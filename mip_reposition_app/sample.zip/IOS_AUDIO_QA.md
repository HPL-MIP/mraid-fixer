# MonoBoost Physical iOS / AppLovin Audio QA

Automated tests validate the audio architecture, but only a physical device in the target AppLovin/WKWebView container can establish audible iOS playback.

Reload the production HTML before each first-interaction case and do not tap elsewhere first.

- [ ] MIP3's first **Start Scan** press plays the click cue without a preliminary unlock tap.
- [ ] MIP3 plays the correct cue at 100%, then the two staged reveal cues once.
- [ ] MIP4's first handle press plays the click cue.
- [ ] MIP4 retries pending playback while dragging and on native release.
- [ ] A below-threshold MIP4 release resets the handle and plays the wrong cue.
- [ ] A successful MIP4 release plays the correct cue and both staged reveal cues once.
- [ ] Releasing or canceling outside the slider does not leave active audio or drag state.
- [ ] CTA presses add no gameplay SFX and use the guarded MRAID-only click path.
- [ ] Hidden/non-viewable transitions cancel one-shots; stale cues do not resume.
- [ ] Numeric `audioVolumeChange` payloads scale SFX and `null` is ignored.
- [ ] Portrait, landscape, and rotation preserve input and sound behavior.
- [ ] No unhandled media promise errors appear in AppLovin preview tooling.

## Verification record

| Field | Result |
|---|---|
| Project and build | MonoBoost MIP3/MIP4; reviewed 2026-10-15 |
| Implementation inspected | Shared sound controller/hook, native button, scan slider, circular scan, lifecycle wiring, and build validator |
| Assets and cue behavior | Five byte-matched shared-library MP3s. Pools: tap/click 4, match-complete 2, wrong 2, CTA part 1 reveal 1, CTA part 2 reveal 1. |
| Automated checks | `npm run typecheck`, 27/27 audio/input tests, 7/7 build-validator tests, and `npm run build` passed. |
| Browser and host | Desktop Chromium portrait and landscape flows verified. Only the expected local `mraid.js` 404 occurred. AppLovin host remains unverified. |
| Physical-device checks | iPhone/iPad and Android AppLovin WebView remain unverified. |
| Diagnostics | Not applicable; no audio diagnostic UI or logging was added. |

| Device | OS | Container/version | Orientation | First gesture | Result |
|---|---|---|---|---|---|
| | | | | | |
