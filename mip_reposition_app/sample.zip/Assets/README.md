# Reusable Asset Library

This directory was copied from `SFX-FIX-TEST-TASK` as source material for future AppLovin playable reskins. It is intentionally outside `src/`, so the current build does not bundle the entire library.

## Contents

- `audio/shared/`: canonical tap, swipe, CTA Part 1, and CTA Part 2 cues.
- `audio/sfx-template/`: SFX-lab completion and bat reference cues.
- `audio/<project>/`: project-derived tap, swipe, scratch, reveal, spin, wrong, match, and CTA variants.
- `fonts/<family-or-project>/`: WOFF/WOFF2 font sources grouped by their prior use. `fonts/geist/OFL.txt` is the only license file that accompanied the imported font library.

At import time the library contained 78 audio files (28 unique byte payloads) and 24 font/license files (14 unique byte payloads). Duplicate bytes are retained under their original project paths so historical guides and project mappings remain understandable.

## Reuse workflow

1. Choose only the cue or font files needed by the new creative.
2. Confirm the selected files' redistribution rights. No license metadata accompanied most imported fonts, so their presence here is not proof of a shipping license.
3. Copy selected runtime files into `src/assets/sounds/` or `src/assets/fonts/`; do not reference `Assets/...` directly from HTML.
4. For audio, trim unused silence/tails and normally use short mono MP3 at about 96 kbps unless quality requires otherwise.
5. For fonts, add explicit `@font-face` declarations, preload only when the first frame needs the face, and include only the weights used.
6. Import runtime assets through TypeScript/CSS so Vite embeds them in the single-file output.
7. Update the typed SFX manifest and preserve native first-gesture playback, pooling, lifecycle, and retry behavior.
8. Run `npm run typecheck`, `npm test`, and `npm run build`; confirm the final HTML stays under 5 MB and contains no unresolved asset paths.

The active implementation rules remain in the root `AGENTS.md` and `IOS_SFX_GUIDELINES.md`. Historical asset-specific examples live in `docs/project-memory/` and must be adapted rather than copied blindly.
