# MonoBoost AppLovin Playables

React/TypeScript source for two self-contained AppLovin MRAID creatives rebuilt from `New Assets/MIP03.html` and `New Assets/MIP04.html`.

## Experiences

- **MIP3:** tap **Start Scan**, watch the circular 2.6-second subscription scan, then reveal the result and CTA.
- **MIP4:** drag the scan handle to at least 85%. An incomplete drag resets; a complete drag reveals the result and CTA.

Both variants retain the supplied copy, color treatment, portrait composition, interaction thresholds, and core animation timing. The authored 1080×1920 stage scales and centers in any viewport, including landscape.

## Runtime behavior

- The local calendar is matched against the supplied Holiday Chart. Active ranges show the matching holiday artwork plus the separate black “CLAIM YOUR 50% DISCOUNT” image; uncovered and intentionally blank ranges show no promo header.
- Thanksgiving/Black Friday/Cyber Monday windows switch artwork on their respective holiday dates. The original gameplay layout is retained when no holiday header is active.
- AppLovin-only MRAID readiness, lifecycle, analytics, and CTA handling.
- CTA opening is centralized through `triggerCTA()` and guarded `mraid.open()` only.
- Five cues from the shared SFX library are imported from `src/assets/sounds/` and embedded into each output: tap, match-complete, wrong, CTA part 1, and CTA part 2.
- Persistent audio pools are created before interaction. Native pointer/touch capture owns first-gesture playback and retry behavior for iOS WebViews.
- Layout and animation pause while the document or MRAID creative is hidden, non-exposed, or non-viewable.

## Commands

```powershell
npm run typecheck
npm test
npm run build
```

`npm run build` produces and validates:

```text
dist/monoboost_acslanot_mip_20261009_03_ecomm_game_unknown_human_dh_unique.html
dist/monoboost_acslanot_mip_20261009_04_ecomm_game_slider_human_dh_unique.html
```

Both outputs are classic-script, single-file creatives. The build verifies the 5 MB limit, exactly one MRAID bridge, the loading guard and click-variable chain, embedded asset byte integrity, and the absence of external creative resources.

A missing local `mraid.js` request is expected in browser previews because AppLovin supplies that bridge at runtime.
