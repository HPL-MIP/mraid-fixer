import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { transformWithOxc } from "vite";

const tests = [];

function test(name, run) {
  tests.push({ name, run });
}

const playLog = [];

class FakeAudio {
  static instances = [];

  constructor(src) {
    this.src = src;
    this.preload = "";
    this.paused = true;
    this.muted = false;
    this.volume = 1;
    this.currentTime = 0;
    this.loop = false;
    this.readyState = 1;
    this.playCalls = 0;
    this.pauseCalls = 0;
    this.loadCalls = 0;
    this.playResponses = [];
    this.listeners = new Map();
    FakeAudio.instances.push(this);
  }

  setAttribute() {}

  removeAttribute(name) {
    if (name === "src") this.src = "";
  }

  addEventListener(name, listener) {
    const listeners = this.listeners.get(name) ?? [];
    listeners.push(listener);
    this.listeners.set(name, listeners);
  }

  removeEventListener(name, listener) {
    const listeners = this.listeners.get(name) ?? [];
    this.listeners.set(
      name,
      listeners.filter((candidate) => candidate !== listener),
    );
  }

  dispatch(name) {
    for (const listener of this.listeners.get(name) ?? []) listener();
  }

  load() {
    this.loadCalls += 1;
  }

  pause() {
    this.pauseCalls += 1;
    this.paused = true;
  }

  play() {
    this.playCalls += 1;
    playLog.push({ element: this, muted: this.muted, src: this.src });
    const response = this.playResponses.shift();
    if (response === "reject") {
      this.paused = true;
      return Promise.reject(new Error("NotAllowedError"));
    }
    this.paused = false;
    return response ?? Promise.resolve();
  }
}

globalThis.Audio = FakeAudio;
globalThis.HTMLMediaElement = { HAVE_NOTHING: 0 };
globalThis.MediaError = { MEDIA_ERR_SRC_NOT_SUPPORTED: 4 };
globalThis.document = { hidden: false };

const controllerSource = await readFile(
  new URL("../src/audio/SfxController.ts", import.meta.url),
  "utf8",
);
const compiled = await transformWithOxc(controllerSource, "SfxController.ts");
const controllerModuleUrl = `data:text/javascript;base64,${Buffer.from(
  compiled.code,
).toString("base64")}`;
const { SfxController } = await import(controllerModuleUrl);

const gestureGateSource = await readFile(
  new URL("../src/audio/SfxGestureGate.ts", import.meta.url),
  "utf8",
);
const compiledGestureGate = await transformWithOxc(
  gestureGateSource,
  "SfxGestureGate.ts",
);
const gestureGateModuleUrl = `data:text/javascript;base64,${Buffer.from(
  compiledGestureGate.code,
).toString("base64")}`;
const { SfxGestureGate } = await import(gestureGateModuleUrl);

const inputOwnershipSource = await readFile(
  new URL("../src/audio/SfxInputOwnership.ts", import.meta.url),
  "utf8",
);
const compiledInputOwnership = await transformWithOxc(
  inputOwnershipSource,
  "SfxInputOwnership.ts",
);
const inputOwnershipModuleUrl = `data:text/javascript;base64,${Buffer.from(
  compiledInputOwnership.code,
).toString("base64")}`;
const { SfxInputOwnership } = await import(inputOwnershipModuleUrl);

function resetAudio() {
  FakeAudio.instances.length = 0;
  playLog.length = 0;
  document.hidden = false;
}

async function flushPromises() {
  await Promise.resolve();
  await Promise.resolve();
}

function cueVoices(controller, key) {
  return controller.cues.get(key).voices;
}

test("constructor eagerly creates the exact persistent pool", () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3", poolSize: 4 },
    correct: { src: "correct.mp3", poolSize: 2 },
    reveal: { src: "reveal.mp3", poolSize: 1 },
  });

  assert.equal(FakeAudio.instances.length, 7);
  assert.deepEqual(
    FakeAudio.instances.map((audio) => audio.src),
    [
      "tap.mp3",
      "tap.mp3",
      "tap.mp3",
      "tap.mp3",
      "correct.mp3",
      "correct.mp3",
      "reveal.mp3",
    ],
  );
  controller.destroy();
});

test("gesture cues request audible playback before muted primes", () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    reveal: { src: "reveal.mp3" },
  });

  controller.playGestureCues([{ key: "tap" }], "pointer:1");

  assert.equal(playLog[0].src, "tap.mp3");
  assert.equal(playLog[0].muted, false);
  assert.equal(playLog[1].src, "reveal.mp3");
  assert.equal(playLog[1].muted, true);
  controller.destroy();
});

test("a gesture-prepared reveal is promoted on the same persistent element", () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    reveal: { src: "reveal.mp3" },
  });
  const reveal = FakeAudio.instances[1];

  controller.playGestureCues([
    { key: "tap" },
    { key: "reveal", options: { loop: true, volume: 0 } },
  ], "touch:reveal");
  reveal.dispatch("playing");
  controller.releaseInteraction("touch:reveal");
  const playCallsBeforePromotion = reveal.playCalls;

  const promoted = controller.promotePrepared("reveal", {
    loop: false,
    restart: true,
    volume: 1,
  });

  assert.equal(promoted, reveal);
  assert.equal(reveal.playCalls, playCallsBeforePromotion);
  assert.equal(reveal.loop, false);
  assert.equal(reveal.volume, 1);
  assert.equal(reveal.muted, false);
  assert.equal(reveal.currentTime, 0);
  controller.destroy();
});

test("an in-flight prepared cue is promoted without a duplicate play request", async () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    endcard: { src: "endcard.mp3" },
  });
  const endcard = FakeAudio.instances[1];
  let finishPreparedPlay;
  endcard.playResponses.push(new Promise((resolve) => {
    finishPreparedPlay = resolve;
  }));

  controller.playGestureCues([
    { key: "tap" },
    { key: "endcard", options: { loop: true, prepareOnly: true } },
  ], "touch:endcard");
  const callsBeforePromotion = endcard.playCalls;
  controller.releaseInteraction("touch:endcard");

  assert.equal(endcard.playCalls, callsBeforePromotion);
  assert.equal(endcard.muted, true);

  const promoted = controller.promotePrepared("endcard", {
    loop: false,
    restart: true,
    volume: 1,
  });

  assert.equal(promoted, endcard);
  assert.equal(endcard.playCalls, callsBeforePromotion);
  assert.equal(endcard.loop, false);
  assert.equal(endcard.volume, 1);
  assert.equal(endcard.muted, false);
  finishPreparedPlay();
  await flushPromises();
  assert.equal(endcard.playCalls, callsBeforePromotion);
  controller.destroy();
});

test("release does not duplicate an in-flight detached silent prime", async () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    endcard: { src: "endcard.mp3" },
  });
  const endcard = FakeAudio.instances[1];
  let finishPrime;
  endcard.playResponses.push(new Promise((resolve) => {
    finishPrime = resolve;
  }));

  controller.playGestureCues([{ key: "tap" }], "touch:prime");
  const callsBeforeRelease = endcard.playCalls;
  controller.releaseInteraction("touch:prime");

  assert.equal(callsBeforeRelease, 1);
  assert.equal(endcard.playCalls, callsBeforeRelease);
  finishPrime();
  await flushPromises();
  assert.equal(endcard.playCalls, callsBeforeRelease);
  controller.destroy();
});

test("delayed CTA cues receive short iOS primes and play only at authored times", async () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    ctaPart1: { src: "cta-part1.mp3" },
    ctaPart2: { src: "cta-part2.mp3" },
  });
  const ctaPart1 = FakeAudio.instances[1];
  const ctaPart2 = FakeAudio.instances[2];

  controller.playGestureCues([{ key: "tap" }], "touch:win");
  await flushPromises();
  controller.releaseInteraction("touch:win");
  const ctaPart1Calls = ctaPart1.playCalls;
  const ctaPart2Calls = ctaPart2.playCalls;

  assert.equal(ctaPart1.paused, true);
  assert.equal(ctaPart1.loop, false);
  assert.equal(ctaPart2.paused, true);
  assert.equal(ctaPart2.loop, false);

  controller.promotePrepared("ctaPart1", {
    loop: false,
    restart: true,
    volume: 1,
  });

  assert.equal(ctaPart1.muted, false);
  assert.equal(ctaPart1.loop, false);
  assert.equal(ctaPart1.playCalls, ctaPart1Calls + 1);
  assert.equal(ctaPart2.paused, true);
  assert.equal(ctaPart2.loop, false);
  assert.equal(ctaPart2.playCalls, ctaPart2Calls);

  controller.promotePrepared("ctaPart2", {
    loop: false,
    restart: true,
    volume: 1,
  });

  assert.equal(ctaPart2.muted, false);
  assert.equal(ctaPart2.loop, false);
  assert.equal(ctaPart2.currentTime, 0);
  assert.equal(ctaPart2.playCalls, ctaPart2Calls + 1);
  controller.destroy();
});

test("a rejected request retries on the same persistent element", async () => {
  resetAudio();
  const controller = new SfxController({ tap: { src: "tap.mp3" } });
  const voice = FakeAudio.instances[0];
  voice.playResponses.push("reject");

  const [requested] = controller.playGestureCues(
    [{ key: "tap" }],
    "pointer:1",
  );
  await flushPromises();
  cueVoices(controller, "tap")[0].lastAttemptAt = performance.now() - 121;
  controller.retryInteraction("pointer:1");
  await flushPromises();

  assert.equal(requested, voice);
  assert.equal(voice.playCalls, 2);
  assert.equal(playLog[0].element, playLog[1].element);
  controller.destroy();
});

test("quick native release retries a still-starting voice immediately", async () => {
  resetAudio();
  const controller = new SfxController({ tap: { src: "tap.mp3" } });
  const voice = FakeAudio.instances[0];
  let finishInitial;
  voice.playResponses.push(
    new Promise((resolve) => {
      finishInitial = resolve;
    }),
  );

  controller.playGestureCues([{ key: "tap" }], "touch:4");
  controller.releaseInteraction("touch:4");

  assert.equal(voice.playCalls, 2);
  assert.equal(playLog[0].element, playLog[1].element);
  finishInitial();
  await flushPromises();
  assert.equal(voice.paused, false);
  controller.destroy();
});

test("a playing event prevents release from replaying the cue", () => {
  resetAudio();
  const controller = new SfxController({ tap: { src: "tap.mp3" } });
  const voice = FakeAudio.instances[0];

  controller.playGestureCues([{ key: "tap" }], "touch:7");
  voice.dispatch("playing");
  controller.releaseInteraction("touch:7");

  assert.equal(voice.playCalls, 1);
  controller.destroy();
});

test("all immediate gesture cues run before future silent primes", () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    result: { src: "result.mp3" },
    reveal: { src: "reveal.mp3" },
  });

  controller.playGestureCues(
    [{ key: "tap" }, { key: "result" }],
    "pointer:1",
  );

  assert.deepEqual(
    playLog.slice(0, 3).map(({ src, muted }) => ({ src, muted })),
    [
      { src: "tap.mp3", muted: false },
      { src: "result.mp3", muted: false },
      { src: "reveal.mp3", muted: true },
    ],
  );
  controller.destroy();
});

test("a rejected request expires after 900 ms", async () => {
  resetAudio();
  const controller = new SfxController({ tap: { src: "tap.mp3" } });
  const voice = FakeAudio.instances[0];
  voice.playResponses.push("reject");

  controller.playGestureCues([{ key: "tap" }], "pointer:1");
  await flushPromises();
  cueVoices(controller, "tap")[0].pendingAt = performance.now() - 901;
  controller.retryInteraction("pointer:1");

  assert.equal(voice.playCalls, 1);
  assert.equal(cueVoices(controller, "tap")[0].pending, false);
  assert.equal(cueVoices(controller, "tap")[0].intendedPlaying, false);
  controller.destroy();
});

test("rapid taps rotate across persistent voices", () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3", poolSize: 2 },
  });

  const [first] = controller.playGestureCues([{ key: "tap" }], "pointer:1");
  const [second] = controller.playGestureCues([{ key: "tap" }], "pointer:2");

  assert.notEqual(first, second);
  assert.equal(FakeAudio.instances.length, 2);
  controller.destroy();
});

test("simultaneous tile presses allow only one successful gesture claim", () => {
  const gate = new SfxGestureGate(900);

  assert.equal(gate.claim(0, 100), true);
  assert.equal(gate.claim(1, 101), false);
  assert.equal(gate.consume(1), false);
  assert.equal(gate.consume(0), true);
  assert.equal(gate.claim(1, 200), true);
  gate.cancel(1);
  assert.equal(gate.claim(2, 201), true);

  const expiringGate = new SfxGestureGate(900);
  assert.equal(expiringGate.claim(0, 0), true);
  assert.equal(expiringGate.claim(1, 901), true);
});

test("touch ownership ignores compatibility pointer capture loss", () => {
  const inputs = new SfxInputOwnership("touch");
  const touch = { owner: "touch-4" };

  assert.equal(inputs.claim("touch", 4, touch), true);
  assert.equal(inputs.take("pointer", 4), undefined);
  assert.equal(inputs.get("touch", 4), touch);
  assert.equal(inputs.take("touch", 4), touch);
});

test("input ownership preserves concurrent tokens in either release order", () => {
  const firstOrder = new SfxInputOwnership("touch");
  firstOrder.claim("touch", 1, "one");
  firstOrder.claim("touch", 2, "two");
  assert.equal(firstOrder.take("touch", 1), "one");
  assert.equal(firstOrder.get("touch", 2), "two");
  assert.equal(firstOrder.take("touch", 2), "two");

  const reverseOrder = new SfxInputOwnership("touch");
  reverseOrder.claim("touch", 1, "one");
  reverseOrder.claim("touch", 2, "two");
  assert.equal(reverseOrder.take("touch", 2), "two");
  assert.equal(reverseOrder.get("touch", 1), "one");
  assert.deepEqual(reverseOrder.drain(), ["one"]);
});

test("pointer ownership rejects touch events and unrelated pointer loss", () => {
  const inputs = new SfxInputOwnership("pointer");
  const pointer = { owner: "pointer-9" };

  assert.equal(inputs.claim("touch", 9, { owner: "touch-9" }), false);
  assert.equal(inputs.claim("pointer", 9, pointer), true);
  assert.equal(inputs.take("pointer", 8), undefined);
  assert.equal(inputs.get("pointer", 9), pointer);
  assert.equal(inputs.take("pointer", 9), pointer);
});

test("late muted-prime completion cannot stop or mute real playback", async () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    delayed: { src: "delayed.mp3" },
  });
  const voice = FakeAudio.instances[1];
  let finishPrime;
  const primeRequest = new Promise((resolve) => {
    finishPrime = resolve;
  });
  voice.playResponses.push(primeRequest);

  controller.playGestureCues([{ key: "tap" }], "pointer:1");
  const actual = controller.play("delayed");
  await flushPromises();
  finishPrime();
  await flushPromises();

  assert.equal(actual, voice);
  assert.equal(voice.paused, false);
  assert.equal(voice.muted, false);
  assert.equal(voice.playCalls, 2);
  controller.destroy();
});

test("release retries a silent prime that rejected before release", async () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3" },
    delayed: { src: "delayed.mp3" },
  });
  const delayed = FakeAudio.instances[1];
  delayed.playResponses.push("reject");

  controller.playGestureCues([{ key: "tap" }], "touch:1");
  await flushPromises();
  assert.equal(delayed.playCalls, 1);

  controller.releaseInteraction("touch:1");
  assert.equal(delayed.playCalls, 2);
  assert.equal(playLog.at(-1).element, delayed);
  assert.equal(playLog.at(-1).muted, true);
  controller.destroy();
});

test("a rejected delayed cue retries on the next native gesture", async () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3", poolSize: 2 },
    delayed: { src: "delayed.mp3" },
  });
  const delayed = FakeAudio.instances[2];

  controller.playGestureCues([{ key: "tap" }], "pointer:1");
  await flushPromises();
  controller.releaseInteraction("pointer:1");
  delayed.playResponses.push("reject");
  const requested = controller.play("delayed");
  await flushPromises();

  controller.playGestureCues([{ key: "tap" }], "pointer:2");
  assert.equal(requested, delayed);
  assert.equal(delayed.playCalls, 3);
  assert.equal(playLog.at(-1).element, delayed);
  controller.destroy();
});

test("an expired delayed cue is discarded instead of replayed", async () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3", poolSize: 2 },
    delayed: { src: "delayed.mp3" },
  });
  const delayed = FakeAudio.instances[2];

  controller.playGestureCues([{ key: "tap" }], "pointer:1");
  await flushPromises();
  controller.releaseInteraction("pointer:1");
  delayed.playResponses.push("reject");
  controller.play("delayed");
  await flushPromises();
  cueVoices(controller, "delayed")[0].pendingAt = performance.now() - 901;

  controller.playGestureCues([{ key: "tap" }], "pointer:2");
  assert.equal(delayed.playCalls, 3);
  assert.equal(playLog.at(-1).element, delayed);
  assert.equal(playLog.at(-1).muted, true);
  assert.equal(cueVoices(controller, "delayed")[0].intendedPlaying, false);
  controller.destroy();
});

test("an unexpected media pause remains recoverable during interaction", () => {
  resetAudio();
  const controller = new SfxController({ tap: { src: "tap.mp3" } });
  const voice = FakeAudio.instances[0];

  controller.playGestureCues([{ key: "tap" }], "pointer:1");
  voice.dispatch("playing");
  voice.dispatch("pause");
  cueVoices(controller, "tap")[0].lastAttemptAt = performance.now() - 121;
  controller.retryInteraction("pointer:1");

  assert.equal(voice.playCalls, 2);
  controller.destroy();
});

test("canceling one active token does not stop another token's voice", () => {
  resetAudio();
  const controller = new SfxController({ tap: { src: "tap.mp3", poolSize: 2 } });
  const [first] = controller.playGestureCues([{ key: "tap" }], "touch:1");
  const [second] = controller.playGestureCues([{ key: "tap" }], "touch:2");
  first.dispatch("playing");
  second.dispatch("playing");

  controller.cancelInteraction("touch:1");

  assert.equal(first.paused, true);
  assert.equal(second.paused, false);
  assert.equal(cueVoices(controller, "tap")[1].intendedPlaying, true);
  controller.destroy();
});

test("pool overflow drops the newest cue without interrupting active voices", () => {
  resetAudio();
  const controller = new SfxController({ tap: { src: "tap.mp3", poolSize: 2 } });
  const [first] = controller.playGestureCues([{ key: "tap" }], "touch:1");
  const [second] = controller.playGestureCues([{ key: "tap" }], "touch:2");
  first.dispatch("playing");
  second.dispatch("playing");

  const [overflow] = controller.playGestureCues([{ key: "tap" }], "touch:3");

  assert.equal(overflow, null);
  assert.equal(first.paused, false);
  assert.equal(second.paused, false);
  assert.equal(first.currentTime, 0);
  assert.equal(second.currentTime, 0);
  controller.destroy();
});

test("configured source segment starts and stops at its bounds", () => {
  resetAudio();
  const controller = new SfxController({
    complete: {
      src: "complete.mp3",
      startAt: 0.12,
      endAt: 1.05,
    },
  });
  const voice = FakeAudio.instances[0];

  controller.playGestureCues([{ key: "complete" }], "pointer:1");
  assert.equal(voice.currentTime, 0.12);
  voice.currentTime = 1.06;
  voice.dispatch("timeupdate");

  assert.equal(voice.paused, true);
  assert.equal(voice.currentTime, 0);
  controller.destroy();
});

test("volume combines cue, per-play, and master scales", () => {
  resetAudio();
  const controller = new SfxController({
    tap: { src: "tap.mp3", volume: 0.8 },
  });
  controller.setMasterVolume(0.25);

  const [voice] = controller.playGestureCues(
    [{ key: "tap", options: { volume: 0.5 } }],
    "pointer:1",
  );

  assert.equal(voice.volume, 0.1);
  controller.destroy();
});

test("lifecycle pause cancels one-shots instead of reviving stale cues", async () => {
  resetAudio();
  const controller = new SfxController({
    short: { src: "short.mp3" },
    long: { src: "long.mp3", pausePolicy: "resume" },
  });
  const [short, long] = controller.playGestureCues(
    [{ key: "short" }, { key: "long" }],
    "pointer:1",
  );
  await flushPromises();
  long.currentTime = 1.25;
  const longCallsBeforePause = long.playCalls;

  controller.setPaused(true);
  assert.equal(short.currentTime, 0);
  assert.equal(short.paused, true);
  assert.equal(long.currentTime, 0);
  assert.equal(long.paused, true);

  controller.setPaused(false);
  await flushPromises();
  assert.equal(short.playCalls, 1);
  assert.equal(long.playCalls, longCallsBeforePause);
  assert.equal(long.currentTime, 0);
  controller.destroy();
});

test("MonoBoost MIP3 and MIP4 preserve native input, staged reveals, and five pooled cues", async () => {
  const [experience, mip3, mip4, slider, circle, nativeButton, styles, manifest, viteConfig, buildVariants] =
    await Promise.all([
      readFile(new URL("../src/experiences/MipExperience.tsx", import.meta.url), "utf8"),
      readFile(new URL("../src/variants/mip3.ts", import.meta.url), "utf8"),
      readFile(new URL("../src/variants/mip4.ts", import.meta.url), "utf8"),
      readFile(new URL("../src/components/ScanSlider.tsx", import.meta.url), "utf8"),
      readFile(new URL("../src/components/CircularScanner.tsx", import.meta.url), "utf8"),
      readFile(new URL("../src/components/NativeGestureButton.tsx", import.meta.url), "utf8"),
      readFile(new URL("../src/styles.css", import.meta.url), "utf8"),
      readFile(new URL("../src/audio/sfxManifest.ts", import.meta.url), "utf8"),
      readFile(new URL("../vite.config.ts", import.meta.url), "utf8"),
      readFile(new URL("../scripts/build-variants.mjs", import.meta.url), "utf8"),
    ]);

  assert.match(nativeButton, /addEventListener\("pointerdown"/);
  assert.match(nativeButton, /addEventListener\("touchstart"/);
  assert.match(slider, /addEventListener\("pointerdown"/);
  assert.match(slider, /addEventListener\("touchstart"/);
  assert.match(slider, /lostpointercapture/);
  assert.match(slider, /requestAnimationFrame/);
  assert.match(slider, /x \/ maxX\(\) >= 0\.85/);
  assert.match(circle, /SCAN_DURATION_MS = 2600/);
  assert.match(circle, /requestAnimationFrame\(tick\)/);
  assert.match(circle, /Element\.prototype\.animate/);
  assert.match(experience, /useSound\(\)/);
  assert.doesNotMatch(experience, /prepareOnly:\s*true/);
  assert.doesNotMatch(experience, /loop:\s*true/);
  assert.doesNotMatch(experience, /\{ key: "endcardReveal"/);
  assert.match(experience, /sfx\.promotePrepared\("productReveal"/);
  assert.match(experience, /sfx\.promotePrepared\("endcardReveal"/);
  assert.match(experience, /key: "wrong"/);
  assert.match(experience, /onClick=\{triggerCTA\}/);
  assert.match(experience, /ctaVisible[\s\S]*className="endcard-clickthrough"/);
  assert.match(styles, /\.endcard-clickthrough\s*\{[^}]*position:\s*fixed;[^}]*inset:\s*0;/s);
  assert.match(mip3, /mechanic: "tap-scan"/);
  assert.match(mip4, /mechanic: "slide-scan"/);
  assert.match(styles, /\.playable-stage\s*\{[^}]*width:\s*1080px;[^}]*height:\s*1920px;/s);
  assert.match(styles, /\.result-cta\s*\{[^}]*animation:/s);
  assert.match(manifest, /"click"[\s\S]*"correct"[\s\S]*"wrong"[\s\S]*"productReveal"[\s\S]*"endcardReveal"/);
  assert.match(manifest, /tap\.mp3/);
  assert.match(manifest, /match-complete\.mp3/);
  assert.match(manifest, /wrong\.mp3/);
  assert.match(manifest, /cta-part1\.mp3/);
  assert.match(manifest, /cta-part2\.mp3/);
  assert.match(viteConfig, /new Set\(\["mip3", "mip4"\]\)/);
  assert.match(buildVariants, /id: "mip3"/);
  assert.match(buildVariants, /id: "mip4"/);
  assert.match(
    buildVariants,
    /monoboost_acslanot_mip_20261009_03_ecomm_game_unknown_human_dh_unique\.html/,
  );
  assert.match(
    buildVariants,
    /monoboost_acslanot_mip_20261009_04_ecomm_game_slider_human_dh_unique\.html/,
  );
});

let passed = 0;
for (const { name, run } of tests) {
  try {
    await run();
    passed += 1;
    console.log(`PASS ${name}`);
  } catch (error) {
    console.error(`FAIL ${name}`);
    throw error;
  }
}
console.log(`[Audio tests] ${passed}/${tests.length} passed`);
