import { readFile, stat, writeFile } from "node:fs/promises";
import { basename, extname, relative, resolve } from "node:path";
import {
  collectImportedAssets,
  listFiles,
  sanitizeInlineScriptProtocols,
  validateBuiltHtml,
} from "./build-validation.mjs";

const distRoot = resolve("dist");
const sourceRoot = resolve("src");
const outputFiles = await listFiles(distRoot);
const htmlFiles = outputFiles.filter(
  (path) => extname(path).toLowerCase() === ".html",
);
const separateAssets = outputFiles.filter(
  (path) => extname(path).toLowerCase() !== ".html",
);

if (htmlFiles.length === 0) {
  throw new Error("Build produced no HTML files.");
}
if (separateAssets.length > 0) {
  throw new Error(
    `Build emitted separate creative resources: ${separateAssets
      .map((path) => relative(distRoot, path))
      .join(", ")}`,
  );
}

const importedAssets = await collectImportedAssets(sourceRoot);

const expectedOutputs = new Set([
  "monoboost_acslanot_mip_20261009_03_ecomm_game_unknown_human_dh_unique.html",
  "monoboost_acslanot_mip_20261009_04_ecomm_game_slider_human_dh_unique.html",
]);
const actualOutputs = new Set(htmlFiles.map((path) => basename(path)));
if (
  expectedOutputs.size !== actualOutputs.size ||
  [...expectedOutputs].some((name) => !actualOutputs.has(name))
) {
  throw new Error(
    `Build must produce exactly the two configured MIP files; found: ${[
      ...actualOutputs,
    ].join(", ")}`,
  );
}

function assetsForOutput(outputPath) {
  return importedAssets.filter((asset) => {
    const path = asset.relativePath.replaceAll("\\", "/").toLowerCase();
    return (
      path.includes("assets/sounds/") ||
      path.includes("assets/creative/holidays/")
    );
  });
}

for (const outputPath of htmlFiles) {
  const expectedAssets = assetsForOutput(outputPath);
  let html = await readFile(outputPath, "utf8");
  html = html
    .replace(/<(script|style)\b([^>]*)>/gi, (_match, rawTag, rawAttributes) => {
      const tag = rawTag.toLowerCase();
      let attributes = rawAttributes.replace(
        /\s+crossorigin(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi,
        "",
      );
      if (tag === "script") {
        attributes = attributes.replace(
          /\s+type\s*=\s*(?:"module"|'module'|module)/gi,
          "",
        );
      }
      return `<${tag}${attributes}>`;
    })
    .replace(/\/\*![\s\S]*?\*\//g, "")
    .replace(/\/\/![^\r\n]*/g, "");
  html = sanitizeInlineScriptProtocols(html);
  // Keep the dynamic-holiday calendar in the same JSON-style literal shape
  // as the approved reference so static campaign tools can discover it.
  html = html.replace(
    /\[([`'"])(\d{4}-\d{2}-\d{2})\1,([`'"])(\d{4}-\d{2}-\d{2})\3,([`'"])([^`'"]+)\5\]/g,
    (_match, _startQuote, start, _endQuote, end, _saleQuote, saleKey) =>
      `["${start}","${end}","${saleKey}"]`,
  );

  const validation = validateBuiltHtml({
    html,
    htmlPath: relative(distRoot, outputPath),
    importedAssets: expectedAssets,
  });

  const visibleHolidayRanges = [...html.matchAll(
    /\["(\d{4}-\d{2}-\d{2})","(\d{4}-\d{2}-\d{2})","([^"]+)"\]/g,
  )];
  if (visibleHolidayRanges.length !== 40) {
    throw new Error(
      `${relative(distRoot, outputPath)} must expose all 40 holiday ranges as literal [start, end, saleKey] tuples; found ${visibleHolidayRanges.length}.`,
    );
  }

  const byteSize = Buffer.byteLength(html, "utf8");
  if (byteSize > 5 * 1024 * 1024) {
    throw new Error(
      `${relative(distRoot, outputPath)} exceeds 5 MB (${byteSize} bytes).`,
    );
  }

  await writeFile(outputPath, html, "utf8");
  const { size } = await stat(outputPath);
  console.log(
    `[Build] ${relative(process.cwd(), outputPath)}: ${size} bytes; ` +
      `${expectedAssets.length} imported assets verified as Base64`,
  );
}
