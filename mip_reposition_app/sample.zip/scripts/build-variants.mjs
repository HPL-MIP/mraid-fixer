import { execFileSync } from "node:child_process";
import { rename, rm } from "node:fs/promises";
import { resolve } from "node:path";

const distRoot = resolve("dist");
const viteBin = resolve("node_modules/vite/bin/vite.js");
const variants = [
  {
    id: "mip3",
    output: "monoboost_acslanot_mip_20261009_03_ecomm_game_unknown_human_dh_unique.html",
  },
  {
    id: "mip4",
    output: "monoboost_acslanot_mip_20261009_04_ecomm_game_slider_human_dh_unique.html",
  },
];

await rm(distRoot, { recursive: true, force: true });

for (const [index, variant] of variants.entries()) {
  execFileSync(process.execPath, [viteBin, "build"], {
    stdio: "inherit",
    env: {
      ...process.env,
      PLAYABLE_FIRST: index === 0 ? "1" : "0",
      PLAYABLE_VARIANT: variant.id,
    },
  });
  await rename(
    resolve(distRoot, "index.html"),
    resolve(distRoot, variant.output),
  );
}
