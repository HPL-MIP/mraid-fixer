import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const source = await readFile(new URL("../src/holidays.ts", import.meta.url), "utf8");
const html = await readFile(new URL("../index.html", import.meta.url), "utf8");

const promotions = new Map();
for (const match of source.matchAll(
  /^\s*(?:"([^"]+)"|(\w+)): promotion\((\d+), "([^"]+)",/gm,
)) {
  promotions.set(match[1] ?? match[2], {
    id: Number(match[3]),
    saleKey: match[4],
  });
}

const ranges = [...source.matchAll(
  /\["(\d{4}-\d{2}-\d{2})", "(\d{4}-\d{2}-\d{2})", "([^"]+)"\]/g,
)].map((match) => ({
  start: match[1],
  end: match[2],
  ...promotions.get(match[3]),
}));

assert.equal(promotions.size, 19, "all reference holiday identities are present");
assert.equal(ranges.length, 40, "the full reference calendar was copied");

for (let index = 0; index < ranges.length; index += 1) {
  const current = ranges[index];
  assert.ok(current.id && current.saleKey, `range ${index + 1} resolves a promotion`);
  assert.ok(current.start <= current.end, `range ${index + 1} is ordered`);
  if (index > 0) {
    assert.ok(ranges[index - 1].end < current.start, `range ${index + 1} does not overlap`);
  }
}

function resolve(day) {
  return ranges.find(({ start, end }) => start <= day && day <= end) ?? null;
}

const checks = [
  ["2026-08-30", null],
  ["2026-08-31", "labor-day"],
  ["2026-09-07", "labor-day"],
  ["2026-10-31", "halloween"],
  ["2026-11-01", null],
  ["2026-11-22", null],
  ["2026-11-23", "thanksgiving"],
  ["2026-11-27", "black-friday"],
  ["2026-11-28", "cyber-monday"],
  ["2026-11-30", "cyber-monday"],
  ["2027-01-14", "winter"],
  ["2027-01-15", null],
  ["2027-01-18", null],
  ["2027-01-19", "winter"],
  ["2027-11-26", "black-friday"],
  ["2027-11-27", "cyber-monday"],
  ["2027-11-29", "cyber-monday"],
  ["2027-12-31", "winter"],
  ["2028-01-01", null],
];

for (const [day, expected] of checks) {
  assert.equal(resolve(day)?.saleKey ?? null, expected, day);
}

assert.match(html, /URLSearchParams\(window\.location\.search\)\.get\("date"\)/);
assert.match(html, /\^\\d\{4\}-\\d\{2\}-\\d\{2\}\$/);
assert.match(html, /window\.getCreativeNow\s*=/);
assert.match(html, /window\.creativeDateIsPinned\s*=\s*previewDate !== null/);

console.log(`[Holiday tests] ${checks.length} boundary dates and ${ranges.length} ranges passed`);
