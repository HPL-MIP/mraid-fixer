import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import {
  sanitizeInlineScriptProtocols,
  validateBuiltHtml,
} from "./build-validation.mjs";

const assetBytes = Buffer.from("ID3fixture-audio-bytes", "ascii");
const assetBase64 = assetBytes.toString("base64");
const importedAssets = [
  {
    relativePath: "assets/sounds/fixture.mp3",
    expectedMime: "audio/mpeg",
    hash: createHash("sha256").update(assetBytes).digest("hex"),
  },
];

const helper = `
  function trackMraidReadiness() {}
  window.isMraidUsable = function () { return true; };
  function init() {}
  if (mraid.getState() === "loading") {
    mraid.addEventListener("ready", init);
  }
  function handleClickAction() {
    const clickTarget =
      window.clickTag ||
      window.clickTag1 ||
      window.clickthrough ||
      window.clickThrough ||
      "";
    if (clickTarget) mraid.open(clickTarget);
    else mraid.open();
  }
`;

const validHtml = `<!doctype html>
<html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<script src="mraid.js"></script>
<script>${helper}</script>
</head><body><audio src="data:audio/mpeg;base64,${assetBase64}"></audio></body></html>`;

function validate(html) {
  return validateBuiltHtml({
    html,
    htmlPath: "fixture.html",
    importedAssets,
  });
}

function rejects(name, mutate, expected) {
  assert.throws(() => validate(mutate(validHtml)), expected, name);
}

validate(validHtml);
rejects(
  "non-Base64 binary asset",
  (html) => html.replace(";base64,", ","),
  /non-Base64 audio\/mpeg/,
);
rejects(
  "separate local asset",
  (html) => html.replace("</body>", '<img src="loose.png"></body>'),
  /external resource reference/,
);
rejects(
  "protocol literal",
  (html) => html.replace("</body>", '<p>https:\x2f\x2fexample.test</p></body>').replace("\\x2f\\x2f", "//"),
  /forbidden literal protocol/,
);
rejects(
  "corrupt asset bytes",
  (html) => html.replace(assetBase64, Buffer.from("ID3different").toString("base64")),
  /does not contain assets\/sounds\/fixture\.mp3/,
);
rejects(
  "invalid inline JavaScript",
  (html) => html.replace("</body>", "<script>function (</script></body>"),
  /invalid inline JavaScript/,
);

const embeddedDuplicateMraid = Buffer.from(
  '<!doctype html><html><head><script src="mraid.js"></script></head></html>',
  "utf8",
).toString("base64");
rejects(
  "embedded duplicate MRAID",
  (html) =>
    html.replace(
      "</body>",
      `<iframe src="data:text/html;base64,${embeddedDuplicateMraid}"></iframe></body>`,
    ),
  /duplicate MRAID integration/,
);

const withProtocols = `<script>const a="http:\x2f\x2fexample";const b="https:\x2f\x2fexample";</script>`
  .replace(/\\x2f/g, "/");
const sanitized = sanitizeInlineScriptProtocols(withProtocols);
assert.doesNotMatch(sanitized, /https?:\/\//);
new Function(sanitized.match(/<script>([\s\S]*)<\/script>/)[1]);

console.log("[Build validation tests] 7/7 passed");
