import { createHash } from "node:crypto";
import { access, readFile, readdir } from "node:fs/promises";
import { extname, isAbsolute, relative, resolve } from "node:path";
import { Script } from "node:vm";

const ASSET_MIME_BY_EXTENSION = new Map([
  [".avif", "image/avif"],
  [".gif", "image/gif"],
  [".jpg", "image/jpeg"],
  [".jpeg", "image/jpeg"],
  [".png", "image/png"],
  [".svg", "image/svg+xml"],
  [".webp", "image/webp"],
  [".mp3", "audio/mpeg"],
  [".m4a", "audio/mp4"],
  [".ogg", "audio/ogg"],
  [".wav", "audio/wav"],
  [".aac", "audio/aac"],
  [".mp4", "video/mp4"],
  [".webm", "video/webm"],
  [".woff", "font/woff"],
  [".woff2", "font/woff2"],
  [".ttf", "font/ttf"],
  [".otf", "font/otf"],
  [".html", "text/html"],
]);

const SOURCE_EXTENSIONS = new Set([".css", ".js", ".jsx", ".ts", ".tsx"]);
const RESOURCE_TAG_PATTERN =
  /<(?:script|img|audio|video|source|link|iframe|object|embed)\b[^>]*>/gi;
const RESOURCE_ATTRIBUTE_PATTERN = /\b(src|href|poster|data)\s*=\s*(["'])(.*?)\2/gi;
const DATA_URI_PATTERN =
  /data:([a-z0-9.+-]+\/[a-z0-9.+-]+)((?:;[a-z0-9.+-]+(?:=[^;,"'`\s)]*)?)*),/gi;
const QUOTED_ASSET_PATTERN = /["'`]([^"'`]+\.[a-z0-9]{2,5}(?:[?#][^"'`]*)?)["'`]/gi;

function hash(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

async function walkFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) files.push(...(await walkFiles(path)));
    else if (entry.isFile()) files.push(path);
  }
  return files;
}

function isInside(parent, candidate) {
  const path = relative(parent, candidate);
  return path !== "" && !path.startsWith("..") && !isAbsolute(path);
}

function normalizeBase64(payload, label) {
  const normalized = payload.replace(/\s/g, "");
  if (
    normalized.length === 0 ||
    normalized.length % 4 !== 0 ||
    !/^[A-Za-z0-9+/]+={0,2}$/.test(normalized)
  ) {
    throw new Error(`${label} contains malformed Base64 data.`);
  }
  const bytes = Buffer.from(normalized, "base64");
  if (
    bytes.toString("base64").replace(/=+$/, "") !==
    normalized.replace(/=+$/, "")
  ) {
    throw new Error(`${label} contains non-canonical Base64 data.`);
  }
  return bytes;
}

function assertMimeSignature(mime, bytes, label) {
  const ascii = bytes.subarray(0, 12).toString("ascii");
  const hex = bytes.subarray(0, 12).toString("hex");
  const textStart = bytes.subarray(0, 256).toString("utf8").trimStart();
  const valid =
    (mime === "audio/mpeg" &&
      (ascii.startsWith("ID3") ||
        (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0))) ||
    (mime === "image/png" && hex.startsWith("89504e470d0a1a0a")) ||
    (mime === "image/jpeg" && hex.startsWith("ffd8ff")) ||
    (mime === "image/gif" && ascii.startsWith("GIF8")) ||
    (mime === "image/webp" && ascii.startsWith("RIFF") && ascii.slice(8, 12) === "WEBP") ||
    (mime === "image/avif" && ascii.slice(4, 8) === "ftyp") ||
    (mime === "audio/wav" && ascii.startsWith("RIFF") && ascii.slice(8, 12) === "WAVE") ||
    (mime === "audio/ogg" && ascii.startsWith("OggS")) ||
    (mime === "audio/aac" &&
      bytes[0] === 0xff &&
      (bytes[1] & 0xf6) === 0xf0) ||
    ((mime === "audio/mp4" || mime === "video/mp4") && ascii.slice(4, 8) === "ftyp") ||
    (mime === "video/webm" && hex.startsWith("1a45dfa3")) ||
    (mime === "font/woff" && ascii.startsWith("wOFF")) ||
    (mime === "font/woff2" && ascii.startsWith("wOF2")) ||
    ((mime === "font/ttf" || mime === "font/otf") &&
      (hex.startsWith("00010000") ||
        ascii.startsWith("OTTO") ||
        ascii.startsWith("true") ||
        ascii.startsWith("typ1"))) ||
    (mime === "image/svg+xml" && /^(?:<\?xml[^>]*>\s*)?<svg\b/i.test(textStart)) ||
    (mime === "text/html" && /^(?:<!doctype\s+html|<html\b)/i.test(textStart));
  if (!valid) throw new Error(`${label} does not match its declared MIME type ${mime}.`);
}

export function sanitizeInlineScriptProtocols(html) {
  return html.replace(
    /<script([^>]*)>([\s\S]*?)<\/script>/gi,
    (match, attributes, scriptBody) => {
      if (/\bsrc\s*=/i.test(attributes)) return match;
      const sanitizedBody = scriptBody
        .replace(/http:\/\//g, "http:\\x2f\\x2f")
        .replace(/https:\/\//g, "https:\\x2f\\x2f");
      return `<script${attributes}>${sanitizedBody}</script>`;
    },
  );
}

export async function collectImportedAssets(sourceRoot) {
  const root = resolve(sourceRoot);
  const files = await walkFiles(root);
  const assets = new Map();

  for (const sourcePath of files) {
    if (!SOURCE_EXTENSIONS.has(extname(sourcePath).toLowerCase())) continue;
    const source = await readFile(sourcePath, "utf8");
    for (const match of source.matchAll(QUOTED_ASSET_PATTERN)) {
      const reference = match[1].split(/[?#]/, 1)[0];
      if (!reference.startsWith(".")) continue;
      const extension = extname(reference).toLowerCase();
      const expectedMime = ASSET_MIME_BY_EXTENSION.get(extension);
      if (!expectedMime || extension === ".html") continue;
      const assetPath = resolve(sourcePath, "..", reference);
      if (!isInside(root, assetPath)) {
        throw new Error(`Asset import escapes src/: ${reference} in ${sourcePath}.`);
      }
      try {
        await access(assetPath);
      } catch {
        throw new Error(`Imported asset does not exist: ${assetPath}.`);
      }
      const bytes = await readFile(assetPath);
      assets.set(assetPath, {
        path: assetPath,
        relativePath: relative(root, assetPath),
        expectedMime,
        bytes,
        hash: hash(bytes),
      });
    }
  }

  return [...assets.values()];
}

function extractDataUris(html, htmlPath) {
  const uris = [];
  for (const match of html.matchAll(DATA_URI_PATTERN)) {
    const [prefix, rawMime, rawParameters] = match;
    const mime = rawMime.toLowerCase();
    const parameters = rawParameters.toLowerCase();
    const payloadStart = (match.index ?? 0) + prefix.length;
    let payloadEnd = payloadStart;
    while (
      payloadEnd < html.length &&
      /[A-Za-z0-9+/=\r\n]/.test(html[payloadEnd])
    ) {
      payloadEnd += 1;
    }
    const payload = html.slice(payloadStart, payloadEnd);
    const isBase64 = /(?:^|;)base64(?:;|$)/.test(parameters);
    const mustBeBase64 =
      mime === "text/html" ||
      (!mime.startsWith("text/") &&
        mime !== "application/json" &&
        mime !== "application/javascript" &&
        mime !== "image/svg+xml");

    if (mustBeBase64 && !isBase64) {
      throw new Error(`${htmlPath} contains a non-Base64 ${mime} data URI.`);
    }
    if (!isBase64) continue;

    const bytes = normalizeBase64(payload, `${htmlPath} ${mime} data URI`);
    assertMimeSignature(mime, bytes, `${htmlPath} data URI`);
    if (mime === "text/html") {
      const embeddedHtml = bytes.toString("utf8");
      if (
        /<script\s+src=["']mraid\.js["']\s*><\/script>/i.test(embeddedHtml) ||
        /trackMraidReadiness|handleClickAction|window\.isMraidUsable/.test(
          embeddedHtml,
        )
      ) {
        throw new Error(`${htmlPath} embeds HTML with duplicate MRAID integration.`);
      }
    }
    uris.push({ mime, bytes, hash: hash(bytes) });
  }
  return uris;
}

function assertResourceReferences(html, htmlPath) {
  for (const tagMatch of html.matchAll(RESOURCE_TAG_PATTERN)) {
    const tag = tagMatch[0];
    for (const attributeMatch of tag.matchAll(RESOURCE_ATTRIBUTE_PATTERN)) {
      const value = attributeMatch[3].trim();
      if (!value || value.startsWith("#") || value.startsWith("data:")) continue;
      if (/^<script\s+src=["']mraid\.js["']\s*>$/i.test(tag)) continue;
      throw new Error(`${htmlPath} contains an external resource reference: ${value}`);
    }
    const srcset = /\bsrcset\s*=\s*(["'])(.*?)\1/i.exec(tag)?.[2];
    if (srcset) {
      for (const candidate of srcset.split(",")) {
        const value = candidate.trim().split(/\s+/, 1)[0];
        if (value && !value.startsWith("data:")) {
          throw new Error(`${htmlPath} contains an external srcset reference: ${value}`);
        }
      }
    }
  }

  for (const match of html.matchAll(/url\(\s*(["']?)(.*?)\1\s*\)/gi)) {
    const value = match[2].trim();
    if (value && !value.startsWith("data:") && !value.startsWith("#")) {
      throw new Error(`${htmlPath} contains an external CSS resource: ${value}`);
    }
  }

  for (const match of html.matchAll(QUOTED_ASSET_PATTERN)) {
    const value = match[1];
    if (value === "mraid.js" || value.startsWith("data:")) continue;
    const extension = extname(value.split(/[?#]/, 1)[0]).toLowerCase();
    if (ASSET_MIME_BY_EXTENSION.has(extension)) {
      throw new Error(`${htmlPath} contains an unembedded asset string: ${value}`);
    }
  }
}

function assertInlineScriptsParse(html, htmlPath) {
  let scriptIndex = 0;
  for (const match of html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/gi)) {
    scriptIndex += 1;
    const attributes = match[1];
    if (/\bsrc\s*=/i.test(attributes)) continue;
    const type = /\btype\s*=\s*["']([^"']+)["']/i.exec(attributes)?.[1];
    if (type && !/^(?:text|application)\/javascript$/i.test(type)) continue;
    try {
      new Script(match[2], { filename: `${htmlPath}#script-${scriptIndex}` });
    } catch (error) {
      throw new Error(`${htmlPath} contains invalid inline JavaScript: ${error.message}`);
    }
  }
}

function assertMraidContract(html, htmlPath) {
  const bridge = '<script src="mraid.js"></script>';
  const bridgeMatches = html.match(/<script src="mraid\.js"><\/script>/g) ?? [];
  if (bridgeMatches.length !== 1) {
    throw new Error(`${htmlPath} must contain exactly one MRAID bridge; found ${bridgeMatches.length}.`);
  }

  const bridgeIndex = html.indexOf(bridge);
  const helperIndex = html.indexOf("trackMraidReadiness");
  if (helperIndex < bridgeIndex) {
    throw new Error(`${htmlPath} places the MRAID readiness helper before the bridge.`);
  }

  const requiredPatterns = [
    /window\.isMraidUsable\s*=/,
    /mraid\.getState\(\)\s*===\s*["']loading["']/,
    /mraid\.addEventListener\(["']ready["'],\s*init\)/,
    /function\s+handleClickAction\s*\(/,
    /mraid\.open\(clickTarget\)/,
    /mraid\.open\(\)/,
  ];
  for (const pattern of requiredPatterns) {
    if (!pattern.test(html)) {
      throw new Error(`${htmlPath} is missing required MRAID helper code: ${pattern}.`);
    }
  }

  const clickVariables = ["window.clickTag", "window.clickTag1", "window.clickthrough", "window.clickThrough"];
  let previousIndex = -1;
  for (const variable of clickVariables) {
    const index = html.indexOf(variable);
    if (index <= previousIndex) {
      throw new Error(`${htmlPath} has an invalid AppLovin click-variable chain.`);
    }
    previousIndex = index;
  }
}

export function validateBuiltHtml({ html, htmlPath, importedAssets }) {
  if (/https?:\/\//i.test(html)) {
    throw new Error(`${htmlPath} contains a forbidden literal protocol string.`);
  }
  const executableTags = html.match(/<(?:script|style)\b[^>]*>/gi) ?? [];
  if (
    executableTags.some(
      (tag) =>
        /\btype\s*=\s*["']?module["']?/i.test(tag) ||
        /\bcrossorigin(?:\s|=|>)/i.test(tag),
    )
  ) {
    throw new Error(`${htmlPath} contains a module or crossorigin resource attribute.`);
  }
  if (/\/\*!|\/\/!/.test(html)) {
    throw new Error(`${htmlPath} contains a legal/license comment banner.`);
  }
  if (!/<meta\s+name="viewport"\s+content="width=device-width,initial-scale=1,maximum-scale=1"\s*\/?>/i.test(html)) {
    throw new Error(`${htmlPath} is missing the required viewport declaration.`);
  }

  assertMraidContract(html, htmlPath);
  assertResourceReferences(html, htmlPath);
  assertInlineScriptsParse(html, htmlPath);
  const dataUris = extractDataUris(html, htmlPath);

  for (const asset of importedAssets) {
    const match = dataUris.find(
      (uri) => uri.hash === asset.hash && uri.mime === asset.expectedMime,
    );
    if (!match) {
      throw new Error(
        `${htmlPath} does not contain ${asset.relativePath} as byte-matching Base64 ${asset.expectedMime}.`,
      );
    }
  }

  return { dataUris };
}

export async function listFiles(directory) {
  return walkFiles(resolve(directory));
}
