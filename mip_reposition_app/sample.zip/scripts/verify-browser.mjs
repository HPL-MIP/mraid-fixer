const endpoint = "http:\x2f\x2f127.0.0.1:9222/json";
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let pages = [];
for (let attempt = 0; attempt < 20 && pages.length === 0; attempt += 1) {
  try {
    pages = await fetch(endpoint).then((response) => response.json());
  } catch {
    await sleep(200);
  }
}

const page = pages.find((entry) => entry.url.includes("127.0.0.1:5173"));
if (!page) throw new Error("Playable browser target was not found.");

const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

let commandId = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (!message.id || !pending.has(message.id)) return;
  const { resolve, reject } = pending.get(message.id);
  pending.delete(message.id);
  if (message.error) reject(new Error(message.error.message));
  else resolve(message.result);
});

function send(method, params = {}) {
  const id = ++commandId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
}

async function evaluate(expression) {
  const result = await send("Runtime.evaluate", {
    expression,
    awaitPromise: true,
    returnByValue: true,
  });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
  return result.result.value;
}

async function clickCard(index) {
  const point = await evaluate(`(() => {
    const element = document.querySelectorAll('.cube')[${index}];
    if (!element) return null;
    const rect = element.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  })()`);
  if (!point) throw new Error(`Card ${index} was not found.`);
  await send("Input.dispatchMouseEvent", {
    type: "mousePressed",
    x: point.x,
    y: point.y,
    button: "left",
    clickCount: 1,
  });
  await send("Input.dispatchMouseEvent", {
    type: "mouseReleased",
    x: point.x,
    y: point.y,
    button: "left",
    clickCount: 1,
  });
}

await send("Page.reload", { ignoreCache: true });
await sleep(2600);
const opening = await evaluate(`({
  cards: document.querySelectorAll('.cube').length,
  title: document.querySelector('h1')?.textContent,
  cta: document.querySelector('.persistent-cta')?.textContent,
  bodyWidth: document.body.scrollWidth,
  viewportWidth: window.innerWidth
})`);
if (opening.cards !== 4 || opening.title !== "Find the matching pair" || opening.cta !== "Shop Now") {
  throw new Error(`Opening state failed: ${JSON.stringify(opening)}`);
}
if (opening.bodyWidth !== opening.viewportWidth) {
  throw new Error(`Unexpected horizontal overflow: ${JSON.stringify(opening)}`);
}

await clickCard(0);
await clickCard(2);
await sleep(950);
const retry = await evaluate(`({
  message: document.querySelector('.retry-message')?.textContent,
  correct: document.querySelectorAll('.feedback-circle.correct').length,
  wrong: document.querySelectorAll('.feedback-circle.wrong').length,
  ctaAboveOverlay: Number(getComputedStyle(document.querySelector('.persistent-cta')).zIndex) > Number(getComputedStyle(document.querySelector('.retry-overlay')).zIndex)
})`);
if (retry.message !== "Try Again" || retry.correct !== 1 || retry.wrong !== 1 || !retry.ctaAboveOverlay) {
  throw new Error(`Retry feedback failed: ${JSON.stringify(retry)}`);
}

await sleep(1300);
const resetCount = await evaluate(`document.querySelectorAll('.feedback-circle').length`);
if (resetCount !== 0) throw new Error("Selections did not reset after retry.");

await clickCard(0);
await clickCard(1);
await sleep(950);
const reveal = await evaluate(`document.querySelector('.reveal-panel h1')?.textContent`);
if (reveal !== "Product Reveal") throw new Error(`Reveal failed: ${String(reveal)}`);
const revealCta = await evaluate(`document.querySelector('.persistent-cta')?.textContent`);
if (revealCta !== "Shop Now") throw new Error("Persistent CTA disappeared during reveal.");

await sleep(2800);
const endCard = await evaluate(`document.querySelector('.end-title')?.textContent`);
if (endCard !== "Shop Now") throw new Error(`End card failed: ${String(endCard)}`);
const persistentCtaAtEnd = await evaluate(`document.querySelector('.persistent-cta')`);
if (persistentCtaAtEnd !== null) throw new Error("Persistent CTA remained over the end card.");

console.log("[Browser] opening, retry/reset, reveal, and end-card flows passed");
socket.send(JSON.stringify({ id: ++commandId, method: "Browser.close", params: {} }));
await sleep(200);
socket.close();
