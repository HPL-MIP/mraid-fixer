import { fileURLToPath, URL } from "node:url";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const supportedVariants = new Set(["mip3", "mip4"]);
const variant = process.env.PLAYABLE_VARIANT ?? "mip3";
if (!supportedVariants.has(variant)) {
  throw new Error(`Unsupported PLAYABLE_VARIANT: ${variant}`);
}

export default defineConfig({
  plugins: [
    react(),
    viteSingleFile(),
    {
      name: "variant-title",
      transformIndexHtml(html) {
        return html.replace(
          "<title>MONOBOOST</title>",
          `<title>MONOBOOST ${variant.toUpperCase()}</title>`,
        );
      },
    },
  ],
  resolve: {
    alias: {
      "@active-variant": fileURLToPath(
        new URL(`./src/variants/${variant}.ts`, import.meta.url),
      ),
      "@active-experience": fileURLToPath(
        new URL("./src/experiences/MipExperience.tsx", import.meta.url),
      ),
    },
  },
  base: "./",
  build: {
    target: "es2018",
    modulePreload: false,
    assetsInlineLimit: 100_000_000,
    cssCodeSplit: false,
    emptyOutDir: process.env.PLAYABLE_FIRST === "1",
    rollupOptions: {
      output: { format: "iife", inlineDynamicImports: true },
    },
  },
  oxc: { legalComments: "none" },
});
