# AGENTS.md - AppLovin React Playable

## Stack
React, TypeScript, Vite, vite-plugin-singlefile, WebP assets, optional MP3 audio.

Network target: AppLovin only (`al`).

This is a portable template for AppLovin-only React playable projects. It must support AppLovin MRAID lifecycle callbacks, responsive React/CSS layout, guarded media handling, video endcards, and a guarded AppLovin CTA path that resolves the four supported click variables and exclusively uses `mraid.open(clickTarget)` or blank `mraid.open()`.

Framework scope: This template is for fresh React projects. Use React hooks for shared audio and responsive state, and keep lifecycle wiring in the app layer. Paths below describe the template architecture, not external documentation dependencies.

## Preserved Project Memory

Earlier multi-project build guidance and implementation lessons are preserved under `docs/project-memory/`. Consult its `README.md` and the relevant guide when changing audio, MRAID, responsive behavior, or AppLovin output. The rules in this file and direct chat instructions remain authoritative for the active Memowrite project; archived project-specific notes are historical context, not active requirements.

## Project Structure
```
src/
  main.tsx             # DOM boot gate, MRAID init, React root creation, resize binding
  App.tsx              # Top-level playable flow and lifecycle wiring
  constants.ts         # Design size, z-index constants, authored layout constants
  networks.ts          # initMraid(), bindLifecycle(), triggerCTA(), notifyGameX()
  analytics.ts         # Optional AppLovin analytics wrapper / guarded logging
  hooks/
    useResponsive.ts   # sx(), sy(), sd(), viewport/DPR helpers
    useSound.ts        # Shared mobile-safe audio hook
  components/          # Single-responsibility gameplay/UI components
    # one file per distinct mechanic, widget, or system
  assets/
    images/
    sounds/
    videos/
scripts/build-all.mjs  # AppLovin-only single-file HTML build
```

## Responsibility Split
- Components own one concern each and receive state, callbacks, and layout values through props or focused hooks.
- Components must not call ad SDKs, MRAID, analytics, or lifecycle helpers directly. CTA components invoke an app-supplied callback wired to `triggerCTA()`; the helper owns CTA lifecycle and analytics calls.
- `App.tsx` is the wiring layer. It creates the playable flow, passes data between components, and calls lifecycle helpers at the correct moments.
- `networks.ts` owns runtime SDK integration, AppLovin-facing callbacks, and CTA orchestration. The required inline head helper owns early readiness and `handleClickAction()`; `networks.ts` delegates to that helper and retains the same guarded MRAID-only behavior when the helper is absent.
- End-screen CTA buttons must call the shared CTA helper rather than touching `mraid.open()` or any browser navigation API directly.

## Rules
- 60 FPS target; never below 30 on mid-range Android.
- `dist/index.html` must be no larger than 5 MB.
- Use WebP for images and short compressed audio when audio exists.
- No hardcoded layout pixels in components. Use responsive helpers, CSS variables, or container-relative sizing derived from the authored `1080 x 1920` layout.
- No audio autoplay. Unlock and request the first interaction SFX synchronously in the real gameplay element's native `pointerdown` (or mobile `touchstart` fallback); preserve desktop `pointerdown` support.
- Prefer CSS transforms for motion and avoid layout-thrashing properties in hot interaction paths.
- Use `requestAnimationFrame` for drag/move loops that update visual state frequently.
- Do not put frame-hot pointer or animation updates through React state. Use refs, CSS transforms, and `requestAnimationFrame`; reserve React state for phase changes, score, progress, and endcard visibility.
- Pool or reuse frequently spawned DOM elements and audio instances.
- Never dim via `body` or page background. Use an app overlay at a named z-index.
- Only one React root may be mounted on the page.
- Avoid React `StrictMode` in production ad builds. If it is used during development, lifecycle, analytics, audio unlock, and CTA setup must be idempotent because effects may run more than once.
- The root app should be fixed to the viewport with no document scrolling. Use CSS such as `position: fixed`, `inset: 0`, `overflow: hidden`, `touch-action: none`, `user-select: none`, and `overscroll-behavior: none` on the app surface as appropriate.

## Responsive Layout
The authored reference size is `1080 x 1920`.

```ts
const s = Math.min(viewW / 1080, viewH / 1920);
const offX = (viewW - 1080 * s) / 2;
const offY = (viewH - 1920 * s) / 2;
// sx/sy/sd apply offX, offY, and s
```

Requirements:
- Use a central responsive hook/service that observes `window.visualViewport` when available and falls back to `window.innerWidth`/`window.innerHeight`.
- On viewport or DPR change, update responsive state and CSS variables such as `--vw`, `--vh`, `--dpr`, `--scale`, `--offset-x`, and `--offset-y`.
- Debounce resize work with `requestAnimationFrame`; use delayed retries around `100`, `300`, and `600` ms for mobile browser settle.
- Every visible component with authored positions must derive layout from responsive helpers, CSS variables, or props.
- Prefer stable dimensions with `width`, `height`, `aspect-ratio`, `min/max`, and `transform: translate3d(...)` so text, images, and hit areas do not resize unpredictably.

## AppLovin MRAID
These MRAID v2 requirements apply only to AppLovin MIP playable HTML builds and take priority for all MRAID work. The implementation must declare the host-provided MRAID bridge exactly once, track readiness near the start of `<head>`, delay creative initialization while MRAID is loading, use guarded `mraid.open()` as the only click-through mechanism, preserve the supported click-tag chain, pause/resume media based on MRAID viewability, and keep the playable self-contained within the AppLovin size limit.

Declare the bridge in `<head>` before the MRAID helper code:

```html
<!DOCTYPE html>
<html>
  <head>
    <script src="mraid.js"></script>
  </head>
</html>
```

Bridge requirements:
- Include `<script src="mraid.js"></script>` exactly once in the top-level document.
- Use the relative path `mraid.js` exactly as shown.
- Do not use a CDN or absolute URL for the bridge.
- Do not bundle a local implementation of `mraid.js`; the ad container provides it at runtime.
- The network identifier comment may be included for naming/packaging metadata.
- The MRAID bridge and helper must load before the bundled playable script.

Place the readiness helper immediately after the bridge:

```html
<script>
  (function () {
    let mraidIsReady = false;
    let mraidReadyListenerAttached = false;

    function trackMraidReadiness(mraid) {
      if (
        mraidReadyListenerAttached ||
        !mraid ||
        typeof mraid.addEventListener !== "function"
      ) {
        return;
      }

      try {
        mraid.addEventListener("ready", function () {
          mraidIsReady = true;
        });
        mraidReadyListenerAttached = true;
      } catch (error) {
        // getState() remains the primary readiness check.
      }
    }

    window.trackMraidReadiness = trackMraidReadiness;

    window.isMraidUsable = function isMraidUsable(mraid) {
      if (!mraid) {
        return false;
      }

      trackMraidReadiness(mraid);
      if (typeof mraid.getState !== "function") {
        return true;
      }

      try {
        const state = mraid.getState();
        return state === "default" || state === "expanded";
      } catch (error) {
        return mraidIsReady;
      }
    };
  })();
</script>
```

Do not initialize layout, interaction, media playback, orientation handling, or React mount until the MRAID boot gate resolves through readiness or the bounded missing/broken-bridge timeout fallback. Use this loading-state guard shape:

```js
let creativeInitialized = false;

function init() {
  if (creativeInitialized) return;
  creativeInitialized = true;

  // Initialize the creative here.
}

if (typeof mraid === "undefined") {
  init();
} else {
  if (mraid.getState() === "loading") {
    mraid.addEventListener("ready", init);
  } else {
    init();
  }
}
```

The comparison must be `mraid.getState() === "loading"`, and the `ready` listener must be inside that same branch. Inverse checks such as `getState() !== "loading"` do not pass AppLovin validation. `init()` must be idempotent. This snippet illustrates the required branch shape, not a complete boot implementation: guard both methods with `typeof`, catch bridge exceptions, poll briefly for a missing bridge, and self-resolve loading after about 2 seconds. The head gate must signal the shared boot process; it must not mount a second creative.

Resolve the standard click variables in this order and use `mraid.open()` only when MRAID is usable:

```js
function handleClickAction() {
  const mraid = window.mraid || {};
  const clickTarget =
    window.clickTag ||
    window.clickTag1 ||
    window.clickthrough ||
    window.clickThrough ||
    "";

  if (
    typeof mraid.open === "function" &&
    window.isMraidUsable(mraid)
  ) {
    try {
      if (clickTarget) {
        mraid.open(clickTarget);
      } else {
        mraid.open();
      }
      return;
    } catch (error) {
      // MRAID-only policy: fail safely without navigating.
      return;
    }
  }
}
```

Requirements:

- Guard `mraid.open()` with `window.isMraidUsable(mraid)`.
- Wrap `mraid.open()` in `try/catch` so previews and non-MRAID environments fail safely without navigation.
- Keep all four supported click variables in the click-target chain.
- Do not add browser navigation or network-specific click-through fallbacks. If MRAID is unavailable, unusable, missing `open`, or throws, return without navigating.

- Components must call the shared CTA helper; they must not call CTA/open APIs directly.
- Do not use `location.href`, `location.assign()`, `location.replace()`, anchor click simulation, or non-AppLovin store SDK APIs.

Any build containing `<video>` or `<audio>` elements must use `mraid.isViewable()` and subscribe to `viewableChange`. Call `setupMraidViewability()` from `init()` before starting media playback. React audio and media state must mirror the same state through `bindLifecycle()`.

```js
let mraidViewable = true;

function syncMediaState() {
  const media = document.querySelectorAll("video, audio");
  media.forEach(function (element) {
    if (!mraidViewable) {
      element.pause();
    } else if (element.tagName === "VIDEO" && element.autoplay) {
      element.play().catch(function () {});
    }
  });
}

function setupMraidViewability() {
  if (typeof mraid === "undefined") return;

  function handleViewableChange(viewable) {
    mraidViewable = Boolean(viewable);
    syncMediaState();
  }

  if (typeof mraid.isViewable === "function") {
    try {
      mraidViewable = Boolean(mraid.isViewable());
    } catch (error) {
      mraidViewable = true;
    }
  }

  if (typeof mraid.addEventListener === "function") {
    mraid.addEventListener("viewableChange", handleViewableChange);
  }
}
```

The media snippet illustrates viewability wiring only. Integrate it into the single lifecycle store rather than registering another `viewableChange` listener. Track detached audio pool instances through the sound hook as well as DOM media; `querySelectorAll` cannot find detached instances. Gate video resume on all visibility/exposure states, keep autoplay video muted until an authorized gameplay gesture, and catch synchronous playback throws as well as promise rejections. SFX resume remains owned by the shared audio hook and requires an active interaction.

Runtime lifecycle requirements:
- `main.tsx` must wait for DOM readiness and `initMraid()` before calling `createRoot(...).render(...)`.
- `initMraid()` must never hang startup; use timeouts for late/missing MRAID.
- Guard every MRAID method with `typeof` checks.
- Register shared `error`, `stateChange`, `exposureChange`, `viewableChange`, and `audioVolumeChange` handlers once before creative initialization. Register each readiness handler at most once for its purpose: the head helper tracks readiness, and the loading branch attaches `init` only while loading. Runtime code must reuse the head gate rather than duplicate its listeners.
- Seed cached visibility from `mraid.isViewable()` when available.
- Pause on `stateChange: "hidden"`, `exposureChange <= 0`, `viewableChange: false`, and `document.visibilitychange`; resume eligible media when all visibility/exposure gates permit it. Resume SFX only while its user interaction is still active.
- Apply `audioVolumeChange` only when the payload is a number; ignore `null`.
- `bindLifecycle()` must expose current hidden/non-exposed/audio-volume state to the app immediately once React mounts.
- Prefer a small lifecycle store plus `useSyncExternalStore`, or a focused `useMraidLifecycle()` hook, so React components can react to visibility and audio-volume changes without importing ad SDK helpers directly.
- Lifecycle, analytics, and media subscriptions must be safe if React development effects run twice. Register shared global MRAID listeners once and unsubscribe component-local listeners during cleanup.

Common MRAID validation failures:

| Message or symptom | Cause | Fix |
|---|---|---|
| Add exactly one MRAID bridge | The bridge is missing, duplicated, escaped inside generated markup, or uses an absolute URL | Keep one top-level `<script src="mraid.js"></script>` in `<head>` |
| Place readiness helpers after the bridge | Helpers are missing, renamed, placed before the bridge, or buried inside bundled app code | Put the readiness helper immediately after the bridge in `<head>` |
| Missing AppLovin loading-state guard | The condition is inverted or the ready listener is outside the guard | Use the exact `mraid.getState() === "loading"` pattern |
| Missing `mraid.open()` | Clicks use browser navigation instead of MRAID | Route the click action exclusively through guarded `mraid.open()` |
| Guard `mraid.open()` | The call is unguarded or not protected by `try/catch` | Check `window.isMraidUsable(mraid)` and wrap the call |
| Invalid click-target chain | One or more supported click variables is absent or out of order | Include all four click variables in the required order and use no non-MRAID fallback |
| Missing media viewability | A video or audio element exists without MRAID lifecycle handling | Add `isViewable()` and `viewableChange` handling |
| External resources found | The build references a CDN, remote asset, or runtime network request | Embed the asset and remove the external request |

## CTA Open
CTA support is AppLovin-only and must stay centralized in `networks.ts`.

`triggerCTA()` click-through flow:
```
1. Resolve window.clickTag || window.clickTag1 || window.clickthrough || window.clickThrough || ""
2. When MRAID is usable, try mraid.open(clickTarget) if a target exists, otherwise mraid.open(); return on success
3. If MRAID is unavailable, unusable, missing open, or throws, return without navigating
```

Requirements:
- Call `notifyGameClose()` before opening from a CTA.
- Track `CTA_CLICKED` immediately before attempting to open.
- `triggerCTA()` should call `window.handleClickAction()` when available. If absent, use the same guarded click-through flow in `networks.ts`.
- Guard MRAID opening with `typeof mraid.open === "function"` and `window.isMraidUsable(mraid)`, and wrap it in `try/catch`.
- Treat missing `mraid.getState()` as ready inside `window.isMraidUsable(mraid)`.
- Preserve all four supported click variables. Resolve them at click time in the order shown, without overwriting host-provided values.
- Pass the resolved target to `mraid.open(clickTarget)` when present; use blank `mraid.open()` only when no target is provided.
- Do not use a browser or network-specific click-through fallback. A failed or unavailable MRAID path is a safe no-op.
- Do not use `location.href`, `location.assign()`, `location.replace()`, anchor click simulation, or non-AppLovin store SDK APIs.
- Components must call the shared helper; they must not call CTA/open APIs directly.

## Lifecycle Callbacks
Expose guarded stubs on `window` so AppLovin preview tooling can detect the lifecycle surface without crashing when SDK methods are absent.

```
gameReady()  -> available after boot stubs are installed
gameStart()  -> notifyGameStart() when playable interaction starts
gameEnd()    -> notifyGameEnd() when the playable reaches its terminal state
gameClose()  -> notifyGameClose() before CTA opening or an explicit internal close action
```

All lifecycle calls must use `typeof` guards. Missing SDK callbacks are no-ops.

## Analytics
AppLovin analytics delivery is optional and must be guarded, but console logging is mandatory for every analytics event. Log each event exactly once regardless of whether `ALPlayableAnalytics` is available or succeeds, then independently attempt AppLovin delivery:

```js
function trackEvent(event) {
  console.log("[Analytics]", event);

  const analytics = window.ALPlayableAnalytics;
  if (analytics && typeof analytics.trackEvent === "function") {
    try {
      analytics.trackEvent(event);
    } catch (error) {
      console.warn("[Analytics] AppLovin delivery failed", error);
    }
  }
}
```

The console log must not be conditional on, replaced by, or suppressed by the AppLovin analytics call. Production builds must preserve these analytics `console.log` calls.

Do not use cross-network analytics fallbacks such as `playableSDK.reportEvent()`.

Suggested events:
- `LOADING`
- `LOADED`
- `DISPLAYED`
- `CHALLENGE_STARTED`
- `CHALLENGE_SOLVED`
- `ENDCARD_SHOWN`
- `CTA_CLICKED`

`CTA_CLICKED` must be emitted immediately before the shared CTA helper attempts to open through MRAID.

## Audio
Audio is optional. When present, the first real gameplay gesture must authorize audio and request the first interaction SFX synchronously; never autoplay audio or require a separate "Tap to Start" control.

All gameplay SFX must use a shared `useSound` hook owning persistent `HTMLAudioElement` instances or pools. Keep media playback, priming, retries, and cleanup inside that shared audio layer. Do not introduce Web Audio (`AudioContext`) without verifying every supported browser and ad WebView.

Required behavior:
- Import/preload every SFX and create the exact reusable instances during startup/layout, after the DOM/MRAID boot gate and before interaction. This includes endcard and delayed-cue pools, which belong in an early-mounted parent or shared hook-owned pool.
- Keep separate platform strategies: desktop uses persistent instances created during layout and silently primed on the first gameplay `pointerdown`; iOS/Android use pre-created pools with native gesture playback and pending retries. Silent priming must not replace or interrupt the immediately audible first interaction cue.
- Include iPadOS desktop-mode detection in the mobile strategy. Do not classify every touchscreen as mobile; touchscreen laptops retain the desktop path.
- Attach native capture listeners directly to the draggable/clickable element or canvas. In native `pointerdown` / `touchstart`, run the shared unlock helper first, immediately request the interaction SFX in the same synchronous event, and then begin normal drag work or pointer capture. Framework-delegated handlers alone are insufficient.
- Keep rejected playback pending on the same element and retry on native `pointermove`, `pointerup`, `touchmove`, or `touchend` while the interaction is still active. Timer-driven cues use this same pending/retry path. Never create replacement tags after rejection.
- Use pools for rapid restarts or overlap, reset `currentTime` before replay, catch thrown playback errors and promise rejections, and preserve muted state and volume while priming.
- Pause/mute on document or MRAID hidden/non-exposed/not-viewable state. Resume only when the interaction is still active and every visibility gate permits playback. Do not resume stale one-shots or ended drags.
- Apply SDK audio volume only for numeric payloads; ignore `null`.

In React projects, import assets explicitly from `src/assets/sounds/` and call the sound hook unconditionally near the top of the component. React sound registration should look like this:

```tsx
import catchSound from "./assets/sounds/catch.mp3";

const catchAudio = useSound(catchSound, {
  poolSize: 3,
  desktopPoolSize: 1,
});
```

`poolSize` controls the mobile pool. `desktopPoolSize` controls desktop and defaults to `poolSize`. Use multiple instances when a sound may overlap or be restarted quickly.

Play through shared helpers so playback always resets to the beginning:

```tsx
const source = playSound(catchAudio);
playSound(catchAudio, { volume: 0.8 });
stopSound(source);
```

### React implementation

Create a `useSound` hook that owns persistent pools. Call it unconditionally in a component mounted before the first gesture. The hook should expose:

```ts
type SoundHandle = {
  handleUnlockGesture: () => void;
  play: () => void;
  retryPending: () => void;
  stop: () => void;
};
```

Bind native listeners directly to the draggable DOM element as well as any React event handlers:

```tsx
const onPointerDown = () => {
  sliderSound.handleUnlockGesture();
  sliderSound.play();
  beginDrag();
};

element.addEventListener('pointerdown', onPointerDown, { capture: true });
element.addEventListener('pointermove', sliderSound.retryPending, { capture: true });
element.addEventListener('pointerup', sliderSound.stop, { capture: true });
```

Pre-create end-card and delayed-cue pools in the same early-mounted parent. Timer-driven playback must go through the same pending/retry helpers.

### Do not do this

- Do not create `new Audio()` inside `pointerdown`, a timeout, a component first mounted after the gesture, or an end card.
- Do not rely only on a `useEffect`, timer, delayed callback, or a global page click for first-gesture authorization.
- Do not start audio automatically on page load.
- Do not call `.play()` directly from scattered gameplay code; route it through the shared audio hook.
- Do not repeatedly call `load()` once an element is ready; it can reset media state.
- Do not replace a rejected media element with a newly created one.
- Do not use silent `play()` then immediate `pause()` as the only authorization strategy; it can create `AbortError` races and still miss the intended audible first cue.

### MRAID and visibility

For playable ads, keep MRAID lifecycle handling centralized:

- Pause/mute audio on `stateChange: hidden`, `exposureChange <= 0`, `viewableChange: false`, and `document.visibilitychange`.
- Seed viewability from `mraid.isViewable()` when available.
- Resume only if the user interaction is still active and the creative is viewable.
- Apply `audioVolumeChange` only when its value is a number.

### Verification checklist

- The very first player action can be tap-and-drag; no preliminary page tap is needed.
- Slider/scratch/drag SFX begins during that first gesture on a physical iPhone.
- Releasing then starting another drag restarts the SFX cleanly.
- Rapid or overlapping one-shot sounds stay audible when a pool is required.
- End-card/delayed SFX uses a pre-created element and produces no unhandled promise errors.
- The creative is tested in Safari/WebKit and the target ad-network preview/WebView, not only desktop Chrome.
- Build passes and the output remains self-contained and within its size cap.

### Example integration requirements

The snippets above show React gesture and pool API patterns; they are not complete hook or lifecycle implementations. Apply these requirements when integrating them:
- Import each SFX as an embedded asset and create its pool in an early-mounted hook before the first gesture. `element` is the draggable DOM element obtained through a ref; `beginDrag` and `sliderSound` represent the gameplay callback and shared sound handle.
- The React `SoundHandle` methods wrap the same shared pool as `playSound` / `stopSound`; they must not create a second audio implementation. `handleUnlockGesture()` may accept an optional event-kind argument when the platform strategy needs it.
- Direct SFX media `.play()` calls belong only inside the shared audio hook; centralized video lifecycle playback is separate. `sliderSound.play()` is the hook API, not a direct media call.
- Supply cached lifecycle state from the app wiring layer to the shared audio hook, pause active instances on hide, and gate playback/retries/resume on combined document visibility, MRAID visibility/exposure, and active interaction. Audio hooks and gameplay components must not access MRAID directly.
- Extend the native listener example with touch fallback where needed, active pointer tracking, release outside the element, `pointercancel` / `touchcancel`, and lost-capture handling. Deduplicate touch/pointer events and native/React handlers so one gesture starts audio and gameplay only once.
- The React listener example stops slider audio on release. For pending cues eligible to play on release, retry before clearing the active interaction, then stop drag loops and discard stale requests; never restart a released loop.
- Guard asynchronous playback completion with current interaction/visibility state (and a request generation when needed), so a late rejection cannot requeue stopped audio and a late resolution cannot leave hidden or ended audio playing.
- Install native listeners once with stable callbacks, remove them with matching capture options on cleanup, and pause/release pools on teardown. React effect setup/cleanup must remain safe when run twice.
- Call `load()` only when needed, such as when `readyState === HTMLMediaElement.HAVE_NOTHING`; do not repeatedly reload ready instances. Silent play followed by immediate pause must never be the sole unlock strategy.
- Preserve the desktop first-`pointerdown` contract and verify mobile retries using the exact instances primed by that gesture.

Audio verification also includes desktop Chromium and physical Android WebViews when available. Record unavailable physical-device checks as unverified; desktop emulation alone does not establish iPhone first-gesture playback.

Suggested verification commands:

```bash
npm run lint # if configured
npm run build
npm run dev
```

The local missing `mraid.js` warning is expected outside an ad container; investigate all other console errors.

## Build
Vite must output a single classic script creative:
- IIFE format.
- `modulePreload: false`.
- Inline assets through Vite imports and `assetsInlineLimit`.
- Images, fonts, media, styles, and scripts must be embedded or otherwise self-contained.
- Keep dependencies lean. React is acceptable for the playable shell, but avoid heavy UI, animation, physics, or state libraries unless they are clearly needed and the final single-file HTML remains comfortably under 5 MB.
- Remote `http://`, `https://`, protocol-relative, and WebSocket resources are blocked.
- Runtime requests such as `fetch`, XMLHttpRequest, WebSocket, `sendBeacon`, EventSource, dynamic imports, jQuery AJAX, Axios, and service workers must not call external URLs.
- Navigation is allowed only through the approved MRAID click-through path, including the resolved click target passed to `mraid.open()`.
- The relative `<script src="mraid.js"></script>` declaration is allowed because the ad host supplies it.
- Prefer `data:` URIs for embedded assets. Do not convert the MRAID bridge to a data URI.
- Strip `type="module"` and `crossorigin` from built script tags if present.
- Remove legal/license comments from built HTML and bundled JS.
- Include `<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">`.
- Preserve the AppLovin network identifier when the build/naming pipeline uses it.
- Inject exactly one `<script src="mraid.js"></script>` early in the HTML.
- Inject exactly one standard MRAID helper immediately after `mraid.js`, containing `trackMraidReadiness(mraid)`, `window.isMraidUsable(mraid)`, a literal `mraid.getState() === "loading"` guard with `mraid.addEventListener("ready", init)` inside that branch, `function handleClickAction()`, the complete four-variable click-target chain, and a try/catch guarded `mraid.open(clickTarget)` / blank `mraid.open()` path with no navigation fallback.

Expected output:
```
dist/
  index.html
```

If naming variants are needed later, keep the network segment fixed to `al`.

If built output contains unwanted `console.error` from bundled dependencies, drop it at bundle time:

```js
export default {
  esbuild: {
    legalComments: 'none',
    pure: ['console.error'],
  },
};
```

Keep `legalComments: 'none'` or an equivalent build step so `/*! ... */`, `//!`, and generated license banners do not ship in the final AppLovin HTML.

Keep project-authored error handling meaningful with visible fallback UI, `console.warn`, or guarded debug logging.

## HTTP(S) String Sanitization

Generated HTML files must not contain literal `http://` or `https://` strings anywhere, including inside bundled JavaScript, comments, metadata, or inlined assets.

Inside JavaScript string literals, preserve required runtime URL and namespace values by escaping the protocol slashes in the generated HTML:

- `http://` → `http:\x2f\x2f`
- `https://` → `https:\x2f\x2f`

Do not delete required URL or namespace strings, and do not alter their runtime values. Implement sanitization and validation in the automated build pipeline, preferably in `scripts/build-all.mjs`, after Vite has bundled and inlined the creative. This is a post-bundle stage of the normal `npm run build` command, not a manual or AI delivery-time edit. The transformation must be context-aware; do not blindly replace text where `\x2f` would change HTML, CSS, metadata, or data payload semantics. Scan every generated `.html` file for both literal protocols and fail the build if either remains. Then verify that the resulting embedded JavaScript still parses and the playable still runs.

## Asset Loading
- Critical image assets should be imported and ready for the first visible frame.
- Imported image URLs may still decode after React renders. Gate the first playable screen on critical `Image.decode()` or `onload` completion when a missing first-frame asset would be visible.
- Defer noncritical overlays and secondary UI when useful. Pre-create and preload all SFX pools, including endcard and delayed cues, before the first gameplay gesture.
- Gameplay should not start until required assets are ready.
- Do not reference raw external asset paths from `index.html`; import assets through JS/TS so Vite can inline them.

## Z-Index Map
Define z-indexes as named constants in `src/constants.ts`. Do not use magic numbers in component code.

| Layer | Z-index |
|---|---:|
| Background | 0 |
| Game objects | 1-10 |
| Logo / HUD | 17 |
| Dim overlay | 20 |
| Result UI | 21 |
| Input blocker / top UI | 25 |
| DOM CTA click layer | 30 |

## Ship Checklist
- [ ] AppLovin only.
- [ ] CTA open uses `triggerCTA()`.
- [ ] All four click variables resolve in order: `clickTag`, `clickTag1`, `clickthrough`, `clickThrough`. The primary CTA uses guarded `mraid.open(clickTarget)` when a target exists and blank `mraid.open()` otherwise.
- [ ] No direct CTA/open calls from components.
- [ ] `mraid.js` injected exactly once.
- [ ] `trackMraidReadiness(mraid)`, `window.isMraidUsable(mraid)`, and `handleClickAction()` are present in `<head>` immediately after `mraid.js`.
- [ ] MRAID init awaited before React mount; startup waits for `ready` when state is `loading`, `init()` is idempotent, and the startup guard self-resolves on timeout.
- [ ] MRAID `error`, `stateChange`, `exposureChange`, `viewableChange`, and `audioVolumeChange` listeners registered early.
- [ ] MRAID opening is inside `try/catch`; unavailable, unusable, missing, or throwing MRAID returns without navigation, and no browser or network-specific fallback exists.
- [ ] Every analytics event is logged exactly once with `console.log("[Analytics]", event)` whether AppLovin analytics is enabled, disabled, missing, or throwing.
- [ ] Builds with media use `isViewable()` and `viewableChange` to pause/resume media; `setupMraidViewability()` runs from `init()` before playback.
- [ ] Responsive portrait and landscape pass.
- [ ] Layout responds to viewport and DPR changes.
- [ ] Only one React root.
- [ ] Frame-hot animation and pointer movement avoid React state churn.
- [ ] Root/app CSS prevents scroll, selection, browser gestures, and viewport bounce during gameplay.
- [ ] All SFX pools, including endcard/delayed cues, are imported/preloaded before interaction and use one shared audio hook. Native capture unlock and the first audible cue run synchronously on the actual gameplay gesture; pending requests retry on the same elements only during active interaction.
- [ ] Audio pauses on hidden/non-viewable state, resumes only for active interactions when viewable, and cleans up on release/cancel. First-drag sound, clean restart, overlapping cues, and delayed cues are verified in Safari/WebKit and the target ad WebView, including physical iPhone testing when available.
- [ ] `dist/index.html` is 5 MB or smaller and all creative assets are self-contained.
- [ ] No `type="module"` or `crossorigin` in output script tags.
- [ ] No legal/license comments or generated comment banners in built output.
- [ ] The automated build pipeline sanitizes and validates final HTML after bundling/inlining; it fails if any generated HTML contains a literal `http://` or `https://`, while required JavaScript string values use escaped protocol slashes and remain valid at runtime.
- [ ] No unsupported inline config output.

## Endcard Video Scaling
- Endcards may use separate portrait and landscape video assets. Pick the video source from the current responsive orientation.
- Preserve the video's authored aspect ratio: use `16 / 9` for landscape and `9 / 16` for portrait.
- The endcard CTA button must remain `position: fixed` and cover the full viewport, but the video itself may be centered inside that button when needed.
- Fill the viewport exactly when its aspect ratio matches the selected video. For other normal mobile ratios, preserve the source aspect ratio with centered cover cropping. For extra-wide or extra-tall viewports, compute a centered contained video box from the selected source ratio to avoid stretching or excessive cropping; the CTA still covers the viewport.
- Recompute the video box from `visualViewport`/responsive viewport dimensions on resize, orientation change, and DPR settle updates.

## Pitfalls
| Issue | Fix |
|---|---|
| Rotation stuck | Poll `visualViewport`, update responsive state/CSS variables, then let components re-render or consume updated layout values. |
| Mobile aliasing | Use appropriately sized raster assets and responsive CSS dimensions; avoid scaling tiny images far beyond source size. |
| FPS drop on resize | Debounce with `requestAnimationFrame` and avoid recreating heavy elements during relayout. |
| Janky drag gameplay | Keep drag positions in refs and apply `transform` in `requestAnimationFrame`; use React state only for durable game state. |
| Effects fire twice in local dev | Make setup idempotent and avoid production ad builds that wrap the app in React `StrictMode`. |
| MRAID crash | Guard `window.mraid` and every optional method with `typeof`. |
| MRAID ready missed | Check `getState()` first, listen for `ready` only when loading, and self-resolve after about 2 seconds. |
| Late MRAID injection | Poll briefly, about 500 ms, before concluding MRAID is absent. |
| MRAID listener wired too late | Call `initMraid()` before React mounts and register callbacks before app components run. |
| Audio keeps playing when hidden | Pause/mute on MRAID hidden or zero exposure, and also handle `document.visibilitychange`. |
| iPhone black screen | Create only one React root; avoid synchronous module-load app mount before DOM and MRAID gates. |
| Root element missing | Create or locate the app container in `boot()` before calling `createRoot(...)`. |
| External asset path survives build | Import assets from JS/TS; do not put raw `src/assets/...` paths in `index.html`. |
| CTA logic scattered | Keep open calls in the required head helper and the equivalent guarded MRAID-only path in `networks.ts`; components invoke the app callback wired to `triggerCTA()`. |
| Unsafe CTA API | Do not use `location.href`, `location.assign()`, `location.replace()`, anchor click simulation, or non-AppLovin store SDK APIs. |
| Click-chain validation failure | Keep `handleClickAction()`, all four click variables in order, and guarded `mraid.open(clickTarget)` / blank `mraid.open()` in the head helper; do not add another navigation path. |
| First SFX blocked | Pre-create exact audio instances, unlock and request the audible cue synchronously from native capture on the gameplay element, and retry rejected requests on those same instances during the active interaction. |
| Endcard CTA click area does not match visible playable frame | Use an explicit DOM `button` for whole-screen endcard CTA state, styled with `position: fixed; inset: 0; width: 100%; height: 100%; z-index` above the app, and call the project CTA helper from its `click` handler. Remove the DOM layer when the endcard is destroyed or hidden. |
