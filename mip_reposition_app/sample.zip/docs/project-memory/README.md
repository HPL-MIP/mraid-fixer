# Preserved Project Memory

This directory retains reusable guidance and historical implementation notes copied from `SFX-FIX-TEST-TASK`. It is documentation only and is not imported by the active Match 2 template build.

## Authority

1. Direct task instructions take priority.
2. The root `AGENTS.md` defines the active project's rules.
3. The guides here provide reusable techniques and historical context.
4. Archived project-specific sections should be reactivated only when deliberately restoring that project or mechanic.

## Archive map

- `AGENTS.multi-project-archive.md`: the complete former workspace instructions, including reusable web-build rules and project-specific lessons.
- `AGENTS.updated-archive.md`: an earlier consolidated instruction snapshot.
- `AGENTS.sfx-lab-archive.md`: the SFX interaction lab's active instruction snapshot at the time of import.
- `SFX-FIX-TEST-TASK.README.md`: the source lab's flow, commands, and documentation map.
- `IMPORT_NOTES.md`: what was adopted, what remains historical, and the workflow for future reskins.
- `guides/AUDIO_GUIDELINES.md`: general playable audio preparation and runtime practices.
- `guides/IOS_SFX_PLAYABLE_GUIDE.md`: original iOS SFX workflow.
- `guides/IOS_SFX_PLAYABLE_GUIDE.updated.md`: later iOS SFX guidance; prefer this when it conflicts with the original.
- `guides/REUSABLE_IOS_SFX_IMPLEMENTATION.md`: reusable controller and gesture-unlock patterns.
- `guides/MRAID_IMPLEMENTATION_GUIDE.md`: MRAID readiness, lifecycle, viewability, volume, and CTA patterns.
- `guides/DYNAMIC_DEVICE_IMPLEMENTATION_GUIDE.md`: responsive viewport and device-layout practices.
- `guides/APPLOVIN_HTML_OUTPUT_GUIDE.md`: AppLovin single-file output and validation practices.
- `guides/SFX_INTERACTION_LAB_TEMPLATE_GUIDELINES.md`: source-lab behavior and extension rules; examples refer to that lab and must be adapted to this project.
- `guides/PORTABLE_IOS_SAFE_SFX_IMPLEMENTATION.md`: the source-lab portable implementation and audit workflow.

## Retained reusable assets

The previous workspace's reusable sound and font libraries are available under `Assets/audio/` and `Assets/fonts/`. The active runtime continues to use only project-owned, explicitly imported files under `src/assets/`.

Treat `Assets/` as an opt-in source library: copy only selected files into `src/assets/`, validate licensing and compression, import them through the bundler, and verify the resulting single-file build size. See `Assets/README.md` for the inventory and reuse workflow.
