# SFX Lab Memory Import Notes

Imported from `C:\Users\jfajardo\Documents\GitHub\SFX-FIX-TEST-TASK` for use by this repository as a reusable AppLovin playable template.

## Adopted into the active template workflow

- Preserve reusable knowledge in `docs/project-memory/`, with the root `AGENTS.md` as the active authority.
- Keep reusable source assets outside the runtime tree and copy only selected assets into `src/assets/`.
- Create persistent audio pools before interaction and keep cue configuration in one typed manifest.
- Bind first-cue playback and retry work to native capture-phase input on the actual gameplay element.
- Keep per-voice pending, in-flight, primed, generation, interaction, and lifecycle state.
- Connect audio to document visibility and centralized MRAID state/volume.
- Treat automated Chromium checks as architectural regression coverage, not proof of physical iOS behavior.
- Require typecheck, regression tests, single-file build validation, size validation, and physical-device QA records.

The current project already implements these principles with a newer controller, input-ownership layer, Base64 byte validation, and exact AppLovin MRAID helper checks. The imported documents supplement that implementation; they do not replace it.

## Preserved as historical or project-specific reference

- The source lab's seven-card scrollable test flow and two-stage CTA/video sequence.
- Dynamic-device/date examples from earlier campaigns.
- Archived brand/project notes and their cue assignments.
- Older controller snippets, pool recommendations, and MRAID variants where the active root specification is stricter.
- Examples that import directly from `Assets/`; this template instead stages selected runtime files under `src/assets/` so validation and ownership stay explicit.

Do not reactivate these behaviors unless the new playable actually needs them.

## Future reskin workflow

1. Read the root `AGENTS.md` and the task-relevant guide in this directory.
2. Inventory the current gameplay, cues, input paths, lifecycle wiring, CTA behavior, and output validator before editing.
3. Select the smallest necessary set from `Assets/`; verify redistribution rights and compression.
4. Copy selected files to `src/assets/sounds/` or `src/assets/fonts/` and import them through the bundler.
5. Update the typed manifest and wire native input without changing unrelated game timing or CTA behavior.
6. Add regression coverage for any new immediate, release, delayed, looping, overlapping, or resumable behavior.
7. Run `npm run typecheck`, `npm test`, and `npm run build`.
8. Inspect the final single-file HTML and record unavailable physical iOS/AppLovin checks as unverified rather than inferred.

## Known asset-library limitation

Only `Assets/fonts/geist/OFL.txt` arrived with explicit font-license documentation. Other font files are retained for continuity, but must not be assumed redistributable until their original licenses are confirmed.
