# Reusable iOS-safe SFX implementation

For the active EllaOla MIP 12/16 builds, use `src/hooks/ReferenceSfxController.ts` and its tests in `Scripts/test-reference-sfx.mjs`. This controller ports the supplied reference MIP's two-voice HTML audio pools. The older `useSound.ts` notes below document the previous template implementation and are retained for archived projects.

This document records the working DOM audio implementation in this repository so it can be carried into future AppLovin projects without reintroducing first-gesture failures.

## Source of truth

- Runtime controller: `src/hooks/useSound.ts`
- Native press ordering: `src/features/PressActivation.ts`
- Canonical cues: `Assets/audio/shared/`
- Regression checks: `Scripts/test-sound.mjs`
- MRAID visibility and volume bridge: `src/networks.ts`

The current implementation uses persistent `HTMLAudioElement` pools. It does not use React, Web Audio, dynamically created handler-time media, or audible autoplay.

## Bootstrap contract

Call `useSound()` for every cue before the experience accepts input. Construction allocates the exact media elements, sets `preload='auto'` and `playsinline`, assigns the configured volume scale, and calls `load()` once.

Current pool sizes:

| Cue | Mobile voices | Desktop voices | Resume after hidden |
|---|---:|---:|---|
| Tap | 3 | 1 | No |
| CTA Part 1 | 1 | 1 | Yes when it was active |
| CTA Part 2 | 1 | 1 | Yes when it was active |

Do not allocate replacement voices after a rejection. iOS authorization belongs to the media element that received the real gesture.

## Accepted gesture sequence

For a pointer-driven button, the exact order is:

```text
native capture pointerdown
  -> playSoundFromGesture(tapHandle, 'pointerdown')
     -> prime deferred handles, excluding tapHandle
     -> play the tap voice directly in the same gesture
  -> later click validates and commits the UI action
```

The binder remembers that sound was already requested, so the compatibility click does not play a duplicate. `pointermove` and `pointerup` retry only pending requests. `pointercancel` cancels the pending tap and never commits the UI action.

Enter and Space use `keydown` for the synchronous unlock/sound request and the browser-generated click for one activation.

## Exact-element priming

On an allowed gesture, each unprimed idle deferred voice is briefly played muted and paused synchronously. The active tap handle is excluded from that pass so its selected voice is not muted and paused immediately before the audible request. Before priming, each deferred voice's current mute and volume are captured; after the immediate pause/reset, both values are restored.

Every voice has a generation counter. A play, stop, cancellation, pause, or reuse advances that generation. Promise callbacks check the captured generation before changing flags, preventing an obsolete prime rejection from modifying a voice that has already been reused for a real cue. Priming promise continuations never start audible media.

## Pending playback

An audible `play()` rejection marks that same voice pending. Continued native gesture events call `retryPending()` through the shared unlock helper. A pending request expires after 750 ms, after which the voice is stopped and reset. Scene exits and canceled interactions call `cancelPending()` immediately.

One-shot replay always pauses and resets `currentTime` before requesting playback. Pool selection prefers an idle non-pending voice and otherwise rotates through the existing pool.

## Visibility and MRAID

`bindLifecycle()` combines `document.hidden` with cached MRAID visibility. `stateChange: hidden` is an explicit pause override; `exposureChange` becomes authoritative after its first finite value, while `viewableChange` remains the MRAID 2 fallback.

On pause, active voices are muted and paused. Tap audio has `resumeAfterPause: false`, so a canceled or interrupted press cannot resume. CTA cues may resume only if they were intentionally playing. `audioVolumeChange` accepts finite numbers, clamps them to 0-100, and ignores `null`, `NaN`, infinities, and strings.

## Reuse checklist

- Copy `src/hooks/useSound.ts` and its sound tests without weakening the generation checks.
- Keep canonical 96 kbps mono cues under `Assets/audio/shared/`.
- Allocate every handle at bootstrap, never in input callbacks or timers.
- Bind native capture listeners to the actual pressed or dragged element.
- Unlock first, request the immediate cue second, mutate interaction state last.
- Retry only the pending voice during an active gesture and cancel on every terminal path.
- Route all browser/MRAID pause and volume changes to every handle.
- Keep iPadOS MacIntel/touch detection and the desktop pointerdown path.
- Run `npm run test:sound` and `npm run test:mraid`.
- Verify first-action sound on physical iOS Safari and the target AppLovin WebView.

The physical-device check is mandatory for final confidence: Node mocks and desktop WebKit can validate logic but cannot reproduce every ad-host media authorization policy.
