# Dynamic Device (DD) Implementation Guide

This guide provides step-by-step instructions and reusable code snippets for implementing **Dynamic Device Detection** in SIP HTML playable ads and landing pages.

---

## Table of Contents
1. [Overview](#overview)
2. [Method 1: Dynamic Date Token Replacement (Recommended)](#method-1-dynamic-date-token-replacement-recommended)
3. [Method 2: Standalone `#sip-device` Element Overlay](#method-2-standalone-sip-device-element-overlay)
4. [Device Detection Logic Breakdown](#device-detection-logic-breakdown)
5. [File Naming Convention](#file-naming-convention)
6. [Testing & Verification](#testing--verification)

---

## Overview

The Dynamic Device feature detects the user's operating system/platform via `navigator.userAgent` and dynamically injects the appropriate audience label into the ad creative:

| Platform / Device | Detected Label |
| :--- | :--- |
| **iPhone / iPad / iPod / iPadOS** | `"iOS users"` |
| **Android Phone / Tablet** | `"Android users"` |
| **Windows PC** | `"Windows users"` |
| **Mac / macOS** | `"MacOS users"` |
| **Linux / X11** | `"Linux users"` |
| **Unknown / Fallback** | `"Dynamic device"` |

---

## Method 1: Dynamic Date Token Replacement (Recommended)

This method dynamically injects the detected device string into the existing dynamic date overlay (`dateTokens`), replacing standard date text with personalized copy (e.g. `Special Offer For iOS users`).

### Step 1: Insert the Dynamic Device JS Block
In your HTML file, locate the `// --- Dynamic date overlay (injected by builder) ---` section inside the `<script>` tag. Insert the following code block directly below `datePositionPortrait` / `datePositionLandscape`:

```javascript
      // <Dynamic Device>
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
      const isAndroid = /Android/i.test(navigator.userAgent);
      if (isIOS) {
        datePositionPortrait.y = 0.1935; // Adjust Y coordinate for iOS portrait if needed
        datePositionLandscape.y = 0.5434; // Adjust Y coordinate for iOS landscape if needed
      } else if (isAndroid) {
        datePositionPortrait.y = 0.1935; // Adjust Y coordinate for Android portrait if needed
        datePositionLandscape.y = 0.5434; // Adjust Y coordinate for Android landscape if needed
      }

      function detectDeviceBrand() {
        if (typeof navigator === "undefined") return "Dynamic device";
        var ua = (navigator.userAgent || "") + " " + (navigator.appVersion || "") + " " + (navigator.vendor || "");
        var maxTouch = navigator.maxTouchPoints || 0;

        if (/iPad|iPhone|iPod/.test(ua) || (/MacIntel|Macintosh/.test(ua) && maxTouch > 1)) {
          return "iOS users";
        }

        if (/Android/i.test(ua)) {
          return "Android users";
        }

        if (/Windows|Win32|Win64|WOW64/i.test(ua)) {
          return "Windows users";
        }

        if (/Macintosh|Mac OS X|MacPPC|MacIntel/i.test(ua)) {
          return "MacOS users";
        }

        if (/Linux|X11/i.test(ua)) {
          return "Linux users";
        }

        return "Dynamic device";
      }

      var userDeviceBrand = detectDeviceBrand();
      // </Dynamic Device>
```

### Step 2: Update `dateTokens`
Update the `dateTokens` declaration to use template literals containing `${userDeviceBrand}`:

```javascript
      // Example 1: Special Offer For [Device]
      const dateTokens = `[Special Offer For ${userDeviceBrand}]`;

      // Example 2: For [Device]
      // const dateTokens = `[For ${userDeviceBrand}]`;

      // Example 3: Exclusively For [Device]
      // const dateTokens = `[Exclusively For ${userDeviceBrand}]`;
```

---

## Method 2: Standalone `#sip-device` Element Overlay

Use this method when you want a dedicated text overlay element rendered separately from the date element.

### 1. HTML Markup
Add the `<div id="sip-device"></div>` inside `#video-container`:

```html
<div id="video-container">
  <video id="sip-video" preload="none" autoplay muted loop playsinline>
    <source id="sip-video-source" src="" type="video/mp4" />
  </video>
  <div id="sip-date"></div>
  <div id="sip-device"></div>
</div>
```

### 2. CSS Styling
Add the CSS rule inside `<style>`:

```css
#sip-device {
  position: absolute;
  left: 0;
  top: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  white-space: pre;
  pointer-events: none;
  z-index: 2;
  transform-origin: center center;
  box-sizing: content-box;
  color: #333333;
  font-weight: 500;
  text-align: center;
  letter-spacing: 0.01em;
}
```

### 3. JavaScript Positioning inside `updateDynamicDatePosition()`
Add the following block inside `updateDynamicDatePosition()`:

```javascript
  const deviceEl = document.getElementById("sip-device");
  if (deviceEl) {
    deviceEl.textContent = userDeviceBrand;
    const deviceFontSize = Math.max(7, renderedVideoH * (isPortraitViewport ? 0.022 : 0.03));
    deviceEl.style.fontSize = deviceFontSize + "px";

    const rawDeviceLeft = anchor.x === "centerX"
      ? (boxW / 2 - deviceEl.offsetWidth / 2)
      : (offsetX + anchor.x * iw * scale - deviceEl.offsetWidth / 2);
    const deviceLeft = Math.max(0, Math.min(rawDeviceLeft, boxW - deviceEl.offsetWidth));
    const deviceTop = top + dateEl.offsetHeight + (isPortraitViewport ? (renderedVideoH * 0.001) : (renderedVideoH * 0.001));

    deviceEl.style.left = deviceLeft + "px";
    deviceEl.style.top = (deviceTop + dateInkOffsetY) + "px";
    deviceEl.style.transform = "rotate(" + currentDateRotation + "deg)";
  }
```

---

## Device Detection Logic Breakdown

- **iPadOS / iOS Detection**:
  ```javascript
  /iPad|iPhone|iPod/.test(ua) || (/MacIntel|Macintosh/.test(ua) && maxTouch > 1)
  ```
  *Note*: Modern iPads report `Macintosh` / `MacIntel` in `navigator.userAgent`. Checking `navigator.maxTouchPoints > 1` ensures iPadOS devices are accurately classified as `"iOS users"`.

- **Android Detection**:
  ```javascript
  /Android/i.test(ua)
  ```

- **Desktop OS Detection**:
  - Windows: `/Windows|Win32|Win64|WOW64/i.test(ua)`
  - MacOS: `/Macintosh|Mac OS X|MacPPC|MacIntel/i.test(ua)`
  - Linux: `/Linux|X11/i.test(ua)`

---

## File Naming Convention

When converting a Dynamic Text (`_dt_`) creative to Dynamic Device (`_dd_`):

- **Original**: `..._dt_none.html` (Dynamic Text)
- **Updated**: `..._dd_none.html` (Dynamic Device)

*Example*:
- `homebitz_acslanot_sip_20260827_09_emily_product_card_human_dt_none.html`
- ➔ `homebitz_acslanot_sip_20260827_10_emily_product_card_human_dd_none.html`

---

## Testing & Verification

1. **Chrome DevTools Emulation**:
   - Open Developer Tools (`F12` or `Ctrl+Shift+I`).
   - Toggle Device Toolbar (`Ctrl+Shift+M`).
   - Select **iPhone 14 / iPad Pro** ➔ Verify text displays `... iOS users`.
   - Select **Samsung Galaxy / Pixel** ➔ Verify text displays `... Android users`.
2. **Network / User Agent Override**:
   - Open DevTools ➔ More Tools ➔ **Network conditions**.
   - Uncheck *Use browser default* under **User agent**.
   - Select custom user agents (Windows, macOS, Android, iPhone) to test each condition.
