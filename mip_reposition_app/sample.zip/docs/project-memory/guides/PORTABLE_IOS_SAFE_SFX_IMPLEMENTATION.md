# Portable iOS-Safe SFX Implementation Guide

> Copy this file into the root of any web, playable-ad, React, DOM, or Phaser project. Then tell Codex: **“Read `IOS_SAFE_SFX_IMPLEMENTATION_GUIDE.md` completely and implement its iOS-safe SFX system in this project. Preserve the project’s existing interaction behavior and adapt the guide to its stack.”**

## Instructions for Codex

Read this entire file before editing the target project. Treat it as an implementation specification, not general advice.

When asked to install this system:

1. Read the target repository’s `AGENTS.md` and package scripts first.
2. Inspect its current audio code, interaction handlers, lifecycle code, CTA behavior, assets, and build output.
3. Preserve project-specific timing, visuals, cue choices, CTA rules, and analytics unless the user asks to change them.
4. Reuse or adapt the controller in this document. Do not replace it with a one-flag “audio unlocked” helper.
5. Keep all runtime audio inside the target project’s normal asset directory and import it through the bundler.
6. Wire the audible request directly to native user gestures as described below.
7. Add lifecycle integration, automated regression tests, and a physical-iOS QA checklist.
8. Run the target project’s typecheck, tests, build, and final-output validation.
9. Report the files changed, the behavior implemented, test results, and anything that still requires a physical iPhone/AppLovin check.

Do not blindly replace a target project’s working MRAID, CTA, analytics, or game-state implementation. Integrate the audio controller into those systems. If the project already has a more complete lifecycle adapter, preserve it and connect `setPaused()` and `setMasterVolume()` to it.

---

## Goal

This system makes short sound effects, overlapping taps, swipe-release sounds, looping scratch cues, delayed sounds, completion sounds, and longer CTA cues as reliable as practical in iOS Safari, WKWebView, and AppLovin/MRAID containers while also working on Android and desktop.

It uses persistent `HTMLAudioElement` pools because iOS media permission is associated with real media elements and synchronous user activation. It deliberately avoids creating audio elements when a delayed action fires.

The implementation guarantees the following:

- Every audio element exists before the first interaction.
- The sound the user expects is requested first inside the native gesture.
- The other exact persistent elements are silently primed during that gesture.
- Rapid cues can overlap through small persistent voice pools.
- A rejected play is retried on the same element during the next native gesture.
- Stale rejected UI sounds expire instead of playing much later.
- Old asynchronous prime completions cannot stop or mute newer real playback.
- Short sounds cancel when the creative becomes hidden.
- Configured long CTA/narration sounds can resume when visible again.
- MRAID volume, exposure, viewability, and document visibility are honored.
- A cue can play only a clean segment of a longer source file.
- Drag surfaces preserve vertical mobile scrolling.

No browser can guarantee sound when the OS is muted, the host volume is zero, the ad is hidden, or the container rejects playback. The controller must fail safely in those cases.

---

## Why simpler implementations fail on iOS

These patterns are not sufficient:

- Creating `new Audio()` inside a timeout, animation callback, promise continuation, or completion handler.
- Calling `play()` only from React `onClick` after state work has occurred.
- Priming one temporary audio element and assuming all future elements are unlocked.
- Keeping only a global `audioUnlocked = true` flag.
- Replacing a pool voice while the experience is running.
- Catching a rejected `play()` promise and discarding it without a bounded retry.
- Running `audio.play()` after an awaited operation and expecting the original user activation to remain valid.
- Letting a stale muted-prime promise call `pause()` after real playback has reused the same element.
- Allowing a full-width scratch/drag surface to use `touch-action: none`, trapping mobile page scrolling.

The critical rule is:

> Request the intended audible sound synchronously from the native gesture on a persistent audio element. Prime other persistent elements only after that request.

---

## Recommended file layout

Adapt paths to the target repository, but keep the responsibilities separate:

```text
src/
  audio/
    SfxController.ts       # Framework-independent persistent audio pools
    sfxManifest.ts         # Typed cue names, sources, volume, pools, policies
  networks.ts              # Existing MRAID/lifecycle integration
  App.tsx or main.ts       # Creates controller and wires interactions
Assets/
  audio/
    project-name/
      tap.mp3
      swipe.mp3
      scratch.mp3
      complete.mp3
scripts/
  test-sound.mjs           # Controller regression tests
```

Audio recommendations for single-file playable builds:

- Use short MP3 files, normally mono at 96 kbps.
- Trim silence and unused tails before bundling.
- Keep cue URLs in one manifest.
- Import URLs from TypeScript/JavaScript so the single-file bundler inlines them.
- Do not leave runtime-relative `<audio src="...">` paths in raw HTML.
- Do not base64-encode assets manually when the existing bundler already handles imports.

---

## Canonical controller

Create `src/audio/SfxController.ts` with this implementation. It is framework-independent and is the core of the fix.

```ts
export type SfxPausePolicy = "cancel" | "resume";

export type SfxCueConfig = {
  src: string;
  volume?: number;
  poolSize?: number;
  loop?: boolean;
  pausePolicy?: SfxPausePolicy;
  startAt?: number;
  endAt?: number;
};

export type SfxPlayOptions = {
  loop?: boolean;
  restart?: boolean;
  volume?: number;
  startAt?: number;
  endAt?: number;
};

type ResolvedPlayOptions = {
  loop: boolean;
  restart: boolean;
  volume: number;
  startAt: number;
  endAt: number;
};

type Voice = {
  element: HTMLAudioElement;
  generation: number;
  primed: boolean;
  pending: boolean;
  pendingAt: number;
  inFlight: boolean;
  intendedPlaying: boolean;
  resumeOnVisible: boolean;
  options: ResolvedPlayOptions;
};

type Cue = {
  config: Required<Omit<SfxCueConfig, "src">> & Pick<SfxCueConfig, "src">;
  voices: Voice[];
  cursor: number;
};

const PENDING_LIFETIME_MS = 900;

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value));
}

export class SfxController<Key extends string> {
  private readonly cues = new Map<Key, Cue>();
  private masterVolume = 1;
  private paused = false;
  private destroyed = false;

  constructor(manifest: Record<Key, SfxCueConfig>) {
    for (const key of Object.keys(manifest) as Key[]) {
      const input = manifest[key];
      const config: Cue["config"] = {
        src: input.src,
        volume: clamp01(input.volume ?? 1),
        poolSize: Math.max(1, Math.floor(input.poolSize ?? 1)),
        loop: input.loop ?? false,
        pausePolicy: input.pausePolicy ?? "cancel",
        startAt: Math.max(0, input.startAt ?? 0),
        endAt: input.endAt == null ? Number.POSITIVE_INFINITY : Math.max(0, input.endAt),
      };

      const voices: Voice[] = [];
      for (let index = 0; index < config.poolSize; index += 1) {
        const element = new Audio(config.src);
        element.preload = "auto";
        element.setAttribute("playsinline", "");
        element.setAttribute("webkit-playsinline", "");

        const voice: Voice = {
          element,
          generation: 0,
          primed: false,
          pending: false,
          pendingAt: 0,
          inFlight: false,
          intendedPlaying: false,
          resumeOnVisible: false,
          options: {
            loop: config.loop,
            restart: true,
            volume: 1,
            startAt: config.startAt,
            endAt: config.endAt,
          },
        };

        element.addEventListener("ended", () => {
          if (voice.element.loop && voice.intendedPlaying) return;
          voice.intendedPlaying = false;
          voice.pending = false;
          voice.inFlight = false;
          voice.resumeOnVisible = false;
        });

        element.addEventListener("timeupdate", () => {
          if (
            voice.intendedPlaying &&
            Number.isFinite(voice.options.endAt) &&
            element.currentTime >= voice.options.endAt
          ) {
            this.stopVoice(voice);
          }
        });

        voices.push(voice);
        try {
          element.load();
        } catch {
          // Metadata loading is best effort in WebViews.
        }
      }

      this.cues.set(key, { config, voices, cursor: 0 });
    }
  }

  playFromGesture(key: Key, options: SfxPlayOptions = {}): HTMLAudioElement | null {
    const activeElement = this.play(key, options);
    this.primeFromGesture(key, activeElement);
    this.retryPending(activeElement);
    return activeElement;
  }

  primeFromGesture(preferredKey?: Key, activeElement: HTMLAudioElement | null = null): void {
    if (this.destroyed || this.paused || document.hidden) return;
    if (preferredKey) this.primeCue(preferredKey, activeElement);
    for (const [key] of this.cues) {
      if (key !== preferredKey) this.primeCue(key, activeElement);
    }
  }

  private primeCue(key: Key, activeElement: HTMLAudioElement | null): void {
    const cue = this.cues.get(key);
    if (!cue) return;
    for (const voice of cue.voices) {
      if (
        voice.element !== activeElement &&
        !voice.primed &&
        !voice.pending &&
        !voice.inFlight &&
        !voice.intendedPlaying &&
        voice.element.paused
      ) {
        this.primeVoice(voice);
      }
    }
  }

  private primeVoice(voice: Voice): void {
    const { element } = voice;
    const previousMuted = element.muted;
    const previousVolume = element.volume;
    const generation = ++voice.generation;
    voice.inFlight = true;

    const settle = (primed: boolean): void => {
      if (voice.generation !== generation || this.destroyed || voice.intendedPlaying) return;
      voice.inFlight = false;
      voice.primed = primed;
      try { element.pause(); } catch { /* Best effort. */ }
      try { element.currentTime = 0; } catch { /* Metadata may not be ready. */ }
      try { element.muted = previousMuted; } catch { /* Best effort. */ }
      try { element.volume = previousVolume; } catch { /* Best effort. */ }
    };

    try {
      element.muted = true;
      element.volume = 0;
      if (element.readyState === HTMLMediaElement.HAVE_NOTHING) element.load();
      const request = element.play();
      if (request) void request.then(() => settle(true), () => settle(false));
      else settle(true);
    } catch {
      settle(false);
    }
  }

  play(key: Key, options: SfxPlayOptions = {}): HTMLAudioElement | null {
    if (this.destroyed || this.paused || document.hidden) return null;
    const cue = this.cues.get(key);
    if (!cue) return null;

    let selectedIndex = cue.cursor;
    for (let offset = 0; offset < cue.voices.length; offset += 1) {
      const index = (cue.cursor + offset) % cue.voices.length;
      const candidate = cue.voices[index];
      if (!candidate.intendedPlaying && !candidate.pending && !candidate.inFlight) {
        selectedIndex = index;
        break;
      }
    }

    const voice = cue.voices[selectedIndex];
    cue.cursor = (selectedIndex + 1) % cue.voices.length;
    this.stopVoice(voice);
    voice.options = {
      loop: options.loop ?? cue.config.loop,
      restart: options.restart ?? true,
      volume: clamp01(options.volume ?? 1),
      startAt: Math.max(0, options.startAt ?? cue.config.startAt),
      endAt: options.endAt == null ? cue.config.endAt : Math.max(0, options.endAt),
    };
    voice.intendedPlaying = true;
    voice.pendingAt = performance.now();
    this.applyVoiceSettings(cue, voice);
    this.requestPlayback(cue, voice, voice.options.restart);
    return voice.element;
  }

  private requestPlayback(cue: Cue, voice: Voice, restart: boolean): void {
    if (this.destroyed || this.paused || document.hidden || !voice.intendedPlaying) return;
    const generation = ++voice.generation;
    voice.pending = false;
    voice.inFlight = true;
    voice.resumeOnVisible = false;
    this.applyVoiceSettings(cue, voice);

    const rejected = (): void => {
      if (voice.generation !== generation || this.destroyed || this.paused) return;
      voice.inFlight = false;
      voice.pending = voice.intendedPlaying;
    };

    if (restart) {
      try { voice.element.currentTime = voice.options.startAt; } catch { /* Metadata may not be ready. */ }
    }

    try {
      const request = voice.element.play();
      if (request) {
        void request.then(() => {
          if (voice.generation !== generation || this.destroyed) return;
          voice.inFlight = false;
          voice.pending = false;
          voice.primed = true;
        }, rejected);
      } else {
        voice.inFlight = false;
        voice.pending = false;
        voice.primed = true;
      }
    } catch {
      rejected();
    }
  }

  retryPending(excludedElement: HTMLAudioElement | null = null): void {
    if (this.destroyed || this.paused || document.hidden) return;
    const now = performance.now();
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (!voice.pending || voice.element === excludedElement) continue;
        if (now - voice.pendingAt > PENDING_LIFETIME_MS) {
          this.stopVoice(voice);
          continue;
        }
        this.requestPlayback(cue, voice, true);
      }
    }
  }

  stop(key: Key): void {
    const cue = this.cues.get(key);
    if (!cue) return;
    for (const voice of cue.voices) this.stopVoice(voice);
  }

  private stopVoice(voice: Voice): void {
    voice.generation += 1;
    voice.pending = false;
    voice.inFlight = false;
    voice.intendedPlaying = false;
    voice.resumeOnVisible = false;
    try { voice.element.pause(); } catch { /* Best effort. */ }
    try { voice.element.currentTime = 0; } catch { /* Metadata may not be ready. */ }
  }

  private applyVoiceSettings(cue: Cue, voice: Voice): void {
    voice.element.loop = voice.options.loop;
    voice.element.muted = this.paused || this.masterVolume <= 0;
    voice.element.volume = clamp01(
      cue.config.volume * voice.options.volume * this.masterVolume,
    );
  }

  setMasterVolume(scale: number): void {
    if (!Number.isFinite(scale)) return;
    this.masterVolume = clamp01(scale);
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) this.applyVoiceSettings(cue, voice);
    }
  }

  setPaused(paused: boolean): void {
    if (this.destroyed || this.paused === paused) return;
    this.paused = paused;

    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (paused) {
          if (cue.config.pausePolicy === "resume" && voice.intendedPlaying) {
            voice.generation += 1;
            voice.pending = false;
            voice.inFlight = false;
            voice.resumeOnVisible = true;
            try { voice.element.pause(); } catch { /* Best effort. */ }
          } else if (voice.intendedPlaying || voice.pending || voice.inFlight) {
            this.stopVoice(voice);
          }
          this.applyVoiceSettings(cue, voice);
          continue;
        }

        this.applyVoiceSettings(cue, voice);
        if (voice.resumeOnVisible) {
          voice.pendingAt = performance.now();
          this.requestPlayback(cue, voice, false);
        }
      }
    }
  }

  destroy(): void {
    if (this.destroyed) return;
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        this.stopVoice(voice);
        try {
          voice.element.removeAttribute("src");
          voice.element.load();
        } catch {
          // Best effort.
        }
      }
    }
    this.destroyed = true;
    this.cues.clear();
  }
}
```

### Why every voice field matters

| Field | Purpose |
|---|---|
| `element` | The exact persistent media element whose iOS permission state matters. |
| `generation` | Invalidates an earlier asynchronous play/prime completion after the voice is reused. |
| `primed` | Records that this exact element completed a muted unlock attempt. |
| `pending` | Records an audible play rejected by the browser and eligible for a bounded retry. |
| `pendingAt` | Expires old UI feedback after 900 ms. |
| `inFlight` | Prevents a voice with an unresolved play promise from being selected as idle. |
| `intendedPlaying` | Distinguishes desired playback from temporary promise/media state. |
| `resumeOnVisible` | Remembers long cues configured to resume after lifecycle pause. |
| `options` | Keeps the exact loop, volume, and source-segment settings for this playback. |

Do not remove the generation guard. Without it, a muted prime can resolve late and pause a real cue that has already reused the voice.

---

## Manifest setup

Create one typed manifest. Replace imports and cue names with the target project’s real assets and behavior.

```ts
import tapUrl from "../../Assets/audio/project/tap.mp3";
import swipeUrl from "../../Assets/audio/project/swipe.mp3";
import scratchUrl from "../../Assets/audio/project/scratch.mp3";
import completeUrl from "../../Assets/audio/project/complete.mp3";
import ctaPart1Url from "../../Assets/audio/project/cta-part1.mp3";
import ctaPart2Url from "../../Assets/audio/project/cta-part2.mp3";
import type { SfxCueConfig } from "./SfxController";

export type SfxKey =
  | "tap"
  | "swipe"
  | "scratch"
  | "complete"
  | "ctaPart1"
  | "ctaPart2";

export const SFX_MANIFEST: Record<SfxKey, SfxCueConfig> = {
  tap: { src: tapUrl, volume: 0.72, poolSize: 4 },
  swipe: { src: swipeUrl, volume: 0.55, poolSize: 2 },
  scratch: { src: scratchUrl, volume: 0.72, poolSize: 1, loop: true },
  complete: { src: completeUrl, volume: 0.88, poolSize: 2 },
  ctaPart1: {
    src: ctaPart1Url,
    volume: 0.9,
    poolSize: 1,
    pausePolicy: "resume",
  },
  ctaPart2: {
    src: ctaPart2Url,
    volume: 0.9,
    poolSize: 1,
    pausePolicy: "resume",
  },
};
```

Recommended pool sizes:

| Cue | Pool size | Reason |
|---|---:|---|
| Ordinary tap | 2 | Allows a second press before the first tail finishes. |
| Rapid/multi-tap | 3–4 | Preserves intentional overlap. |
| Swipe/carousel | 2 | Supports quick direction changes. |
| Wrong/correct feedback | 2 | Allows immediate correction. |
| Completion hit | 2 | Avoids cutting off closely timed successes. |
| Scratch loop | 1 | One explicitly started/stopped loop. |
| Reveal/transition | 1 | Normally serialized by flow state. |
| CTA/narration | 1 | Long serialized cue with `resume` policy if appropriate. |

Final volume is:

```text
manifest cue volume × per-play volume × normalized MRAID master volume
```

Use `startAt` and `endAt` when only part of a source file should play:

```ts
complete: {
  src: completeUrl,
  volume: 0.88,
  poolSize: 2,
  startAt: 0.12,
  endAt: 1.05,
}
```

This template currently uses that exact segment for its isolated Halloween completion hit. It skips the source’s opening click and the later ding/click burst. Source-segment values are asset-specific and must be re-measured when the file changes.

---

## Create the controller before interaction

There must be one controller instance for the experience. Constructing it creates every pool voice.

React:

```tsx
const [sfx] = useState(() => new SfxController<SfxKey>(SFX_MANIFEST));

useEffect(() => () => sfx.destroy(), [sfx]);
```

Vanilla DOM:

```ts
const sfx = new SfxController<SfxKey>(SFX_MANIFEST);

window.addEventListener("pagehide", () => sfx.destroy(), { once: true });
```

Do not construct the controller inside an interaction component that mounts late. Do not create one controller per button, card, scene, or sound.

---

## Native gesture wiring

### Immediate tap

The safest path is a native capture-phase `pointerdown`. The audible request must happen first.

```ts
button.addEventListener("pointerdown", () => {
  sfx.playFromGesture("tap");
}, true);
```

Use the normal click/game handler for state changes:

```ts
button.addEventListener("click", () => {
  completeInteraction();
});
```

For browsers without Pointer Events, use a passive native `touchstart` fallback:

```ts
if ("PointerEvent" in window) {
  button.addEventListener("pointerdown", press, true);
} else {
  button.addEventListener("touchstart", press, {
    capture: true,
    passive: true,
  });
}
```

### Reusable React button

```tsx
function NativeGestureButton({ onGesture, ...props }) {
  const ref = useRef<HTMLButtonElement>(null);
  const gestureRef = useRef(onGesture);
  gestureRef.current = onGesture;

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const press = () => {
      if (!element.disabled) gestureRef.current();
    };

    if ("PointerEvent" in window) {
      element.addEventListener("pointerdown", press, true);
      return () => element.removeEventListener("pointerdown", press, true);
    }

    element.addEventListener("touchstart", press, {
      capture: true,
      passive: true,
    });
    return () => element.removeEventListener("touchstart", press, true);
  }, []);

  return <button {...props} ref={ref} />;
}
```

Keyboard activation should also request the cue for accessibility:

```tsx
onKeyDown={(event) => {
  if (!event.repeat && (event.key === "Enter" || event.key === " ")) {
    onGesture();
  }
}}
```

### Swipe sound on release

If the sound represents a changed carousel snap, prioritize/prime its voices on press, then request the audible cue synchronously from the native release event only when the selection changed.

```ts
let startX = 0;

track.addEventListener("pointerdown", (event) => {
  startX = event.clientX;
  sfx.primeFromGesture("swipe");
  sfx.retryPending();
}, true);

track.addEventListener("pointerup", (event) => {
  const changed = Math.abs(event.clientX - startX) >= swipeThreshold;
  if (!changed) return;
  updateCarousel();
  sfx.playFromGesture("swipe", { restart: true });
}, true);
```

Use `touch-action: pan-y` on the swipe surface so users can still scroll the page vertically.

### Looping scratch

```ts
surface.addEventListener("pointerdown", () => {
  sfx.playFromGesture("scratch", { loop: true, restart: true });
}, true);

const stopScratch = () => sfx.stop("scratch");
surface.addEventListener("pointerup", stopScratch, true);
surface.addEventListener("pointercancel", stopScratch, true);
```

Always stop looped cues on release, cancel, completion, scene change, and unmount.

### Delayed reveal

Use the gesture to play the immediate feedback and prime the deferred reveal element. The later timer uses the persistent element already owned by the controller.

```ts
button.addEventListener("pointerdown", () => {
  sfx.playFromGesture("tap");
}, true);

button.addEventListener("click", () => {
  window.setTimeout(() => {
    sfx.play("reveal", { restart: true });
    showReveal();
  }, 650);
});
```

If the delayed cue is more important than lower-priority cues, explicitly prioritize it during the initiating gesture:

```ts
sfx.primeFromGesture("reveal");
```

### Completion sound

Use one idempotent completion function. Do not scatter completion playback across features.

```ts
const completed = new Set<string>();

function markComplete(id: string): void {
  if (completed.has(id)) return;
  completed.add(id);
  updateProgress(id);
  sfx.play("complete", { restart: true });
}
```

Project-specific exceptions belong here. For example, this test template marks swipe complete after its first valid card change but does not add a completion sound because swipe has no completion moment:

```ts
if (id !== "swipe") {
  sfx.play("complete", { restart: true });
}
```

Do not add a second delayed ding, click, or generic success sound unless the brief explicitly requests it.

### CTA behavior

CTA button presses should not automatically reuse the gameplay tap sound. If the flow requires CTA Part 2 audio, start it when the experience transitions into CTA Part 2/endcard—not when the user taps the CTA clickthrough.

```ts
function enterEndcard(): void {
  sfx.play("ctaPart2", { restart: true });
  renderEndcard();
}

ctaHitArea.addEventListener("click", triggerCTA);
```

The CTA click handler must remain dedicated to analytics/lifecycle and guarded MRAID clickthrough.

---

## Retry rejected playback

`playFromGesture()` retries existing pending voices after requesting the current audible cue. Drag-heavy experiences should also expose native movement/release opportunities:

```ts
const retry = () => sfx.retryPending();

window.addEventListener("pointermove", retry, true);
window.addEventListener("pointerup", retry, true);
window.addEventListener("touchmove", retry, true);
window.addEventListener("touchend", retry, true);
```

Remove these listeners during teardown.

Pending requests expire after 900 ms. Do not make the retry queue unlimited; playing old UI feedback seconds later is worse than dropping it.

---

## Lifecycle, MRAID visibility, and volume

Feed four values into the application:

```ts
type LifecycleState = {
  hidden: boolean;
  exposed: boolean;
  viewable: boolean;
  audioVolume: number;
};
```

Derive pause state and update the controller whenever it changes:

```ts
const mediaPaused = hidden || !exposed || !viewable;
sfx.setMasterVolume(audioVolume);
sfx.setPaused(mediaPaused);
```

Required sources:

- `document.visibilitychange` updates `hidden`.
- MRAID `stateChange` treats the `hidden` state as hidden.
- MRAID `exposureChange` is the primary viewability signal; exposed percentage `0` pauses media.
- MRAID `viewableChange` is the fallback and should seed exposure until an exposure event is observed.
- `mraid.isViewable()` seeds initial viewability when available.
- MRAID `audioVolumeChange` controls master volume.

Normalize MRAID volume safely:

```ts
function onAudioVolumeChange(value: unknown): void {
  if (typeof value !== "number" || !Number.isFinite(value)) return;
  sfx.setMasterVolume(Math.max(0, Math.min(1, value / 100)));
}
```

`null` is valid MRAID input and must be ignored. Guard every MRAID object and method access with `typeof` checks.

Register lifecycle listeners once and early. MRAID may appear after initial module evaluation, so bind once before boot and attempt binding again after the MRAID-ready/timeout gate resolves.

Pause-policy rules:

- Use the default `cancel` for taps, swipes, scratch, wrong/correct, spin, reveal, and completion effects.
- Use `resume` only for long narration or CTA cues that remain meaningful after returning.
- On pause, short cues stop and reset.
- On pause, a resume-policy cue remembers its position and pauses.
- On resume, only remembered resume-policy cues continue without restarting.

Do not use hidden or zero-volume time as an unlock opportunity. Keep the native gesture path even if the current master volume is zero.

---

## Mobile scrolling with drag interactions

For a one-page mobile test build inside an embedded ad view, use an explicit root scroll surface:

```css
html,
body {
  width: 100%;
  height: 100%;
  overflow: hidden;
}

#root {
  width: 100%;
  height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior-y: contain;
  touch-action: pan-y;
}

.swipe-surface,
.scratch-surface {
  touch-action: pan-y;
}
```

For old touch-event fallbacks, wait for directional intent before calling `preventDefault()`:

```ts
let startX = 0;
let startY = 0;
let intent: "pending" | "interaction" | "scroll" = "pending";

surface.addEventListener("touchstart", (event) => {
  startX = event.touches[0]?.clientX ?? 0;
  startY = event.touches[0]?.clientY ?? 0;
  intent = "pending";
  beginInteraction(startX, startY);
}, { capture: true, passive: true });

surface.addEventListener("touchmove", (event) => {
  const x = event.touches[0]?.clientX ?? startX;
  const y = event.touches[0]?.clientY ?? startY;

  if (intent === "pending") {
    const dx = Math.abs(x - startX);
    const dy = Math.abs(y - startY);
    if (Math.max(dx, dy) < 8) return;
    intent = dy > dx * 1.15 ? "scroll" : "interaction";
    if (intent === "scroll") {
      cancelInteraction();
      return;
    }
  }

  if (intent === "scroll") return;
  event.preventDefault();
  updateInteraction(x, y);
}, { capture: true, passive: false });
```

This intentionally favors vertical page scrolling. Users can still scratch horizontally or diagonally. Never make a full-width interaction region `touch-action: none` on a scrollable mobile test page unless the design provides another obvious scroll surface.

---

## Framework adaptation

### React

- Construct once with lazy `useState` or a stable top-level provider.
- Use native listeners in `useEffect` for the audio gesture path.
- Store changing callbacks in refs so the native listener does not need to be recreated on every render.
- Use React `onClick` for state changes, not as the only iOS audio-unlock path.
- Destroy the controller only when the entire experience unmounts.

### Vanilla DOM

- Construct the controller during boot after DOM readiness.
- Attach native capture listeners directly to interactive elements.
- Keep references to listener functions for teardown.
- Destroy on final teardown/page exit, not between sections.

### Phaser or another canvas engine

- Keep `SfxController` outside the scene so scene transitions do not recreate audio elements.
- The most reliable route is a native capture listener on the real canvas or a DOM interaction overlay.
- Request the intended cue synchronously before an async scene transition, tween completion, or timer.
- If using engine pointer callbacks, verify they execute synchronously from the native event and do not await before playback.
- Stop looped cues during scene shutdown and call `destroy()` only when the whole app is destroyed.
- Do not mix a second Phaser sound instance for the same cues unless the project has a deliberate, tested reason.

---

## Regression tests Codex must add

Automated tests cannot prove physical iOS permission behavior, but they must lock down the architecture.

At minimum test that:

1. The constructor creates the exact total number of persistent pool voices before any gesture.
2. `playFromGesture()` requests the intended audible cue before muted primes.
3. A rejected request retries on the same element.
4. A rejected request expires after 900 ms.
5. Rapid taps use different persistent voices.
6. A late prime completion cannot pause or mute a real delayed cue.
7. `startAt`/`endAt` stops playback at the configured source segment.
8. Final volume equals cue × per-play × master volume.
9. Lifecycle pause cancels short cues and resumes only configured long cues.
10. Swipe/release wiring primes on press and plays on native release after a valid change.
11. Every loop has release, cancel, completion, and teardown stop paths.
12. CTA clickthrough contains no gameplay tap call.
13. Mobile drag surfaces use `touch-action: pan-y` when the page must scroll.

The target project may use Vitest, Jest, Node’s test runner, or its existing test system. Follow the repository’s conventions instead of forcing a new framework.

---

## Implementation audit checklist

### Before editing

- [ ] Read repository instructions and package scripts.
- [ ] List every existing cue and where it is triggered.
- [ ] Identify immediate, release, delayed, looped, overlapping, completion, and CTA cues.
- [ ] Find all `new Audio`, `<audio>`, Web Audio, Phaser sound, and `.play()` calls.
- [ ] Find all native, React, engine, and touch/pointer handlers.
- [ ] Find visibility, mute, MRAID, CTA, and teardown code.
- [ ] Confirm which existing behavior must be preserved.

### Controller and manifest

- [ ] Add one persistent controller instance.
- [ ] Put all cues in one typed manifest.
- [ ] Size pools according to overlap needs.
- [ ] Import all runtime audio through the bundler.
- [ ] Use `resume` only for meaningful long cues.
- [ ] Add source segments only after measuring the real asset.

### Gesture wiring

- [ ] Audible cue requested first in native capture-phase press/release.
- [ ] No `await`, timer, or promise before the gesture-bound request.
- [ ] Swipe cue prioritized on press and requested on native release.
- [ ] Delayed cue uses the existing persistent element.
- [ ] Loop stops on all exit paths.
- [ ] Rejected playback retry is available on later gestures.
- [ ] Completion helper is idempotent.
- [ ] CTA clicks do not accidentally play gameplay tap audio.

### Lifecycle

- [ ] Document visibility connected.
- [ ] MRAID exposure and viewability connected.
- [ ] Initial `isViewable()` state seeded.
- [ ] MRAID volume normalized from 0–100 to 0–1.
- [ ] `null` and non-numeric volume ignored.
- [ ] MRAID calls guarded.
- [ ] Listeners installed once and late-ready MRAID handled.

### Mobile interaction

- [ ] Scrollable embedded builds own an explicit momentum-scroll container.
- [ ] Swipe and scratch surfaces preserve `pan-y`.
- [ ] Fallback touch handlers do not prevent vertical scrolling.
- [ ] Pointer capture is released/cancelled cleanly.

### Verification

- [ ] Typecheck passes.
- [ ] Unit/regression tests pass.
- [ ] Production build passes.
- [ ] Final HTML/resources pass target-network validation.
- [ ] First interaction works after a fresh load.
- [ ] Rapid cues overlap as designed.
- [ ] Swipe cue works on the first valid release.
- [ ] Scratch loop stops on release/cancel.
- [ ] Delayed cue works on its first attempt.
- [ ] Hide/show behavior is correct.
- [ ] Host mute/volume behavior is correct.
- [ ] Portrait and landscape work.
- [ ] Mobile page remains scrollable over and around interactions.
- [ ] Physical iPhone/iPad test completed in the real target container.

---

## Current template behavior used to derive this guide

The source template that produced this document currently uses:

| Cue | Behavior |
|---|---|
| Tap | Reskin `Bat 03` MP3, four-voice pool, immediate native press playback. |
| Multi-tap | Same Bat 03 pool, allowing rapid overlap. |
| Swipe | Two-voice pool; primed on press and played on valid native release. No completion sound. |
| Scratch | Single looping voice; stops on release, cancel, or completion. |
| Spin | One longer one-shot synchronized with the visual spin. |
| Wrong | Two voices so a correction can follow quickly. |
| Completion | Halloween bat source segment from 0.12–1.05 seconds; immediate and idempotent. |
| Reveal | Deferred cue played from its already-created/primed persistent voice. |
| CTA Part 1 | Long cue with visibility-aware resume policy. |
| CTA Part 2 | Starts during the endcard transition, not on CTA click. |
| CTA click | No tap SFX; guarded MRAID clickthrough only. |

These cue names and timings are examples, not universal requirements. Preserve the architecture while adapting the manifest and interaction rules to the new project’s brief.

---

## Physical iOS test protocol

Automated Chromium testing cannot validate iOS media permission. Before shipping:

1. Use the real production HTML, not only the development server.
2. Load it fresh in the actual AppLovin/iOS preview or equivalent WKWebView container.
3. Do not tap anywhere before the intended first interaction.
4. Test each possible first interaction path separately after a fresh reload.
5. Confirm the first immediate tap is audible.
6. Confirm the first swipe-release cue is audible.
7. Confirm the first scratch loop starts and stops correctly.
8. Confirm a delayed cue plays without a second unlock tap.
9. Rapidly tap and verify overlap without cutting voices off.
10. Background the app or make the ad non-viewable, then restore it.
11. Confirm short cues do not resume and configured long cues do.
12. Change host audio volume/mute when the preview supports it.
13. Test portrait, landscape, and rotation.
14. Confirm vertical scrolling works even when a gesture starts over swipe/scratch content.
15. Confirm CTA presses do not add an unintended click/tap sound.

Record the device, iOS version, preview/container version, orientation, first gesture tested, and result. Physical verification remains required even when all automated tests pass.

---

## Ready-to-use Codex request

After copying this file to another repository, use this request:

```text
Read IOS_SAFE_SFX_IMPLEMENTATION_GUIDE.md completely before making changes.

Audit this project’s existing audio, interaction handlers, lifecycle/MRAID code,
CTA flow, assets, tests, and build setup. Then implement the portable iOS-safe
SFX system from the guide, adapted to this project’s framework and current
behavior. Preserve existing visuals, interaction timing, analytics, CTA rules,
and project-specific sounds unless I explicitly ask for changes.

Create persistent audio pools before the first gesture; request the intended
cue first from native capture-phase gesture handlers; prime exact persistent
elements; retain bounded same-element retries; use generation guards; connect
visibility, MRAID exposure/viewability, and volume; preserve mobile vertical
scrolling; and add regression tests. Run typecheck, tests, the production build,
and target-network validation. Do not stop at an audit—implement and verify it.

At the end, list changed files, explain how each interaction is wired, report
test/build results, and identify only the physical iOS checks that remain.
```

If the target project is not TypeScript, tell Codex to translate the controller faithfully into its language while preserving the same per-voice state machine and ordering guarantees.
