# Audio Guidelines

## Shared architecture

All interaction SFX use `src/hooks/useSound.ts`. This repository has no React runtime and does not use `AudioContext`. Never create an `HTMLAudioElement` inside a handler, timer, scene transition, or endcard.

Reusable production cues are stored separately from campaign artwork:

```text
Assets/audio/shared/
  tap.mp3
  cta-part1.mp3
  cta-part2.mp3
```

They are mono, 44.1 kHz, 96 kbps MP3 files. Import them from TypeScript with `?inline` so Vite embeds the bytes in the final HTML.

## Registering sounds

Create every handle during module/bootstrap evaluation:

```ts
const tap = useSound(tapUrl, {
  poolSize: 3,
  desktopPoolSize: 1,
  volumeScale: 0.6,
  resumeAfterPause: false,
})
const ctaPart1 = useSound(ctaPart1Url, { poolSize: 1 })
const ctaPart2 = useSound(ctaPart2Url, { poolSize: 1 })
```

Use multiple mobile voices only when a cue may overlap or restart rapidly. Play through `playSound()` so the selected voice resets to the beginning and every rejection is guarded.

## Native gesture contract

- Bind native capture listeners directly to the interactive element.
- On an accepted `pointerdown`, call `playSoundFromGesture(tapHandle, 'pointerdown')` before state mutation. It primes deferred handles while excluding the active tap handle from the mute/pause priming pass, then plays that tap directly inside the native gesture.
- Keep activation on `click`, so pointer cancellation cannot select an item.
- Avoid playing the cue again from the compatibility click.
- Call `tapHandle.handleUnlockGesture('pointermove' | 'pointerup')` while an input remains active so only a rejected tap request retries on the same element.
- Call `cancelPending()` on cancellation or scene exit.
- For keyboard activation, prime and request the cue from the Enter/Space `keydown`, then activate once from the generated click.

`isMobileMediaPlatform()` must retain iPadOS desktop-mode detection using `navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1`. Touchscreen Windows devices continue to use the desktop strategy.

## Priming and lifecycle rules

- Prime the exact persistent elements that will later play.
- Preserve each element's prior `muted` and `volume` values.
- Pause and reset synchronously before restoring those values.
- Promise continuations from stale primes must never unmute, mutate, or start a reused voice.
- Pending cues expire after 750 ms and must be canceled when their interaction ends.
- Browser visibility, MRAID visibility, and hidden container state pause and mute every voice.
- Apply only finite numeric MRAID volume percentages; ignore `null` and invalid values.
- Destroy handles on permanent unload by pausing, clearing `src`, and calling `load()`.

## Verification

```powershell
npm run typecheck
npm run test:sound
npm run test:mraid
npm run build
npm run verify:applovin
```

Also test the first accepted tap on physical iPhone/iPad Safari and the target AppLovin WebView. Mocked Node checks validate ordering and state, but cannot prove host media authorization.
