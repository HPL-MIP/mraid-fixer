# iOS SFX Guide for Playables

Use this guide when SFX works on desktop or Android but fails in iPhone Safari, iOS WebViews, or playable-ad previews. The goal is for the **first real gameplay gesture** (for example, tap-and-drag) to be enough to authorize and play sound.

## Core rule

Create the exact audio instances early, before interaction. On the interactive element's native `pointerdown` or `touchstart`, unlock those existing instances and request the immediately audible SFX in that same synchronous event. Do not require a separate “Tap to Start” button.

React is **not** required. Keep Phaser games in Phaser; add a shared native-audio controller. Use a React hook only when the game is already React.

## Required behavior

1. Import/preload every SFX before the first interaction.
2. Create persistent `HTMLAudioElement` instances or a reusable pool during startup/layout—never inside an event handler or timer.
3. Add native capture listeners directly to the draggable/clickable element. Framework-delegated handlers alone can arrive too late in some iOS WebViews.
4. In native `pointerdown` / `touchstart`, call the shared audio unlock helper first, then play the interaction SFX immediately.
5. Keep a rejected `play()` request pending and retry that same element on native `pointermove`, `pointerup`, `touchmove`, or `touchend` while the drag is active.
6. Use a pool when a sound can overlap or restart quickly. Reset `currentTime = 0` before replay.
7. Catch every `play()` rejection. Do not silently create a replacement audio tag after rejection.
8. Pause active sounds when the document/MRAID is hidden or not viewable. Resume only if the interaction is still active and the creative is viewable.

## Phaser implementation

Use Phaser for rendering and gameplay; use a single `SoundController` (or equivalent) for browser audio. This avoids framework audio unlock timing being the only path.

```ts
// SoundController.ts
class SoundController {
  private readonly slider = new Audio(sliderSfxUrl);
  private sliderHeld = false;
  private sliderPending = false;

  constructor() {
    this.slider.preload = 'auto';
    this.slider.loop = true;
    this.slider.volume = 0.7;
  }

  handleUnlockGesture(): void {
    // Runs synchronously from the real native gesture.
    if (this.slider.readyState === HTMLMediaElement.HAVE_NOTHING) {
      this.slider.load();
    }
  }

  startSlider(): void {
    this.sliderHeld = true;
    this.requestSliderPlayback();
  }

  retryActiveSounds(): void {
    if (this.sliderHeld && this.sliderPending) this.requestSliderPlayback();
  }

  stopSlider(): void {
    this.sliderHeld = false;
    this.sliderPending = false;
    this.slider.pause();
    this.slider.currentTime = 0;
  }

  private requestSliderPlayback(): void {
    if (document.hidden || !this.slider.paused) return;
    this.slider.currentTime = 0;
    try {
      const request = this.slider.play();
      if (request) void request.then(() => { this.sliderPending = false; })
        .catch(() => { this.sliderPending = true; });
    } catch {
      this.sliderPending = true;
    }
  }
}
```

Attach the native listeners to the Phaser canvas, and call audio before normal drag work:

```ts
canvas.addEventListener('pointerdown', (event) => {
  if (!isOverDraggableHandle(event)) return;
  sounds.handleUnlockGesture();
  sounds.startSlider();
}, { capture: true, passive: true });

canvas.addEventListener('pointermove', () => sounds.retryActiveSounds(), {
  capture: true,
  passive: true,
});
canvas.addEventListener('pointerup', () => sounds.stopSlider(), {
  capture: true,
  passive: true,
});
```

If the project must retain Phaser HTML5 audio (`disableWebAudio: true`), unlock and load the **cached tags Phaser created** from `scene.cache.audio` during that same native gesture. Do not create substitute tags: iOS authorization applies to the specific media element. Retain rejected cached-tag playback for move/release retry.

## React implementation

Create a `useSound` hook that owns persistent pools. Call it unconditionally in a component mounted before the first gesture. The hook should expose:

```ts
type SoundHandle = {
  handleUnlockGesture: () => void;
  play: () => void;
  retryPending: () => void;
  stop: () => void;
};
```

Bind native listeners directly to the draggable DOM element as well as any React event handlers:

```tsx
const onPointerDown = () => {
  sliderSound.handleUnlockGesture();
  sliderSound.play();
  beginDrag();
};

element.addEventListener('pointerdown', onPointerDown, { capture: true });
element.addEventListener('pointermove', sliderSound.retryPending, { capture: true });
element.addEventListener('pointerup', sliderSound.stop, { capture: true });
```

Pre-create end-card and delayed-cue pools in the same early-mounted parent. Timer-driven playback must go through the same pending/retry controller.

## Do not do this

- Do not convert a Phaser game to React solely to add SFX.
- Do not create `new Audio()` inside `pointerdown`, a timeout, scene creation after the gesture, or an end card.
- Do not rely only on a `useEffect`, timer, Phaser delayed callback, or a global page click for first-gesture authorization.
- Do not start audio automatically on page load.
- Do not call `.play()` directly from scattered gameplay code; route it through one controller/hook.
- Do not repeatedly call `load()` once an element is ready; it can reset media state.
- Do not replace a rejected media element with a newly created one.
- Do not use silent `play()` then immediate `pause()` as the only authorization strategy; it can create `AbortError` races and still miss the intended audible first cue.

## MRAID and visibility

For playable ads, keep MRAID lifecycle handling centralized:

- Pause/mute audio on `stateChange: hidden`, `exposureChange <= 0`, `viewableChange: false`, and `document.visibilitychange`.
- Seed viewability from `mraid.isViewable()` when available.
- Resume only if the user interaction is still active and the creative is viewable.
- Apply `audioVolumeChange` only when its value is a number.

## Verification checklist

- The very first player action can be tap-and-drag; no preliminary page tap is needed.
- Slider/scratch/drag SFX begins during that first gesture on a physical iPhone.
- Releasing then starting another drag restarts the SFX cleanly.
- Rapid or overlapping one-shot sounds stay audible when a pool is required.
- End-card/delayed SFX uses a pre-created element and produces no unhandled promise errors.
- The creative is tested in Safari/WebKit and the target ad-network preview/WebView, not only desktop Chrome.
- Build passes and the output remains self-contained and within its size cap.

## Reuse prompt

> Read `IOS_SFX_PLAYABLE_GUIDE.md` and fix iOS SFX without changing the rendering framework. Create persistent audio pools before gameplay, unlock them from the exact native draggable-element gesture, play the first interaction cue immediately, retry rejected requests during the active drag, and preserve MRAID visibility handling.
