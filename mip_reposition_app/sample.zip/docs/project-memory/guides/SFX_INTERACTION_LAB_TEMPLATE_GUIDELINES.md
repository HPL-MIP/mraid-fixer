# iOS-Safe SFX Template Guidelines

This is the active implementation guide for the reusable SFX test template in this repository. The older project notes under `docs/project-memory/` remain as historical reference; this file describes the system that new builds should copy.

## What the template guarantees

The template is designed around the restrictions of iOS Safari and WKWebView: an audible media request is most reliable when it happens synchronously inside a real user gesture and uses an audio element that already exists. It also handles AppLovin/MRAID mute, exposure, visibility, overlapping cues, delayed cues, and rejected `play()` promises.

The core files are:

- `src/audio/SfxController.ts` — persistent voice pools and playback state.
- `src/audio/sfxManifest.ts` — one declarative list of all cues, volumes, pools, loops, and pause policies.
- `src/networks.ts` — MRAID readiness, exposure, visibility, volume, and CTA handling.
- `src/App.tsx` — examples for tap, multi-tap, swipe, scratch, spin, wrong/match, delayed reveal, CTA Part 1, and video endcard.
- `scripts/test-sound.mjs` — regression tests for the controller's iOS-critical behavior.

## Required interaction contract

1. Create one `SfxController` before the first interaction. Its constructor creates every persistent `HTMLAudioElement`; do not create audio elements in a timer, animation callback, or release handler.
2. Attach the unlock/play handler directly to the real interactive element with a native capture-phase `pointerdown`. Use `touchstart` only as the fallback when Pointer Events are unavailable.
3. Inside that handler, call `playFromGesture(cue)`. It requests the intended audible cue first, then primes the other exact persistent elements while the gesture is still active.
4. For a drag cue that should sound on release, call `primeFromGesture(cue)` on the native press and `playFromGesture(cue)` synchronously in the native `pointerup`/`touchend` handler.
5. If `play()` rejects, retain the request on the same voice and call `retryPending()` from the next native gesture. Requests expire after 900 ms so stale UI feedback does not play later.
6. Stop looping interaction cues explicitly on completion, cancel, and pointer release.
7. Route every successful interaction through one idempotent completion helper. That helper immediately plays only the isolated Halloween hit for all tests except the three-card swipe, which marks complete without a completion cue after its first valid card change. Do not duplicate completion playback inside individual feature modules.

Do not depend only on React synthetic events, a document-level unlock flag, or a newly constructed `Audio` instance. These patterns can work in desktop browsers while still failing on the first iOS gesture.

## Why the controller is reliable

Each pool voice tracks its own state:

- `primed` — that exact element completed a muted unlock play.
- `pending` and `pendingAt` — its audible play was rejected and may be retried briefly.
- `inFlight` — a play promise is unresolved.
- `intendedPlaying` — the application still wants the cue.
- `resumeOnVisible` — a long cue should continue after a lifecycle pause.
- `generation` — invalidates old async completions, preventing a late prime promise from pausing or muting a newer audible cue.

This state must remain per voice, not just per sound name. Pooling without per-voice state can select an element that is still priming or let a stale promise interfere with current playback.

## Manifest-first setup

Add cues in `src/audio/sfxManifest.ts` and import audio from `Assets/audio/...` so Vite can inline it into the final HTML.

```ts
export const SFX_MANIFEST = {
  tap: { src: tapUrl, volume: 0.72, poolSize: 4 },
  swipe: { src: swipeUrl, volume: 0.55, poolSize: 2 },
  scratch: { src: scratchUrl, volume: 0.72, loop: true },
  complete: { src: halloweenBatCompleteUrl, volume: 0.88, poolSize: 2, startAt: 0.12, endAt: 1.05 },
  reveal: { src: revealUrl, volume: 0.88 },
  ctaPart1: { src: ctaPart1Url, volume: 0.9, pausePolicy: "resume" },
} satisfies Record<string, SfxCueConfig>;
```

Pool recommendations:

| Cue type | Pool | Policy |
|---|---:|---|
| Rapid tap or particles | 3–4 | Allow overlap |
| Swipe/carousel snap | 2 | Prime both before deferred cues |
| Wrong/match feedback | 2 | Allow quick correction |
| Isolated completion hit | 2 | Play 0.12–1.05s immediately; skip the swipe test |
| Scratch loop | 1 | Start/stop explicitly |
| Reveal or transition | 1 | Prime on the gesture that schedules it |
| CTA narration/cue | 1 | Use `pausePolicy: "resume"` when continuity matters |

The current template's `complete` cue uses the Halloween source staged at `Assets/audio/sfx-template/halloween-bat-complete.mp3`, but only plays its 0.12–1.05 second segment. This skips the source's opening click and the later 2.18-second ding/click burst. Play the isolated hit immediately. The three-card swipe is the exception: a valid left/right card change marks it complete without playing this cue.

Keep individual cue volume in the manifest. Use the optional per-play volume only for a specific variation. The final volume is:

```text
cue volume × per-play volume × normalized MRAID master volume
```

## Interaction patterns

Immediate press:

```ts
element.addEventListener("pointerdown", () => {
  sfx.playFromGesture("tap");
}, true);
```

Swipe or carousel snap:

```ts
element.addEventListener("pointerdown", () => {
  sfx.primeFromGesture("swipe");
  sfx.retryPending();
}, true);

element.addEventListener("pointerup", () => {
  if (selectionChanged) sfx.playFromGesture("swipe");
}, true);
```

Delayed reveal:

```ts
element.addEventListener("pointerdown", () => {
  sfx.playFromGesture("tap"); // audible first; reveal is primed afterward
}, true);

window.setTimeout(() => {
  sfx.play("reveal");
}, 650);
```

Looping scratch:

```ts
onNativePress(() => sfx.playFromGesture("scratch", { loop: true }));
onNativeRelease(() => sfx.stop("scratch"));
```

For a known iOS-critical gesture such as the first carousel swipe, pass its key to `primeFromGesture()` first. The controller primes all voices for that cue before lower-priority deferred cues.

## Mobile scrolling and gesture surfaces

Embedded iOS ad views are more reliable when the creative owns an explicit scroll surface. Keep `html` and `body` fixed to the viewport, then give `#root` `height: 100%`, `overflow-y: auto`, `-webkit-overflow-scrolling: touch`, and `touch-action: pan-y`.

Drag interactions must preserve vertical page panning. Use `touch-action: pan-y` on swipe and scratch surfaces. For a touch-event fallback, wait for a small movement threshold, treat predominantly vertical motion as scrolling, stop any interaction loop, and do not call `preventDefault()`. Only prevent the default after horizontal interaction intent is established. This prevents a full-width interaction card from trapping the page on mobile.

## Lifecycle and MRAID rules

- Initialize MRAID before constructing the application, but keep a timeout so startup cannot hang.
- Bind MRAID listeners again after readiness because the bridge may appear after JavaScript first evaluates.
- Pause audio when `document.hidden`, MRAID state is hidden, exposure is zero, or viewability is false.
- Prefer `exposureChange`; use `viewableChange` as the fallback signal.
- MRAID `audioVolumeChange` is a percentage. Ignore `null` and non-numeric values, then normalize with `clamp(value / 100, 0, 1)` before passing it to `setMasterVolume()`.
- Short interaction sounds use the default `cancel` pause policy. Only long CTA or narration cues that remain meaningful after returning should use `resume`.
- A muted ad volume is not an unlock opportunity. Keep the gesture path in place even when the current master volume is zero.

## CTA and video sequence

After all tests complete, this template keeps a short visual handoff, then replaces the scrollable lab with a full-screen CTA Part 1 visual. It advances when CTA Part 1 audio ends or after a visibility-aware fallback. The endcard transition starts CTA Part 2 and a muted looping responsive video. The full endcard is clickable, but tapping it must not play an extra tap sound.

CTA clickthrough must resolve the AppLovin variables at click time in this order:

1. `window.clickTag`
2. `window.clickTag1`
3. `window.clickthrough`
4. `window.clickThrough`

Use guarded `mraid.open()` only. Do not add `window.open`, location navigation, or anchor simulation.

## Adding a new interaction

1. Put the compressed MP3 under `Assets/audio/<project>/` and keep it mono at 96 kbps unless sound quality clearly requires more.
2. Import it and add a typed key/config entry in `sfxManifest.ts`.
3. Decide whether the sound is immediate, release-triggered, delayed, looping, or overlapping.
4. Wire the native capture-phase gesture using one of the patterns above.
5. Stop loops and cancel obsolete feedback when the interaction exits.
6. Add a controller regression test if the interaction introduces a new playback rule.
7. Test the first gesture, not only subsequent gestures.

## Verification checklist

Run:

```powershell
npm run typecheck
npm run test:sound
npm run build
```

Then verify the single HTML in `dist/`:

- One early `mraid.js` request and no external runtime assets.
- No module/crossorigin script attributes.
- Under 5 MB.
- Portrait and landscape layouts work.
- Each interaction plays on its first attempt.
- Rapid taps overlap without cutting each other off.
- A changed swipe plays on the release gesture.
- Scratch stops on release/cancel.
- Delayed reveal and CTA cues play after being primed.
- Hiding and restoring the app cancels short cues and resumes only configured long cues.
- AppLovin mute/volume changes scale sound correctly.
- CTA uses MRAID and fails safely when MRAID cannot open.

Desktop and automated tests cannot prove iOS media policy behavior. Before shipping a project derived from this template, test the built HTML on a physical iPhone or iPad inside the actual AppLovin preview/container, beginning from a fresh load and using the intended first gesture.

## Rules for future template changes

- Keep `SfxController` framework-independent so it can be reused by React, DOM, or Phaser builds.
- Keep one manifest as the source of truth; do not scatter cue URLs or base volumes through feature code.
- Never replace persistent pools with `new Audio()` per play.
- Never remove generation guards from async play/prime handling.
- Never turn rejected playback into an unlimited queue.
- Preserve the native gesture timing when refactoring UI components.
- Re-run sound tests and physical iOS first-gesture QA after changing event ordering, pool selection, or lifecycle behavior.
