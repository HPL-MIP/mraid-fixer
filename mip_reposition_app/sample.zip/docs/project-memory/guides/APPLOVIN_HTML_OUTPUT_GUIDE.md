# AppLovin Single-File HTML Output Guide

This document defines the reusable delivery contract for an AppLovin-only,
self-contained HTML creative. It covers the final HTML envelope, MRAID 2.0 and
3.0 compatibility, click-through behavior, lifecycle handling, and browser-safe
sound effects.

It intentionally does not define creative layout, visual design, interaction
rules, copy, or campaign-specific file names.

## 1. Final output contract

The submitted artifact must be one synchronous HTML file with these properties:

- AppLovin is the only ad-network target.
- The file is strictly smaller than 5 MiB (`5 * 1024 * 1024` bytes).
- Line 1 is exactly `<!-- ad-network: Applovin | al -->`.
- The MRAID bridge is requested once, as early as possible in `<head>`.
- The mobile viewport declaration is present exactly once.
- Application JavaScript is an inline, synchronous IIFE.
- Final script tags have no `type="module"` or `crossorigin` attributes.
- CSS, fonts, images, audio, and video are embedded, normally as `data:` URLs.
- `mraid.js` is the only permitted external resource request.
- The file contains no external fetch/XHR/WebSocket/EventSource/beacon/service
  worker path.
- The file contains no stale SDK branch for another ad network.
- The delivered bundle contains no `console.error` call.
- CTA destination overrides remain resolved at click time.

Use this document shape:

```html
<!-- ad-network: Applovin | al -->
<!DOCTYPE html>
<html lang="en">
<head>
  <script src="mraid.js"></script>
  <!-- Insert the early MRAID helper from section 2 here. -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
  <style>
    /* All production CSS, including embedded font URLs. */
  </style>
</head>
<body>
  <div id="app"></div>
  <script>
    (function () {
      "use strict";
      // Inline application bundle.
    })();
  </script>
</body>
</html>
```

Do not inline, rename, proxy, or replace the MRAID bridge. The host provides it:

```html
<script src="mraid.js"></script>
```

## 2. Early validator-readable MRAID helper

Place this unminified block immediately after the single MRAID bridge and before
the application bundle. Keep the named helper, direct loading-state comparison,
ready listener, and direct `mraid.open(url)` call intact; submission validators
may scan for these exact forms.

```html
<script>
(function () {
  var mraidIsReady = false;
  var mraidReadyListenerAttached = false;
  var mraidGateInitialized = false;
  var resolveMraidReady;

  window.mraidReadyPromise = new Promise(function (resolve) {
    resolveMraidReady = resolve;
  });

  function init() {
    if (mraidGateInitialized) {
      return;
    }
    mraidGateInitialized = true;
    mraidIsReady = true;
    resolveMraidReady();
  }

  function trackMraidReadiness(mraid) {
    if (
      mraidReadyListenerAttached ||
      !mraid ||
      typeof mraid.addEventListener !== "function"
    ) {
      return;
    }

    try {
      mraid.addEventListener("ready", function () {
        mraidIsReady = true;
      });
      mraidReadyListenerAttached = true;
    } catch (error) {
      // getState() remains the primary readiness check.
    }
  }

  window.isMraidUsable = function (mraid) {
    if (!mraid) {
      return false;
    }

    trackMraidReadiness(mraid);
    if (typeof mraid.getState !== "function") {
      return true;
    }

    try {
      var state = mraid.getState();
      return state === "default" || state === "expanded";
    } catch (error) {
      return mraidIsReady;
    }
  };

  window.openMraidClickthrough = function (url) {
    var mraid = window.mraid;
    if (
      !window.isMraidUsable(mraid) ||
      typeof mraid.open !== "function"
    ) {
      return false;
    }

    try {
      mraid.open(url);
      return true;
    } catch (error) {
      return false;
    }
  };

  window.trackMraidReadiness = trackMraidReadiness;

  try {
    if (typeof mraid === "undefined") {
      init();
    } else {
      if (mraid.getState() === "loading") {
        mraid.addEventListener("ready", init);
        mraidReadyListenerAttached = true;
      } else {
        init();
      }
    }
  } catch (error) {
    init();
  }
})();
</script>
```

The early promise exists for compatibility and validator visibility. Production
startup must still use the timeout-safe runtime initializer in section 4 so a
broken host cannot leave the creative waiting forever.

This exact helper is the approved baseline for a non-resizing submission. It
recognizes the active `default` and `expanded` states. If a creative deliberately
uses MRAID `resize()`, its separately approved helper must also recognize the
valid `resized` state while preserving all validator-readable expressions above.

## 3. MRAID 2.0 and 3.0 compatibility

The implementation must support a MRAID 2.0 baseline and take advantage of
MRAID 3.0 signals when they exist.

| Concern | MRAID 2.0 baseline | MRAID 3.0 behavior |
| --- | --- | --- |
| Bridge | Request `mraid.js` early | Same bridge and initialization contract |
| Readiness | Check `getState()` and listen for `ready` while loading | Same behavior |
| Click-through | Use guarded `mraid.open(url)` | Same behavior |
| Container state | Listen for `stateChange` and `error` | Same events remain relevant |
| Visibility | Seed with `isViewable()` and listen for `viewableChange` | Prefer `exposureChange`; keep the 2.0 path as fallback |
| Effective audio volume | No standard volume event | Listen for `audioVolumeChange` |

Compatibility rules:

1. Register all listeners through guarded `typeof` checks and `try/catch`.
2. Seed visibility with `isViewable()` when available.
3. Treat `exposureChange` as authoritative after the first valid numeric event.
4. Use `viewableChange` only until an `exposureChange` event has been observed.
5. Clamp valid exposure and audio percentages to the specification's `0–100`
   range; treat an exposed percentage greater than zero as visible.
6. Accept `audioVolumeChange` only when its value is a finite number.
7. Ignore `null`, `undefined`, `NaN`, and infinite volume values.
8. Combine MRAID visibility with `document.visibilityState`; either source may
   pause the creative.
9. Do not assume that optional native methods exist. Call `mraid.supports()`
   before using optional native capabilities.
10. Keep host-facing callbacks small, guarded, and allocation-free where they
    may run frequently.

MRAID 3.0 deprecates `isViewable()` and `viewableChange`, but retains them for
backward compatibility. Keep them for MRAID 2.0 hosts and for two-part ads,
where `exposureChange` is unavailable. A 2.0 host may reject or report an error
for a 3.0-only event registration; guarded registration must treat that as an
unsupported capability, not a startup failure.

Official references:

- [IAB Tech Lab MRAID 2.0 specification](https://dev.iabtechlab.com/wp-content/uploads/2016/02/IAB_MRAID_v2_FINAL.pdf)
- [IAB Tech Lab MRAID 3.0 specification](https://iabtechlab.com/wp-content/uploads/2016/07/MRAID_3.0_FINAL.pdf)
- [IAB Tech Lab MRAID overview and compliance resources](https://iabtechlab.com/standards/mobile-rich-media-ad-interface-definitions-mraid/)

## 4. Timeout-safe runtime initialization

Initialize the MRAID runtime at bundle evaluation time, then await it before
constructing the application. The short detection window handles containers
that inject `window.mraid` slightly after parsing begins. The readiness timeout
prevents a loading host from blocking startup indefinitely. A timeout settles
application startup without calling a still-loading bridge; the retained
`ready` listener activates MRAID later if the host eventually becomes ready.

```js
var MraidRuntime = (function () {
  var state = {
    bootSettled: false,
    mraidReady: false,
    viewable: true,
    volumePercentage: null
  };
  var bootPromise = null;
  var listenersRegistered = false;
  var exposureSignalObserved = false;
  var visibilitySubscribers = [];
  var volumeSubscribers = [];

  function notifyVisibility(viewable) {
    state.viewable = Boolean(viewable);
    for (var index = 0; index < visibilitySubscribers.length; index += 1) {
      visibilitySubscribers[index](state.viewable);
    }
  }

  function notifyVolume(percentage) {
    if (typeof percentage !== "number" || !Number.isFinite(percentage)) {
      return;
    }
    var normalized = Math.max(0, Math.min(100, percentage));
    state.volumePercentage = normalized;
    for (var index = 0; index < volumeSubscribers.length; index += 1) {
      volumeSubscribers[index](normalized);
    }
  }

  function addListener(mraid, eventName, handler) {
    try {
      if (mraid && typeof mraid.addEventListener === "function") {
        mraid.addEventListener(eventName, handler);
      }
    } catch (error) {
      // Missing or partial host APIs must not stop startup.
    }
  }

  function setup() {
    var mraid = window.mraid;
    if (!mraid || state.mraidReady) {
      return;
    }
    state.mraidReady = true;

    try {
      state.viewable = typeof mraid.isViewable === "function"
        ? Boolean(mraid.isViewable())
        : true;
    } catch (error) {
      state.viewable = true;
    }

    if (!listenersRegistered) {
      listenersRegistered = true;

      addListener(mraid, "error", function (message, action) {
        console.warn("[MRAID error]", { message: message, action: action });
      });

      addListener(mraid, "stateChange", function () {
        // Reconcile explicit expand, resize, or close behavior here if used.
      });

      addListener(mraid, "exposureChange", function (exposedPercentage) {
        if (
          typeof exposedPercentage !== "number" ||
          !Number.isFinite(exposedPercentage)
        ) {
          return;
        }
        exposureSignalObserved = true;
        var normalized = Math.max(0, Math.min(100, exposedPercentage));
        notifyVisibility(normalized > 0);
      });

      addListener(mraid, "viewableChange", function (viewable) {
        if (!exposureSignalObserved) {
          notifyVisibility(Boolean(viewable));
        }
      });

      addListener(mraid, "audioVolumeChange", function (percentage) {
        // null is valid in MRAID 3.0 and is intentionally ignored here.
        notifyVolume(percentage);
      });
    }

    notifyVisibility(state.viewable);
  }

  function init(timeoutMs, detectTimeoutMs) {
    timeoutMs = typeof timeoutMs === "number" ? timeoutMs : 2000;
    detectTimeoutMs = typeof detectTimeoutMs === "number" ? detectTimeoutMs : 500;

    if (bootPromise) {
      return bootPromise;
    }

    bootPromise = new Promise(function (resolve) {
      var bootResolved = false;

      function settleBoot() {
        if (bootResolved) {
          return;
        }
        bootResolved = true;
        state.bootSettled = true;
        resolve(state);
      }

      function activateMraid() {
        setup();
        settleBoot();
      }

      function waitForReady() {
        var mraid = window.mraid;
        if (!mraid) {
          notifyVisibility(true);
          settleBoot();
          return;
        }

        try {
          if (typeof mraid.getState !== "function") {
            activateMraid();
            return;
          }

          if (mraid.getState() === "loading") {
            if (typeof mraid.addEventListener === "function") {
              mraid.addEventListener("ready", activateMraid);
            }
            window.setTimeout(settleBoot, timeoutMs);
            return;
          }

          activateMraid();
        } catch (error) {
          settleBoot();
        }
      }

      if (window.mraid) {
        waitForReady();
        return;
      }

      var startedAt = Date.now();
      function detect() {
        if (window.mraid || Date.now() - startedAt >= detectTimeoutMs) {
          waitForReady();
          return;
        }
        window.setTimeout(detect, 50);
      }
      detect();
    });

    return bootPromise;
  }

  function subscribeVisibility(handler) {
    visibilitySubscribers.push(handler);
    handler(state.viewable);
    return function unsubscribe() {
      var index = visibilitySubscribers.indexOf(handler);
      if (index >= 0) {
        visibilitySubscribers.splice(index, 1);
      }
    };
  }

  function subscribeVolume(handler) {
    volumeSubscribers.push(handler);
    if (state.volumePercentage !== null) {
      handler(state.volumePercentage);
    }
    return function unsubscribe() {
      var index = volumeSubscribers.indexOf(handler);
      if (index >= 0) {
        volumeSubscribers.splice(index, 1);
      }
    };
  }

  return {
    getState: function () {
      return state;
    },
    init: init,
    subscribeVisibility: subscribeVisibility,
    subscribeVolume: subscribeVolume
  };
})();

function whenDomReady() {
  if (document.readyState !== "loading" && document.body) {
    return Promise.resolve();
  }

  return new Promise(function (resolve) {
    function finish() {
      if (!document.body) {
        window.setTimeout(finish, 20);
        return;
      }
      document.removeEventListener("DOMContentLoaded", finish);
      window.removeEventListener("load", finish);
      resolve();
    }

    document.addEventListener("DOMContentLoaded", finish);
    window.addEventListener("load", finish);
    finish();
  });
}

// Start detection at module evaluation time.
var runtimeMraidSettled = MraidRuntime.init(2000, 500);

async function boot() {
  await whenDomReady();
  await runtimeMraidSettled;
  // Construct the application only after DOM and MRAID readiness are handled.
}

boot().catch(function (error) {
  console.warn("Application startup failed.", error);
});
```

Call the runtime initializer once. Repeated calls must return the same promise
and must not register duplicate listeners. This singleton owns its host MRAID
listeners for the lifetime of the containing webview. A multi-mount application
must additionally store and remove host listeners during permanent teardown.

## 5. Browser and MRAID lifecycle

Pause whenever the page is hidden or the host reports zero visibility. Resume
only when both sources are visible. Apply cached MRAID state immediately when
the application registers its handlers.

```js
function bindVisibilityLifecycle(runtime, handlers) {
  var documentVisible = !document.hidden;
  var mraidVisible = runtime.getState().viewable;
  var effectiveVisible = null;

  function sync() {
    var visible = documentVisible && mraidVisible;
    if (visible === effectiveVisible) {
      return;
    }
    effectiveVisible = visible;
    if (visible) {
      handlers.onResume();
    } else {
      handlers.onPause();
    }
  }

  function onVisibilityChange() {
    documentVisible = !document.hidden;
    sync();
  }

  document.addEventListener("visibilitychange", onVisibilityChange);

  var unsubscribeVisibility = runtime.subscribeVisibility(function (viewable) {
    mraidVisible = viewable;
    sync();
  });

  var unsubscribeVolume = runtime.subscribeVolume(function (percentage) {
    if (
      typeof percentage === "number" &&
      Number.isFinite(percentage) &&
      typeof handlers.onVolume === "function"
    ) {
      handlers.onVolume(percentage);
    }
  });

  sync();

  return function unbind() {
    document.removeEventListener("visibilitychange", onVisibilityChange);
    unsubscribeVisibility();
    unsubscribeVolume();
  };
}
```

Lifecycle handlers should pause animations, timers, audio, and video without
destroying state. Resume only media that was intentionally active before the
pause. Destroy media and remove listeners when the document is permanently
unloaded.

## 6. CTA resolution and click-through

Resolve the destination at click time so an AppLovin wrapper or client preview
tool can supply or change it after the HTML is built.

Use this exact priority:

1. `window.__CTA_URL__`
2. Query parameters: `cta_url`, `ctaUrl`, `click_url`, `clickUrl`
3. `window.clickTag`
4. `window.clickTag1`
5. `window.clickthrough`
6. `window.clickThrough`
7. `about:blank`

```js
var DEFAULT_CTA_URL = "about:blank";

function stringValue(value) {
  return typeof value === "string" ? value.trim() : "";
}

function resolveCTAUrl() {
  try {
    var query = new URLSearchParams(window.location.search);
    var queryKeys = ["cta_url", "ctaUrl", "click_url", "clickUrl"];
    var queryValue = "";

    for (var index = 0; index < queryKeys.length; index += 1) {
      queryValue = stringValue(query.get(queryKeys[index]));
      if (queryValue) {
        break;
      }
    }

    return (
      stringValue(window.__CTA_URL__) ||
      queryValue ||
      stringValue(window.clickTag) ||
      stringValue(window.clickTag1) ||
      stringValue(window.clickthrough) ||
      stringValue(window.clickThrough) ||
      DEFAULT_CTA_URL
    );
  } catch (error) {
    return (
      stringValue(window.__CTA_URL__) ||
      stringValue(window.clickTag) ||
      stringValue(window.clickTag1) ||
      stringValue(window.clickthrough) ||
      stringValue(window.clickThrough) ||
      DEFAULT_CTA_URL
    );
  }
}

function triggerCTA(url) {
  var target = stringValue(url) || resolveCTAUrl();

  try {
    if (
      typeof window.openMraidClickthrough === "function" &&
      window.openMraidClickthrough(target)
    ) {
      return;
    }

    var mraid = window.mraid;
    if (mraid && typeof mraid.open === "function") {
      var usable = typeof window.isMraidUsable === "function"
        ? window.isMraidUsable(mraid)
        : typeof mraid.getState !== "function" || mraid.getState() !== "loading";

      if (usable) {
        try {
          mraid.open(target);
          return;
        } catch (error) {
          // Continue to the browser fallback.
        }
      }
    }

    window.open(target, "_blank", "noopener");
  } catch (error) {
    try {
      window.open(target, "_blank", "noopener");
    } catch (fallbackError) {
      // The host rejected all available click-through mechanisms.
    }
  }
}
```

CTA rules:

- Invoke `triggerCTA()` only from a discrete user activation such as a tap,
  click, or keyboard activation; never launch a click-through from a timer.
- Do not resolve the URL only once during startup.
- Do not use `location.href`, `location.assign()`, or an unguarded
  `window.open()` as the primary path.
- Call `mraid.open()` only after readiness/usable-state checks.
- Keep the browser fallback for local previews and incomplete hosts.
- Stop pointer propagation when a CTA overlaps another input surface.
- A production submission must arrange for the client or host to inject a real
  destination if the default remains `about:blank`.

## 7. Optional AppLovin analytics and lifecycle hooks

Host globals are optional. Guard both the object and method before use, and let
missing integrations behave as no-ops.

```js
function safeCall(callback) {
  try {
    if (typeof callback === "function") {
      callback();
    }
  } catch (error) {
    // Optional host callbacks must not break the creative.
  }
}

function trackEvent(eventName) {
  try {
    var analytics = window.ALPlayableAnalytics;
    if (analytics && typeof analytics.trackEvent === "function") {
      analytics.trackEvent(eventName);
    }
  } catch (error) {
    // Analytics is optional.
  }
}

function notifyAppReady() {
  safeCall(window.appReady);
}

function notifyAppStart() {
  safeCall(window.appStart);
}

function notifyAppComplete() {
  safeCall(window.appComplete);
}

function notifyAppClose() {
  safeCall(window.appClose);
}

function redirectToClient() {
  trackEvent("CTA_CLICKED");
  notifyAppClose();
  triggerCTA(resolveCTAUrl());
}
```

A compact event vocabulary may include `DISPLAYED`, `CTA_CLICKED`,
`PANEL_SHOWN`, `INTERACTION_STARTED`, and `INTERACTION_COMPLETED`. Emit each
semantic milestone once unless repeated events are deliberately part of the
measurement contract.

## 8. Platform-level sound-effect requirements

### 8.1 Asset requirements

- Use short MP3 assets encoded as mono, 44.1 kHz, 96 kbps.
- Strip nonessential metadata.
- Embed the final bytes in the single HTML through imported/data URLs.
- Keep audio out of the critical first visual frame when possible.
- Do not reference a raw relative audio path from final DOM markup.

### 8.2 Runtime architecture

- Create persistent `HTMLAudioElement` instances during application setup.
- Do not create replacement elements inside event handlers or timers.
- Set `preload = "auto"` and `playsinline` on every SFX element.
- Never start audible playback automatically.
- Prime the exact persistent element, muted, during the first real user gesture.
- Retry a rejected prime only from a later user gesture.
- Reset `currentTime` before replaying a one-shot effect.
- Catch every `play()` promise rejection.
- Track whether a loop is intentionally active; never infer intent only from
  `audio.paused`.
- Stop loops on release/cancel/lost capture, lifecycle pause, and destroy.
- Preserve the effective MRAID volume multiplier.
- Pause audio when browser or MRAID visibility is zero.
- Remove `src` and call `load()` during permanent destruction.

### 8.3 Persistent one-shot controller

The following pattern never performs audible autoplay. Call
`unlockFromGesture()` or `retryFromGesture()` only from a genuine pointer,
touch, or keyboard activation handler.

```js
function createOneShotSfx(source) {
  var element = new Audio(source);
  var generation = 0;
  var unlocked = false;
  var unlockPending = false;
  var priming = false;
  var playPending = false;
  var paused = false;
  var destroyed = false;
  var volume = 1;
  var resumeAfterPause = false;

  element.preload = "auto";
  element.setAttribute("playsinline", "");

  function markBlocked(expectedGeneration) {
    if (destroyed || paused || generation !== expectedGeneration) {
      return;
    }
    unlocked = false;
    unlockPending = true;
    playPending = true;
  }

  function playNow() {
    if (destroyed || paused || !unlocked) {
      return;
    }

    var expectedGeneration = ++generation;
    playPending = false;
    resumeAfterPause = false;

    try {
      element.pause();
      element.currentTime = 0;
      element.muted = false;
      element.volume = volume;
      var playback = element.play();
      if (playback) {
        playback.catch(function () {
          markBlocked(expectedGeneration);
        });
      }
    } catch (error) {
      markBlocked(expectedGeneration);
    }
  }

  function finishPrime(expectedGeneration, succeeded) {
    if (destroyed || generation !== expectedGeneration) {
      return;
    }

    try {
      element.pause();
      element.currentTime = 0;
      element.muted = false;
      element.volume = volume;
    } catch (error) {
      // Preserve the state flags even if media cleanup is rejected.
    }

    priming = false;
    unlocked = succeeded;
    unlockPending = !succeeded;

    if (succeeded && playPending && !paused) {
      playNow();
    }
  }

  function primeFromGesture() {
    if (destroyed || unlocked || priming) {
      return;
    }

    var expectedGeneration = ++generation;
    priming = true;
    unlockPending = false;

    try {
      element.muted = true;
      element.volume = 0;
      element.currentTime = 0;
      var playback = element.play();

      if (!playback) {
        finishPrime(expectedGeneration, true);
        return;
      }

      playback.then(function () {
        finishPrime(expectedGeneration, true);
      }).catch(function () {
        finishPrime(expectedGeneration, false);
      });
    } catch (error) {
      finishPrime(expectedGeneration, false);
    }
  }

  return {
    unlockFromGesture: function () {
      primeFromGesture();
    },

    retryFromGesture: function () {
      if (!unlocked && unlockPending) {
        primeFromGesture();
      }
    },

    play: function () {
      if (destroyed || paused) {
        return;
      }
      if (!unlocked) {
        playPending = true;
        return;
      }
      playNow();
    },

    setVolume: function (percentage) {
      if (typeof percentage !== "number" || !Number.isFinite(percentage)) {
        return;
      }
      volume = Math.max(0, Math.min(1, percentage / 100));
      element.volume = volume;
    },

    pause: function () {
      if (destroyed || paused) {
        return;
      }
      paused = true;
      resumeAfterPause = !element.paused && !element.ended && !priming;
      try {
        element.pause();
      } catch (error) {
        // Pause is best-effort in incomplete media implementations.
      }
    },

    resume: function () {
      if (destroyed || !paused) {
        return;
      }
      paused = false;

      if (playPending && unlocked) {
        playNow();
        return;
      }

      if (resumeAfterPause) {
        resumeAfterPause = false;
        try {
          var playback = element.play();
          if (playback) {
            playback.catch(function () {});
          }
        } catch (error) {
          // A later real gesture may retry playback.
        }
      }
    },

    destroy: function () {
      if (destroyed) {
        return;
      }
      destroyed = true;
      generation += 1;
      try {
        element.pause();
        element.removeAttribute("src");
        element.load();
      } catch (error) {
        // The element is no longer used after this point.
      }
    }
  };
}
```

### 8.4 Explicit loop controller

A loop needs separate desired-state tracking so a lifecycle resume does not
restart a loop that the application already stopped.

```js
function createLoopSfx(source, volumeTrim) {
  var element = new Audio(source);
  var generation = 0;
  var unlocked = false;
  var unlockPending = false;
  var priming = false;
  var desiredPlaying = false;
  var paused = false;
  var destroyed = false;
  var volume = 1;
  var trim = typeof volumeTrim === "number" && Number.isFinite(volumeTrim)
    ? Math.max(0, Math.min(1, volumeTrim))
    : 1;

  element.loop = true;
  element.preload = "auto";
  element.setAttribute("playsinline", "");

  function stopElement(reset) {
    try {
      element.pause();
      if (reset) {
        element.currentTime = 0;
      }
    } catch (error) {
      // Media cleanup is best-effort.
    }
  }

  function markBlocked(expectedGeneration) {
    if (
      destroyed ||
      paused ||
      generation !== expectedGeneration
    ) {
      return;
    }
    unlocked = false;
    unlockPending = true;
  }

  function finishPrime(expectedGeneration, succeeded) {
    if (destroyed || generation !== expectedGeneration) {
      return;
    }

    try {
      element.pause();
      element.currentTime = 0;
      element.muted = false;
      element.volume = volume * trim;
    } catch (error) {
      // Preserve the state flags even if media cleanup is rejected.
    }

    priming = false;
    unlocked = succeeded;
    unlockPending = !succeeded;

    if (succeeded && desiredPlaying && !paused) {
      playNow();
    }
  }

  function primeFromGesture() {
    if (destroyed || unlocked || priming) {
      return;
    }

    var expectedGeneration = ++generation;
    priming = true;
    unlockPending = false;

    try {
      element.muted = true;
      element.volume = 0;
      element.currentTime = 0;
      var playback = element.play();

      if (!playback) {
        finishPrime(expectedGeneration, true);
        return;
      }

      playback.then(function () {
        finishPrime(expectedGeneration, true);
      }).catch(function () {
        finishPrime(expectedGeneration, false);
      });
    } catch (error) {
      finishPrime(expectedGeneration, false);
    }
  }

  function playNow() {
    if (
      destroyed ||
      paused ||
      !desiredPlaying ||
      !unlocked ||
      !element.paused
    ) {
      return;
    }

    var expectedGeneration = ++generation;
    try {
      element.muted = false;
      element.volume = volume * trim;
      var playback = element.play();
      if (playback) {
        playback.then(function () {
          if (expectedGeneration !== generation) {
            return;
          }
          if (destroyed || paused || !desiredPlaying) {
            stopElement(true);
          }
        }).catch(function () {
          markBlocked(expectedGeneration);
        });
      }
    } catch (error) {
      markBlocked(expectedGeneration);
    }
  }

  return {
    unlockFromGesture: function () {
      primeFromGesture();
    },

    retryUnlockFromGesture: function () {
      if (!unlocked && unlockPending) {
        primeFromGesture();
      }
    },

    startFromGesture: function () {
      if (destroyed) {
        return;
      }
      desiredPlaying = true;
      if (paused) {
        return;
      }
      if (!unlocked) {
        primeFromGesture();
        return;
      }
      playNow();
    },

    retryFromGesture: function () {
      if (destroyed || paused || !desiredPlaying) {
        return;
      }
      if (!unlocked) {
        primeFromGesture();
        return;
      }
      if (element.paused) {
        playNow();
      }
    },

    stop: function () {
      desiredPlaying = false;
      generation += 1;
      if (priming) {
        priming = false;
        unlockPending = !unlocked;
      }
      stopElement(true);
    },

    setVolume: function (percentage) {
      if (typeof percentage !== "number" || !Number.isFinite(percentage)) {
        return;
      }
      volume = Math.max(0, Math.min(1, percentage / 100));
      element.volume = volume * trim;
    },

    pause: function () {
      if (destroyed || paused) {
        return;
      }
      paused = true;
      generation += 1;
      if (priming) {
        priming = false;
        unlockPending = !unlocked;
      }
      stopElement(false);
    },

    resume: function () {
      if (destroyed || !paused) {
        return;
      }
      paused = false;
      if (desiredPlaying && unlocked) {
        playNow();
      }
    },

    destroy: function () {
      if (destroyed) {
        return;
      }
      destroyed = true;
      desiredPlaying = false;
      generation += 1;
      stopElement(true);
      try {
        element.removeAttribute("src");
        element.load();
      } catch (error) {
        // The element is no longer used after this point.
      }
    }
  };
}
```

Create every controller during setup. On the first real user gesture, call
`unlockFromGesture()` for each persistent loop. If a loop should begin on that
same gesture, call `startFromGesture()` after the unlock call; audible playback
waits for the muted prime to finish. A failed prime or blocked start may be
retried only by `retryUnlockFromGesture()` or `retryFromGesture()` from another
real gesture.

Do not start a loop from a timer, and stop it on every terminal input path.

## 9. Packaging rules

### Required

- Single `.html` file only; no ZIP unless explicitly requested.
- Exact AppLovin marker on line 1.
- Exactly one early `<script src="mraid.js"></script>`.
- Exactly one mobile viewport declaration.
- Inline IIFE application script.
- Literal embedded `data:` URLs for runtime media.
- Raster art encoded as WebP unless a documented exception is required.
- Compressed, short audio only when sound is required.
- Runtime click-through overrides preserved.
- Final byte length strictly below 5 MiB.

### Prohibited

- `type="module"` in the delivered HTML.
- `crossorigin` on final markup.
- Remote `http://`, `https://`, protocol-relative, or WebSocket resources.
- External resource calls through `fetch`, XHR, WebSocket, EventSource,
  `sendBeacon`, dynamic imports, service workers, AJAX libraries, or similar
  request APIs.
- Relative runtime asset paths other than the host-provided `mraid.js` bridge.
- Direct runtime imports from handoff, scratch, download, or reference folders.
- Template placeholders such as `${assetName}` inside resource URLs.
- Stale SDK adapters for non-AppLovin networks. Remove rejected adapter tokens
  such as `ExitApi`, `FbPlayableAd`, `__VUNGLE__`, `dapi`, `Luna`,
  `playableSDK`, `openAppStore`, `ironSource`, `mintegral`, `UnityAds`, and
  `Moloco` from the submitted bundle.
- Primary CTA navigation through `location.href` or `location.assign()`.
- Unguarded MRAID calls.
- `console.error` in the delivered bundle.
- Audible autoplay.

## 10. Common validator failures

| Failure | Typical cause | Required correction |
| --- | --- | --- |
| Missing network marker | Comment is absent or not on line 1 | Prepend the exact AppLovin marker before `<!DOCTYPE html>` |
| Wrong MRAID count | Bridge is missing, duplicated, renamed, or embedded | Keep one literal `src="mraid.js"` script in `<head>` |
| MRAID helper ordering invalid | Helper is before the bridge or buried in the bundle | Put the unminified helper immediately after the bridge |
| Loading gate not found | Condition is inverted, aliased, or combined | Preserve the standalone `mraid.getState() === "loading"` gate |
| Ready listener not found | Listener is outside the loading branch or renamed beyond recognition | Keep `mraid.addEventListener("ready", init)` in the branch |
| MRAID click call not found | CTA uses only an anchor or browser navigation | Retain guarded `mraid.open(url)` with fallback |
| Missing lifecycle signal | Media exists without browser/MRAID visibility handling | Register both version-compatible MRAID paths and `visibilitychange` |
| Invalid audio volume handling | `null` is coerced to zero or applied to media | Accept only finite numeric percentages |
| External asset detected | A runtime URL was not embedded | Import and inline the resource before delivery |
| External request API detected | Bundle retains a network client or service worker | Remove the request path entirely |
| Module/cross-origin markup remains | Vite output was not normalized | Strip `type="module"` and `crossorigin` after bundling |
| Dynamic resource placeholder remains | CSS/markup URL was constructed from a template string | Emit a static literal embedded URL |
| Non-AppLovin SDK token remains | Shared template branches were bundled | Remove unused network adapters before building |
| File is too large | Media is uncompressed or unused assets were included | Recompress assets and tree-shake unused variants |
| `console.error` remains | Application or dependency emitted the call | Drop it at bundle time; keep guarded `console.warn` fallback paths |

## 11. Delivery checklists

### HTML and packaging

- [ ] The file begins with `<!-- ad-network: Applovin | al -->` on line 1.
- [ ] `<!DOCTYPE html>` follows the network marker.
- [ ] The viewport meta tag is present exactly once.
- [ ] The MRAID bridge appears exactly once and is the first executable request.
- [ ] All application code and creative assets are inline.
- [ ] No `type="module"` or `crossorigin` attribute remains.
- [ ] No external resource or request API remains except `mraid.js`.
- [ ] No stale non-AppLovin SDK branch remains.
- [ ] No `console.error` call remains.
- [ ] The final file is strictly smaller than 5 MiB.

### MRAID and CTA

- [ ] The named early readiness helper follows the bridge.
- [ ] The exact loading-state gate and ready listener remain readable.
- [ ] Timeout-safe runtime initialization begins at bundle evaluation.
- [ ] Startup cannot wait forever for a broken host.
- [ ] `error`, `stateChange`, `exposureChange`, `viewableChange`, and
      `audioVolumeChange` listeners are guarded and registered once.
- [ ] Visibility is seeded from `isViewable()` when available.
- [ ] `exposureChange` takes priority after its first valid event.
- [ ] CTA resolution happens at click time in the documented priority order.
- [ ] CTA uses guarded `mraid.open(url)` before the browser fallback.
- [ ] Optional analytics and lifecycle callbacks are guarded.

### Sound effects

- [ ] Audio bytes are embedded and encoded to the delivery specification.
- [ ] Persistent audio elements are created before the first interaction.
- [ ] Audible autoplay is absent.
- [ ] The exact persistent elements are primed muted on the first real gesture.
- [ ] Rejected playback is retried only from another real gesture.
- [ ] One-shot playback resets `currentTime`.
- [ ] Loops track desired state and stop on every terminal input path.
- [ ] Every `play()` promise rejection is handled.
- [ ] Browser and MRAID visibility pause audio.
- [ ] Only finite numeric MRAID volume values are applied; `null` is ignored.
- [ ] Audio elements are stopped and released during permanent destruction.

### Browser and host QA

- [ ] The HTML boots when MRAID is already ready.
- [ ] The HTML boots after a loading host fires `ready`.
- [ ] The HTML self-resolves when a loading host never fires `ready`.
- [ ] A normal browser preview boots without `window.mraid`.
- [ ] The only expected local network error is the unavailable host-provided
      `mraid.js`; investigate every other console error.
- [ ] V2 `viewableChange` pauses and resumes media.
- [ ] V3 `exposureChange` overrides the V2 fallback after first observation.
- [ ] V3 `audioVolumeChange(null)` leaves the current volume unchanged.
- [ ] CTA injection works for every supported global/query override.
- [ ] CTA uses `mraid.open()` in a host and the browser fallback outside one.
- [ ] First-gesture audio is verified in desktop Chromium, Safari/WebKit, iOS,
      and Android WebView environments.
- [ ] Hidden/background transitions stop active media and timers.
- [ ] The final submission passes the AppLovin static validator.
