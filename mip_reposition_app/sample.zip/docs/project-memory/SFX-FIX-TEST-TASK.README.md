# iOS-Safe SFX Interaction Lab

A reusable one-page React/Vite test build for verifying playable-ad sound effects across iOS, Android, and desktop devices. It exercises immediate taps and overlapping taps using the reskin `Bat 03` cue, a three-card cyclic swipe, looping scratch, spin, wrong/match feedback, a delayed reveal, the isolated Halloween hit for successful interactions other than swipe, CTA Part 1, and a responsive video endcard.

The build uses persistent per-cue audio pools, native capture-phase gesture handlers, exact-element priming, bounded rejected-play retries, MRAID volume/viewability handling, and lifecycle-aware pause policies.

## Flow

1. Complete all seven interaction cards on the scrollable page.
2. A full-screen CTA Part 1 visual fades in after the final interaction handoff.
3. The build advances on the cue's `ended` event or a visibility-aware fallback.
4. CTA Part 2 and the responsive looping video endcard appear.
5. The complete endcard is clickable through guarded AppLovin MRAID handling.

## Commands

```powershell
npm install
npm run typecheck
npm run test:sound
npm run test:flow
npm run dev
npm run build
npm run preview
```

`npm run build` produces `dist/sfx_interaction_lab_template_al.html` and validates its size, MRAID bridge/helper surface, script format, embedded resources, protocol strings, and inline JavaScript syntax.

The missing local `mraid.js` request is expected outside an AppLovin container.

## Documentation

- Portable cross-project implementation handoff: [`MD/IOS_SAFE_SFX_IMPLEMENTATION_GUIDE.md`](MD/IOS_SAFE_SFX_IMPLEMENTATION_GUIDE.md)
- Active implementation rules: [`docs/IOS_SAFE_SFX_TEMPLATE_GUIDELINES.md`](docs/IOS_SAFE_SFX_TEMPLATE_GUIDELINES.md)
- Preserved cross-project knowledge: [`docs/project-memory/README.md`](docs/project-memory/README.md)

Automated browser checks are useful, but physical first-gesture testing in the real AppLovin iOS container remains required before shipping a derived build.
