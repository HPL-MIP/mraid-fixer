# AGENTS.md - Web Development Builds

## Instruction Scope
Direct instructions in chat override this file.

This repository is for polished single-file web experiences and client-ready HTML builds. It may still contain code or scripts inherited from playable ad templates, but new work should use web-development naming, web-oriented lifecycle terms, and Applovin-only output unless the user explicitly asks for another target.

## Stack
TypeScript, Vite, vite-plugin-singlefile, WebP, MP3 96kbps, and optional Phaser 3.90 for canvas-heavy interactive work.

Build target: Applovin (`al`) HTML only.

Deprecated multi-network adapters, build branches, validators, lifecycle shims, and CTA paths should be removed or ignored unless the user explicitly asks to restore them.

## Porting To A New Web Project
1. Update naming fields in [scripts/build-networks.mjs](scripts/build-networks.mjs) or the active build script. These fields drive the output filename.
2. Update default CTA/client destination URLs in [src/constants.ts](src/constants.ts). Runtime client-provided CTA links must override defaults.
3. Adjust the Depth Map below to match the project's visual layer needs.
4. Update [src/iteration.ts](src/iteration.ts) for this project's variants, debug flags, and date/time tester settings.
5. Replace project assets under `Assets/`; every runtime asset must live in `Assets/images/...`, `Assets/audio/...`, or `Assets/videos/...`.
6. Run `node scripts/convert-assets.mjs` after adding or changing assets.
7. Rewrite `features/` modules for the new interaction, page section, widget, or visual system. Keep the single-responsibility split.
8. Update this AGENTS.md with any project-specific pitfalls discovered during implementation.

## Structure
Prefer this web-oriented structure for new work:

```text
src/
  main.ts                 # Bootstrap, DOM readiness, MRAID gating, responsive setup
  constants.ts            # Design coords, default CTA URL, debug keys, layer depths
  networks.ts             # triggerCTA(), initMraid(), bindLifecycle(), notifyAppX()
  analytics.ts            # trackEvent() -> guarded SDK/debug output
  iteration.ts            # Variant and debug config
  utils/
    responsive.ts         # sx(), sy(), sd() for canvas layouts
    timeDebug.ts          # Dev-only global time tester when date/time matters
  scenes/
    BootScene.ts          # Critical preload + deferred asset manifest when Phaser is used
    AppScene.ts           # Orchestrator only - wires feature modules and lifecycle
    cta.ts                # CTA panel + redirectToClient() -> triggerCTA()
  features/               # Single-responsibility modules; no direct SDK calls
Assets/
  images/
  audio/
  videos/
scripts/
  convert-assets.mjs      # Converts PNGs in Assets/images to WebP and re-encodes MP3s
  build-networks.mjs      # Single build -> Applovin HTML output
```

If the current code still uses older scene or module names from a game template, treat them as migration targets. Prefer `AppScene`, `features`, `interaction`, `experience`, `flow`, `panel`, or `module` in new documentation and code.

## Responsibility Split
- `features/` modules each own a single concern: one interaction, widget, animation system, state panel, or visual layer.
- Feature modules receive the scene/app context as a constructor arg and own their own objects.
- Feature modules never call ad SDK, MRAID, CTA, or analytics helpers directly.
- `AppScene.ts` or the main orchestration layer creates modules, passes data between them, and calls SDK helpers at lifecycle moments.
- `scenes/cta.ts` owns CTA panel presentation and the client redirect sequence.

## Rules
- Target 60 FPS; never below 30 on mid-range Android.
- Keep each built HTML under 5 MB.
- Use WebP for raster images and short compressed audio only when audio is required.
- No audio autoplay. Unlock sound only after the first `pointerdown` or user gesture.
- Avoid hardcoded viewport-specific pixels. Use `sx()`, `sy()`, `sd()`, CSS responsive units, CSS variables, or container-aware layout.
- In hot animation/update paths, use `for` loops, object pools, and stable arrays. Avoid per-frame allocation.
- For Phaser images, use `setDisplaySize(sd(...))` unless a documented Phaser workaround requires `setScale`.
- For DOM UI, use semantic HTML and CSS layout instead of canvas text unless the interaction requires canvas rendering.
- Never dim the page via `body` or page background. Use an explicit overlay layer.
- Keep app-authored errors visible or recoverable with fallback UI, `console.warn`, or guarded debug logging.

## Optional Phaser Config
Use Phaser only when the experience benefits from canvas rendering. When Phaser is used, keep this config shape:

```ts
{
  type: Phaser.AUTO,
  transparent: true,
  scale: { mode: Phaser.Scale.NONE, width: 1080, height: 1920 },
  render: { antialias: true, pixelArt: false },
}
```

`Scale.NONE` means manual sizing; CSS = viewport px; internal canvas = viewport x DPR.

`antialias: true` is required to avoid jagged scaled WebP assets. Never set it to `false` unless the project intentionally uses pixel art.

## Responsive Layout
Use a 1080x1920 reference for canvas layouts unless the project specifies another design size.

```ts
const s = Math.min(viewW / 1080, viewH / 1920)
const offX = (viewW - 1080 * s) / 2
const offY = (viewH - 1920 * s) / 2
// sx/sy/sd apply offX, offY, s
```

- Poll `visualViewport` during active rendering for rotation and browser chrome changes.
- On change: `app.scale.resize(vw * dpr, vh * dpr)` -> `relayout()`.
- `bindResponsiveResize()`: rAF debounce plus 100/300/600 ms retries.
- Test portrait and landscape before shipping.

## CTA - Applovin And MRAID
All client-ready Applovin HTML builds must request MRAID and use MRAID for CTA clickthroughs when available.

CTA resolution happens at click time from the AppLovin-supported host variables.

Recommended CTA URL priority:

```text
1. window.clickTag
2. window.clickTag1
3. window.clickthrough
4. window.clickThrough
```

CTA click flow:

```text
1. Resolve the CTA URL at click time.
2. Track CTA_CLICKED.
3. Notify the close/exit lifecycle helper if the app has one.
4. If MRAID is usable and `mraid.open` is available, call `mraid.open(clickTarget)` or blank `mraid.open()` when no target is supplied.
5. If MRAID is unavailable, unusable, missing `open`, or throws, return without navigating.
```

MRAID CTA calls must be guarded:

```ts
const hasMraid = typeof window.mraid !== 'undefined'
const canOpen = hasMraid && typeof window.mraid.open === 'function'
const state = hasMraid && typeof window.mraid.getState === 'function'
  ? window.mraid.getState()
  : 'ready'

if (canOpen && state !== 'loading') {
  if (clickTarget) window.mraid.open(clickTarget)
  else window.mraid.open()
}
```

Do not add `window.open`, location navigation, anchor simulation, or another network-specific click fallback.

## Analytics
Use a small event vocabulary that fits web interactions:

```text
DISPLAYED
CTA_CLICKED
PANEL_SHOWN
INTERACTION_STARTED
INTERACTION_COMPLETED
```

Applovin analytics priority:

```text
1. ALPlayableAnalytics.trackEvent(e), guarded by typeof
2. console.log('[Analytics]', e) in debug/dev builds
```

Never assume an injected SDK object includes every method. Guard both the object and the method before calling.

## App Lifecycle
Use web-oriented lifecycle names internally:

```text
appReady()
appStart()
appComplete()
appClose()
```

If a client preview tool requires legacy lifecycle function names, expose them only as thin aliases to the web-oriented helpers and keep them behind `typeof` guards.

Lifecycle helpers should be no-ops when the relevant SDK is absent.

### Pause / Resume / Mute
- Use `document.visibilitychange` for browser-level pause/resume and audio mute behavior.
- Use MRAID `exposureChange` as the primary ad-container viewability signal.
- Fall back to MRAID `viewableChange` / `isViewable()` when only MRAID 2.0 behavior is present.
- Listen for MRAID `audioVolumeChange`; ignore `null`, and only apply volume math when the value is numeric.
- In `bindLifecycle(sceneOrApp)`, apply cached hidden/non-exposed MRAID state immediately once the app context exists.

## MRAID 3.0 Requirements
Applovin (`al`) builds must inject exactly one early request:

```html
<script src="mraid.js"></script>
```

Creative requirements from MRAID 3.0 and common validator expectations:
- Request `mraid.js` as early as possible and exactly once.
- Wait for both DOM readiness and MRAID readiness before starting rich media behavior.
- Use `mraid.getState()` together with `mraid.addEventListener('ready', ...)` so startup still works if the container fires `ready` before the listener attaches.
- Guard access to `mraid` and all MRAID methods with `typeof` checks.
- Use `mraid.open(url)` for clickthroughs when available.
- Do not use `window.open`, `location.href`, `location.assign`, `location.replace`, or anchor simulation for CTA behavior.
- Include `<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">` or an equivalent mobile viewport tag.
- Do not assume nested iframes can access native MRAID.
- Use `exposureChange` as the MRAID 3.0 viewability signal, then degrade to `viewableChange` / `isViewable()`.
- Listen for `audioVolumeChange`; `null` is valid and must be ignored.
- Listen for `error`; if the app cannot run or assets cannot load, show a fallback UI or call `mraid.unload()` when appropriate.
- Listen for `stateChange` when using state-changing behavior such as close, expand, or resize.
- Call `setResizeProperties()` before `resize()` if resize is intentionally supported.
- Do not use `resize()` for full-screen takeovers; use `expand()` only when the project intentionally supports it.
- Avoid `useCustomClose()` and custom close indicators in MRAID 3.0. The host provides the close control.
- Call `supports()` before optional native features such as `storePicture`, `createCalendarEvent`, `getLocation`, VPAID, SMS/tel, or inline video behavior.
- Use `playVideo()` for native video playback cases instead of `mraid.open(videoUrl)`.

Implementation requirements for `networks.ts` / `networks.js`:
- Export `initMraid(timeoutMs = 2000, detectTimeoutMs = 500)` and call it at module load.
- If `window.mraid` is missing at module load, poll briefly before resolving as no-MRAID.
- If MRAID exists and `mraid.getState() === 'loading'`, wait for `ready` and self-resolve after `timeoutMs` so startup never hangs.
- `main` / boot must `await initMraid()` before constructing the primary app or Phaser instance.
- On setup, seed cached visibility from `mraid.isViewable()` when available.
- Register MRAID callbacks once, before any scene/app module is ready:
  - `mraid.addEventListener('error', (message, action) => ...)`
  - `mraid.addEventListener('stateChange', state => ...)`
  - `mraid.addEventListener('exposureChange', exposedPercentage => ...)`
  - `mraid.addEventListener('viewableChange', viewable => ...)`
  - `mraid.addEventListener('audioVolumeChange', pct => ...)`
- If the app renders its own close control, wire it to a guarded close helper and notify app close before calling `mraid.close()`.

## Date And Time Sync
When an experience displays date or time, it must use runtime time from the browser/device. Never bake dates, countdown starts, or clock values into the build unless the user explicitly requests fixed demo data.

Production requirements:
- Use `Date.now()` / `new Date()` at runtime as the source of current time.
- Use `Intl.DateTimeFormat` for display formatting.
- Use IANA time zone names with the `timeZone` option when a specific zone is required. Do not hardcode UTC offsets.
- Handle daylight saving time, month/year rollover, midnight/day rollover, and leap-year dates through native date APIs.
- Update visible clocks at least once per second while they are visible.
- Recompute date labels after timezone or locale changes instead of caching formatted strings indefinitely.
- Keep timezone, locale, and format options configurable in `constants.ts` or `iteration.ts`.
- Test narrow mobile layouts for long zone names, AM/PM labels, and translated month/day names.
- Do not trigger CTA, analytics, or lifecycle events from date/time debug controls.

Recommended formatter pattern:

```ts
const formatter = new Intl.DateTimeFormat(locale, {
  timeZone,
  weekday: 'short',
  month: 'short',
  day: 'numeric',
  hour: 'numeric',
  minute: '2-digit',
  second: '2-digit',
  timeZoneName: 'short',
})

const label = formatter.format(new Date())
```

## Dynamic Time Tester
Every project should include a dev-only global time tester when time/date display matters.

Purpose:
- Quickly verify date and clock formatting across global time zones.
- Catch DST, locale, AM/PM, day rollover, and narrow mobile layout issues.
- Keep it as a development display tool, not a user-facing production panel.

Default behavior:
- Define `DEBUG_TIME_TESTER_ENABLED`, `DEBUG_TIME_KEY`, and `DEBUG_TIME_ZONES` in [src/constants.ts](src/constants.ts) or [src/iteration.ts](src/iteration.ts).
- Default key: `T`.
- Pressing the debug key flashes a compact time/date overlay.
- Repeated key presses while the overlay is visible cycle through configured zones.
- The overlay auto-hides after a short delay, usually 2-4 seconds.
- The tester must never trigger CTA, analytics, or lifecycle events.

Recommended time zones:

```ts
export const DEBUG_TIME_ZONES = [
  'UTC',
  'America/Los_Angeles',
  'America/New_York',
  'Europe/London',
  'Europe/Paris',
  'Asia/Taipei',
  'Asia/Tokyo',
  'Australia/Sydney',
] as const
```

Implementation notes:
- Use `Intl.DateTimeFormat` with the IANA `timeZone` option. Do not hardcode offsets.
- Render the zone label, date, local time, and optional GMT offset.
- Update the visible time at least once per second while the overlay is shown.
- Keep the overlay on a top debug layer that does not resize the app or block CTA clicks when hidden.
- Make text responsive and safe in both portrait and landscape.
- Disable by default in final client builds unless the user explicitly wants the tester included.

## Local Testing
Use Vite for local browser testing:

```powershell
npm install
npm run dev
```

The current dev server default is `http://127.0.0.1:5173/`.

For pages with date/time display:
- Open the dev URL in a browser.
- Press `T` to flash the dynamic time tester.
- Press `T` again while the overlay is visible to cycle through configured global time zones.
- Verify visible time/date text in portrait and landscape.
- Keep the time tester gated behind dev/debug flags so normal production builds do not show it.

## Build
Vite outputs IIFE format:

```js
{
  build: {
    rollupOptions: {
      output: { format: 'iife' },
    },
    modulePreload: false,
  },
}
```

Build script requirements:
- Build Applovin (`al`) only.
- Output HTML only. Do not produce zip packages unless the user explicitly asks.
- Inject `<script src="mraid.js"></script>` exactly once.
- Strip `type="module"` and `crossorigin` from bundled script tags because submitted single-file HTML should run synchronously in client preview containers.
- Preserve the mobile viewport meta tag.
- Keep runtime client CTA overrides intact.

### Network Tag Comment
Every output HTML file must begin with this exact first line, before `<!DOCTYPE html>`:

```html
<!-- ad-network: Applovin | al -->
```

In the active build script, prepend the comment before writing the HTML file:

```js
const networkComment = '<!-- ad-network: Applovin | al -->\n'
fs.writeFileSync(outPath, networkComment + htmlContent)
```

Parsers must treat `<!-- ad-network:` as the sentinel. The comment must be on line 1.

Applovin output row:

| Target | Tag | Injected | Zipped | Included |
|---|---|---|---|---|
| Applovin | al | `mraid.js` | no | yes |

Output is grouped by target network. All iteration HTML files sit together in the Applovin folder:

```text
dist/
  Applovin/
    project_web_vendor_concept_01_interactive_na_noseason_en_short_na_al.html
    project_web_vendor_concept_01_interactive_na_noseason_en_full_na_al.html
```

Recommended naming fields:

| Field | Description | Example |
|---|---|---|
| Project Code | Short project code | `ws`, `site`, `app` |
| Format | Build format | `web`, `mip`, `html` |
| Vendor | Studio / vendor code | `grhpl` |
| Concept Name | Creative or page concept | `landing`, `onboarding`, `promo` |
| Concept # | Iteration number, zero-padded | `01`, `02`, `03` |
| Experience Type | Interaction style | `static`, `interactive`, `animated` |
| Content Source | UGC or non-UGC marker when relevant | `na`, `ugc`, `nougc` |
| Seasonal | Seasonal tie-in | `noseason`, `xmas` |
| Language | Locale code | `en` |
| Length | Variant length/state | `short`, `full`, `15sec` |
| Size | Region / size code | `na` |
| Network | Applovin tag | `al` |

If built output contains `console.error` from Phaser or bundled node modules, prefer dropping it at bundle time instead of editing library source. Add this option to the shared Vite config if present:

```js
export default {
  esbuild: {
    pure: ['console.error'],
  },
}
```

## Asset Loading And Conversion
- Every runtime asset must live under `Assets/images/...`, `Assets/audio/...`, or `Assets/videos/...`.
- Source drops outside `Assets/` are references only. Do not import runtime assets directly from scratch folders, downloads, desktop paths, or design handoff folders.
- After adding or changing assets, run `node scripts/convert-assets.mjs`.
- The converter changes PNG files under `Assets/images` to WebP quality 75 and re-encodes MP3 files under `Assets/audio` to 96 kbps mono. Project-specific preparers may validate and stage supplied MP4s under `Assets/videos` without re-encoding when they already meet delivery requirements.
- Import optimized assets from JS/TS so vite-plugin-singlefile can inline them.
- Leave DOM media elements without raw relative `src` values when they need to be inlined; assign imported asset URLs from JS at boot.
- Critical first-frame assets should stay under 200 KB when practical.
- Deferred assets include audio, overlays, secondary UI, and non-blocking media.

## Depth Map
Define depths as named constants in [src/constants.ts](src/constants.ts). Never use magic numbers in scene code.

| Layer | Depth |
|---|---|
| Background | 0 |
| Content objects | 1-10 |
| Brand / header | 17 |
| Dim overlay | 20 |
| Modal / result UI | 21 |
| CTA input | 25 |
| Debug overlay | 30 |

## Ship Checklist
- [ ] Built HTML under 5 MB.
- [ ] All runtime assets live under `Assets/images`, `Assets/audio`, or `Assets/videos`.
- [ ] `node scripts/convert-assets.mjs` has been run after asset changes.
- [ ] All raster assets are WebP unless there is a clear exception.
- [ ] FPS >= 55 under CPU throttle for animated/canvas experiences.
- [ ] Portrait and landscape pass.
- [ ] MRAID requested exactly once.
- [ ] MRAID ready path cannot block startup forever.
- [ ] CTA resolves `clickTag`, `clickTag1`, `clickthrough`, and `clickThrough` in order at click time.
- [ ] CTA uses guarded `mraid.open(clickTarget)` or blank `mraid.open()` with no browser navigation fallback.
- [ ] Audio is muted/locked until user gesture.
- [ ] Date/time UI uses runtime time and `Intl.DateTimeFormat`.
- [ ] Time/date display has been tested across configured `DEBUG_TIME_ZONES`.
- [ ] Debug time tester is disabled or intentionally included for client review.
- [ ] No `console.error` in output.
- [ ] No `type="module"` or `crossorigin` on final bundled script tags.
- [ ] No stale non-Applovin SDK branches in the built output.

## Pitfalls
| Issue | Fix |
|---|---|
| Rotation stuck | Use `Scale.NONE` plus visualViewport polling for canvas work; use responsive CSS for DOM work. |
| Mobile aliasing | Canvas = viewport x DPR; keep `antialias: true`. |
| FPS drop on resize | Use rAF debounce and delayed resize retries. |
| MRAID crash | Guard every `mraid` object and method access with `typeof`. |
| Assets not inlined | Import assets from JS/TS so vite-plugin-singlefile can inline them. |
| Upload checker reports a `${name}` resource | Do not construct CSS `url(...)` values with JavaScript template interpolation. Declare fonts and other CSS resources in static stylesheets so Vite emits a literal base64 `data:` URL. |
| Runtime asset imported outside `Assets/` | Move it to `Assets/images`, `Assets/audio`, or `Assets/videos`, then run the active asset-preparation script. |
| Bundle > 5 MB | Compress WebP, reduce audio length/bitrate, remove unused variants. |
| Built output contains library `console.error` | Add `esbuild: { pure: ['console.error'] }` in the shared Vite config. Do not edit library source. |
| Audio blocked | Gate audio unlock on first pointer/user gesture. |
| Letterbox | Avoid `Scale.FIT`, `EXPAND`, and `CENTER_BOTH` for Phaser builds; handle responsive sizing manually. |
| DOM script runs before body exists | Wrap boot in DOM readiness: `if (document.readyState === 'loading') addEventListener('DOMContentLoaded', boot) else boot()`. |
| Preview container strips custom DOM | Create required root elements at runtime and pass element references, not string selectors. |
| iOS black screen with canvas | Use only one Phaser/WebGL app instance per page. Render static backgrounds as CSS images when possible. |
| iOS hangs on font load | Race font loading against a short timeout before startup. |
| iOS hangs on MRAID ready | `initMraid()` must check `getState()` first and self-resolve after about 2 seconds. |
| External `src=` survives build | Do not leave raw relative DOM asset paths in `index.html`; assign imported URLs from JS. |
| Audio keeps playing when hidden | Use `visibilitychange` to mute/suspend audio when `document.hidden`. |
| `mraid.open()` is unavailable or throws | Guard readiness and fail safely without browser navigation. |
| MRAID listener wired too late | Call `initMraid()` at module load and cache viewability/audio state before app startup. |
| Upload checker misses or rejects MRAID calls | Keep the exact standalone `if (mraid.getState() === "loading") { mraid.addEventListener("ready", init) } else { init() }` gate and guarded `mraid.open(url)` in the unminified early head helper. Do not combine the equality with another condition or rely on minified bundle aliases. |
| MRAID `exposureChange` not handled | Register both `exposureChange` and `viewableChange`; seed from `isViewable()` when available. |
| MRAID `audioVolumeChange` mishandles null | Ignore `null`; apply volume only when `typeof pct === 'number'`. |
| MRAID `error` listener missing | Register an early `error` listener and surface failures with guarded warnings or fallback UI. |
| MRAID `stateChange` listener missing | Register it with the other early MRAID callbacks when state-changing behavior is present. |
| Client CTA URL ignored | Resolve URL at click time and prioritize runtime globals/query params before defaults. |
| Clock shows stale build time | Use runtime `new Date()` / `Date.now()` and refresh visible labels at least once per second. |
| Timezone display is wrong around DST | Use `Intl.DateTimeFormat` with IANA `timeZone` names, never fixed offsets. |
| Date label breaks on mobile | Test long month/day/zone labels in portrait and landscape; use responsive text constraints. |
| Debug time tester ships visibly | Gate with a debug flag and hide/disable it in final client builds unless requested. |

## Courtyard MIP/SIP 01 project notes

- The active build is a responsive DOM/CSS Courtyard pack-opening experience. Gameplay and CTA Part 1 stay in a centered 1080×1920 portrait stage; only CTA Part 2 and the standalone SIP switch between portrait and landscape videos.
- Produce exactly `courtyard_acslanot_mip_20260924_01_ecomm_game_packopening_human_none_none.html` and `courtyard_acslanot_sip_20260924_01_ecomm_product_carousel_human_none_none.html`.
- Browse five live pack assets in an infinite drag carousel. A side-pack tap centers it; a centered-pack tap selects it. Start on football and map football/red, blue ball/blue, multicolor Press Start/green, gold Press Start/gold, and basketball/orange. The two Press Start packs share their icon.
- Render the infinite carousel on a continuous cylindrical front arc: drag progress drives each pack's horizontal sine arc, cosine depth, and Y-axis angle. Keep the centered pack full size, adjacent packs smaller, outermost packs smaller again, and fade the rear crossover to zero so wrapping is seamless. Once non-selected packs finish their 350 ms selection fade, keep them explicitly hidden through the tear handoff so repaints cannot flash them back onscreen.
- Tear the selected live pack with complementary SVG clip polygons. Below 75% resets over 220 ms; at or above 75% auto-completes, peels the left-high strip over 450 ms, and enters the 2.5-second glow/star reveal.
- Keep the tear tutorial hand animation dormant outside `tear-ready`; entering or returning to `tear-ready` must start a fresh loop whose hand fades in only during the opening frames, preventing hidden animation time from surfacing mid-gesture.
- As soon as the 2.5-second reveal resolves into the green card, automatically run the full 4.3-second green→red→blue→pink→cyan→gold Y-spin with no green-card tap state or tutorial hand. Race through the first four transitions in 550/600/650/700 ms, then smoothly ease from cyan into gold over 1.8 seconds without an abrupt speed drop. Swap artwork at the true edge-on point, hold gold for 450 ms, then flip to CTA Part 1 over 700 ms. Trim/fade the spin cue to the same 4.3-second duration.
- Keep the soft and hard golden-yellow glows inside the live card button, behind its artwork, so they inherit the Y-spin and final CTA flip. Bake RGB 255/211/48 into their WebPs while preserving alpha; do not use runtime hue/saturation filters or screen blending because WebKit can shift them orange. Start CTA's single 260 ms size/opacity settle when the final 700 ms flip begins, so the halo is fully enlarged before the CTA face swaps in at 350 ms.
- CTA Part 1 advances to the supplied looping video when its cue ends or after a 3.2-second visible-time fallback. Preserve video phase through orientation changes and make the complete endcard clickable. Do not add date/time UI.
- Match MIP CTA Part 2 and standalone SIP to the edited SIP framing: both use the same shared controller and video pair, center the frame, and on viewport ratios above 1.8 cap it to 9:16 in portrait or 16:9 in landscape with the edited near-black orientation backgrounds.
- Ship exactly Tap, Swipe, Scratch, Reveal, Spin, CTA Part 1, and CTA Part 2 cues in the MIP. Preserve persistent two-voice pools, exact-element priming, rejected-play retries, MRAID volume, and visibility-aware pause/resume. SIP ships no gameplay WebPs or MP3s.
- Source the carousel cue from `New Assets/Updated Swipe.wav`, transcode it to the standard 96 kbps mono runtime MP3, and play it at 55% per-cue volume so rapid overlapping swipes remain softer.
- For iOS first-swipe reliability, prime both persistent Swipe voices before all other deferred cues on the carousel's capture-phase `pointerdown`, then request the changed-snap Swipe synchronously through `playFromGesture` on the native release event. Keep later two-voice overlap and rejected-play retry behavior.
- Preserve the early readable MRAID helper, literal click-time four-variable chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached exposure/volume, and guarded `mraid.open`. Final HTML must contain no `window.open`, location navigation, or anchor simulation anywhere.
- Run `npm run typecheck`, `npm run test:pack`, `npm run test:sound`, `npm run test:dynamic`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iPhone/AppLovin first-gesture audio verification remains separate.

## Courtyard MIP/SIP 02 project notes

- The full-viewport opened-card sparkle overlay must fade to zero during the final third of the 2.5-second reveal. Its soft and hard gold glows must finish at the settled result opacities so changing from `revealing` to `result` never removes stars or glow in a single frame.
- Build MIP02 and SIP02 alongside MIP01/SIP01 without importing MIP02 code or assets into MIP01. MIP01 and SIP01 outputs must retain their established hashes.
- MIP02 starts with three static packs. A pack tap selects or changes the choice and its background; Continue is required before the pack opens.
- On the initial three-pack screen, reuse MIP01's hand artwork as a center-pack tap guide with a contact pulse. Dismiss it on pack selection; after five visible seconds without continuing, reuse it below the Continue button. Reset that idle timer when another pack is selected, clear it on Continue, pause it with lifecycle visibility, and support the same delayed Continue cue on the optional second choice.
- Match the approved starting layout: gold starts left, multicolor Press Start starts center, and blue starts right, so the default centered pack matches the green starting background. On the first pull, the chosen pack animates to center and the other two rotate around it. On the retry choice, the two unopened packs remain upright, non-overlapping, and side by side even after one is selected.
- Normalize the chooser artwork's visible bounds: compensate for the blue and gold source PNG padding, counter the apparent size loss of the unrotated center pack, and use glow/position rather than a selection-only size jump.
- Reuse MIP01's exact tear geometry, 42-particle seam VFX, 75% threshold, 220 ms reset, 450 ms peel, fresh tear-hand loop, golden-card/glow/star assets, and 2.5-second reveal timing. MIP02 resolves the random graded card at MIP01's final-card swap point, with no colored-card spin and no CTA Part 1.
- MIP1's tear coordinates are relative to its inset game panel. In MIP2's full-stage opening layer, use the converted stage coordinates (`top: 22.637%`, `width: 45.504%`) plus the matching converted hand/input bounds. Fade gameplay backgrounds to zero during reveal and place a full-viewport black dim layer beneath the star field so transparent VFX pixels cannot expose a rectangular gameplay background.
- Randomize each reveal uniformly from the nine supplied graded cards. The optional second pull cannot repeat the first card or reopen the first pack.
- After the first result, Continue shows `Test another pack?`; No goes directly to CTA Part 2, while Yes shows the two remaining packs. After the second result, Continue goes directly to CTA Part 2 with no third attempt.
- Keep card name, set/grade, value, prompts, and Yes/No buttons as responsive DOM text. MIP02 ships Tap, Scratch, Reveal, CTA Part 1, and CTA Part 2 cues. Play CTA Part 1 whenever either randomized slab finishes revealing; prioritize both persistent CTA Part 1 voices during the native tear gesture so delayed playback remains iOS-safe, with rejected playback retained for the next exact-gesture retry.
- MIP02 and MIP03 DOM copy uses locally embedded Inter: weight 700 for headings, card names, value pills, and buttons; weight 600 for set/grade lines, retry prompts, and supporting copy. Keep `font-synthesis: none` so WebKit cannot substitute synthetic weights.
- Keep the result name, set/grade, and value pill in one flex-column header. Do not independently pin their vertical positions: long names such as Mega Gardevoir, Mega Tokyo's Pikachu, and Poncho-Wear Pikachu must reserve a second title line without overlapping the grade or value, in both result and retry-prompt layouts.
- Use the supplied MIP02 `Group 230.png` Continue artwork for both the pack-choice and revealed-card Continue gates; retain semantic button labels and native disabled states.
- Keep Continue hidden during the golden-card reveal and show it only after the graded card resolves. Enabled Continue/Yes/No controls are slightly translucent at rest and reach full opacity while pressed, matching the supplied button-state note.
- Match the approved result references after the reveal: remove the reveal-only cloudy `card-opened` layer, retain only fine ambient stars and a restrained gold halo, and position the graded card at `top: 30.5%; width: 48%`. Narrow the square golden-card VFX to `scaleX(.82)` and center it at `top: 49.1%` so its internal white silhouette matches both the visible dimensions and center of the graded slab without resizing or distorting the reward artwork. Dissolve gold into the reward continuously from 58–90% of the 2.5-second reveal with two linear, compositor-friendly opacity animations. Do not animate brightness, saturation, contrast, blur, or other CSS filters during this crossfade; translucency over the white card supplies the washed-out intermediate look without mobile repaint stutter. Promote the gold and reward layers with `will-change` and hidden backfaces, and avoid intermediate eased opacity keyframes that reset velocity. Keep the first pack-choice and tear background crisp, full-opacity, and unmasked. The golden-card animation and the revealed-card Continue screen use only the clean black star background. Do not show the feathered gameplay background until the user presses that Continue button and enters the retry prompt. From the retry prompt through the second pack choice and second tear, use one reduced-opacity, blurred, dimmed, broadly feathered image constrained to the centered 9:16 playable stage; never add a duplicate viewport-sized gameplay background. Those later phases add full-viewport screen-blended fine stars above the feathered image. On the retry prompt, keep both unopened packs upright with no rotation, use 31% by 29% stage boxes, normalize blue/gold source padding, place them at `top: 35.8%`, and use 4.3% outer insets so their visible inner edges meet the revealed slab. Keep the smaller centered reward and vertical divider between Yes and No. Keep `inset: auto` before viewport layers' `left`/`top`; declaring it later resets those anchors and shifts the layer half a viewport up-left.
- MIP02 CTA Part 2 and SIP02 share the supplied 02 portrait/landscape videos and the existing orientation-aware endcard controller.
- Produce exactly four AppLovin files: the established MIP01/SIP01 pair plus `courtyard_acslanot_mip_20260924_02_ecomm_game_packopening_human_none_none.html` and `courtyard_acslanot_sip_20260924_02_ecomm_product_carousel_human_none_none.html`.
- Run `npm run typecheck`, `npm run test:pack`, `npm run test:pack2`, `npm run test:sound`, `npm run test:dynamic`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iPhone/AppLovin first-gesture audio verification remains separate.

## Courtyard MIP/SIP 03 project notes

- Build MIP03 and SIP03 as isolated entry points beside MIP01/SIP01 and MIP02/SIP02. Do not import MIP03 code or assets into earlier iterations.
- MIP03 preserves MIP02's chooser, Continue gates, tear geometry and particles, golden-card crossfade, random nine-card pool, optional second pull, responsive result layout, iOS-safe audio pools, and orientation-aware video endcard.
- Replace MIP02's direct post-pull CTA transition with a missed-card finale. Declining the optional retry automatically opens both remaining packs together; completing a second user pull automatically opens the one remaining pack. A session never repeats a reward among user pulls or missed-card reveals.
- The two-card finale uses the semantic heading `Cards you've missed`, places one pack/card upper-left and the other lower-right, runs both top-strip peels simultaneously, and positions each card's metadata in the open space beside it. The one-card finale uses `Card you've missed`, centers the pack/card, and places the metadata below the slab.
- Finale order is automatic and pause-aware: unopened pack(s), 1.05-second peel, 2.5-second gold-to-slab reveal, final star pop and metadata, 2.2-second hold, then CTA Part 2. Keep the peeled strips near their packs so they never cross the heading.
- Keep the feathered reduced-opacity gameplay background and fine star field behind all missed-card stages. The missed-card slab uses the same undistorted reward image and settled gold glow as the normal MIP02 result.
- MIP03 ships Tap, Scratch, Reveal, CTA Part 1, and CTA Part 2. Prioritize CTA Part 1 during native tear gestures, retain rejected-play retries, and use CTA Part 1 again when the missed slabs finish revealing.
- MIP03 CTA Part 2 and SIP03 share the supplied MIP3 portrait/landscape videos and the existing normalized-phase endcard controller.
- Produce exactly six AppLovin files: the established 01 and 02 pairs plus `courtyard_acslanot_mip_20260924_03_ecomm_game_packopening_human_none_none.html` and `courtyard_acslanot_sip_20260924_03_ecomm_product_card_human_none_none.html`.
- Run `npm run typecheck`, `npm run test:pack`, `npm run test:pack2`, `npm run test:pack3`, `npm run test:sound`, `npm run test:dynamic`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iPhone/AppLovin first-gesture audio verification remains separate.

## Archived Chef Preserve MIP 02 project notes

- The active build is a responsive DOM/CSS Chef Preserve wheel. Gameplay, Try Again, and CTA Part 1 stay in a centered 1080×1920 portrait stage; only CTA Part 2 and SIP have landscape layouts.
- Produce exactly `chefpreserve_acslanot_mip_20260923_02_ecomm_game_spinwheel_human_dt_unique.html` and `chefpreserve_acslanot_sip_20260923_02_ecomm_product_carousel_human_dt_unique.html`.
- A native wheel press starts one 3-second automatic spin through at least five turns. The first result is 50/50 retry or win across the matching three sector centers; after a retry, the next user spin is guaranteed to win.
- Try Again blurs the live game, plays `reference-try-again.mp3`, and auto-resets after 1.5 visible seconds. Extra wheel presses while spinning or retrying are ignored; Shop Now remains available.
- CTA Part 1 uses the supplied SAVE $83, product, review, confetti, and CTA artwork. It and CTA Part 2/SIP show `Today Only,` plus the browser-local long English date in the Inter 24pt SemiBold font extracted from the supplied SIP HTML.
- CTA Part 2 and SIP use the supplied 854×1138 portrait and 1138×854 landscape MP4s, preserve normalized playback phase through rotation, and make the complete video clickable.
- Ship exactly Tap, Wheelspin, Try Again, CTA Part 1, and CTA Part 2 cues in the MIP. Preserve the iOS-safe persistent two-voice pools, exact-element priming, rejected-play retries, and visibility-aware pause/resume. SIP ships no gameplay WebPs or MP3s.
- Preserve the early readable MRAID helper, literal click-time four-variable chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached exposure/volume, and guarded `mraid.open`. Final HTML must contain no `window.open`, location navigation, or anchor simulation anywhere.
- Run `npm run typecheck`, `npm run test:wheel`, `npm run test:sound`, `npm run test:dynamic`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iPhone/AppLovin first-gesture audio verification remains separate.

## Archived Seed MIP 01 project notes

- Reference: `New Assets/Layout and Flow.jpg`. The active build is a responsive 5×6 DOM/CSS match-3 game using the four supplied Seed product cutouts, goal checks, tutorial hand, and Claim Your Offer artwork.
- Produce exactly two AppLovin files: `seed_acslanot_mip_20260921_01_ecomm_game_match3_human_dd_none.html` and `seed_acslanot_sip_20260921_01_lingyun_product_review_human_dd_none.html`.
- A direct horizontal or vertical match of 3+ checks one unfinished product goal. Goal order is unrestricted, repeated completed products do not advance progress, no power-ups are created, and scripted refills must remain cascade-free while keeping a move for every unfinished goal.
- CTA Part 1 follows the final flow-board panel: blurred gameplay, Seed logo, limited-offer badge, 25%-off promo, live normal-case long English device date, 24-hour Hrs/Min/Sec countdown, DOM savings card, framed product photo, and CTA. Landscape preserves the same centered portrait-stage composition.
- The offer deadline starts on MIP CTA Part 1 or SIP reveal, uses wall-clock time, continues while hidden, carries into CTA Part 2, and clamps at zero. It is intentionally session-local.
- CTA Part 2 and the SIP use the supplied `[HB] seed_acslanot_sip_20260921_01` portrait/landscape videos. Overlay only the same live date and countdown in the reserved space between baked offer/review content. Preserve video phase on orientation changes and keep the complete endcard clickable.
- Ship exactly Tap, Swipe, Wrong, Match Complete (`stack_complete.mp3`), CTA Part 1, and CTA Part 2 cues in the MIP. Use `ReferenceSfxController` two-voice pools, capture-phase native priming, rejected-play retries, and visibility-aware pause/resume. The SIP ships no MP3s or gameplay WebPs.
- Preserve the early readable MRAID helper, literal four-variable click chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached exposure/volume, guarded `mraid.open(clickTarget)` / blank `mraid.open()`, no browser navigation fallback, and the exact `CTA_CLICKED` browser-preview log when MRAID is absent.
- Run `npm run typecheck`, `npm run test:match3`, `npm run test:sound`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iOS/AppLovin first-gesture audio verification remains separate.

## Archived EllaOla MIP 12 project notes

- Reference: `New Assets/Layout and Flow.jpg`. Match its portrait EllaOla header, sale banner, fixed pointer, oversized wheel, center button, tutorial hand, blurred Try Again result, and 30% OFF product reward panel.
- Let MIP 12's wheel bleed outside its centered 1080x1920 stage in wide viewports; clip only at the viewport. Extend the Try Again blur over that bleed and hide the wheel on the reward screen. MIP 16 keeps its own contained wheel layout.
- Keep gameplay and reward leaves in a viewport-anchored decorative layer so they touch the screen edges in portrait and landscape. MIP 16 also shows mirrored autumn leaves at both bottom corners during gameplay.
- Apply the Try Again and CTA Part 1 blur/tint across the whole viewport, including landscape gutters outside the centered stage. Keep the retry label, reward art, CTA, and reward leaves above the blur.
- Keep the wheel board and pointer together below the viewport blur on Try Again. Render the retry label, reward art, and CTA in a centered foreground stage with no opaque stage background; otherwise landscape CTA Part 1 shows a white rectangle. Use the supplied reference MIP's louder Try Again cue and two-voice HTML audio pools, primed on the native wheel press, for first and repeated retry results.
- Produce four AppLovin files: MIP 12, MIP 16, SIP 12, and SIP 16 at their existing naming pattern.
- The first spin chooses Try Again or 30% OFF with equal probability and stops one of the three corresponding 60-degree wedges under the pointer. After one Try Again, the next spin must stop on a winning wedge.
- Try Again auto-resets after 1.5 visible seconds. Winning reveals CTA Part 1, then CTA Part 2 after the Part 1 cue ends or a 3.2-second visible-time fallback.
- Use the shared `New Assets/Try Again!.png` artwork for the retry label in both MIP 12 and MIP 16.
- CTA Part 2 uses the updated EllaOla portrait and landscape MP4s from `New Assets/Updated Endcard/Updated Videos`, staged under `Assets/videos/ellaola/mip12`. Place `TODAY ONLY,` above a live uppercase device date under the baked 30% OFF text, using the supplied Sofia SemiBold font. The complete endcard is clickable and orientation switching preserves playback phase.
- Request Tap and Wheelspin on the spin button's capture-phase pointerdown before priming deferred cues. Use `ReferenceSfxController` for all five cues; its pool, prime, and retry behavior follows `Reference Project/ellaola_acslanot_mip_20260916_10_ecomm_game_spinwheel_human_none_none.html`. Retry rejected requests on native pointer events. Do not cut off an active CTA Part 1 cue when the video fallback reveals Part 2. Ship only Tap, Wheelspin, Wrong, CTA Part 1, and CTA Part 2 cues.
- Keep Shop Now available throughout, the 1.5-second centered pulse, and click-time resolution of the four supported AppLovin click variables.
- Preserve the validator-readable early MRAID helper, literal four-variable click chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached viewability/volume, and MRAID-only navigation with no browser fallback.
- All transitions, audio, and video pause during browser/MRAID invisibility. Spin progress survives resize and rotation.
- Run `npm run typecheck`, `npm run test:wheel`, `npm run test:sound`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iOS/AppLovin first-gesture audio verification remains a separate delivery check.

## EllaOla MIP 16 project notes

- Reference: `New Assets/MIP16/2026.09.16 - Ella Ola - MIPs 09-16 Back-to-school/Layout and Flow MIP 16.jpg`. Its ZIPs duplicate files already extracted in that folder.
- The MIP 16 drop supplies the mint background, wheel, separate pointer and center button, men's multivitamin product image and name, mint reward glow, and 30% OFF graphic. `New Assets/Try Again!.png` supplies the retry wording over a blurred live wheel. `Page 21.png` has the wording baked in and must not be combined with the separate text image. Reuse the matching EllaOla logo, leaves, heading, instruction, CTA, sale banner, and reward copy from MIP 12.
- Scope MIP 16 reward positioning to `.experience-root[data-mip='mip16']`, because `.reward-panel` is rendered in `.ella-foreground-stage`, outside `.ella-stage`. Match the combined product image at roughly 78% of the centered stage's visible width.
- MIP 16 uses its updated portrait and landscape MP4s from `New Assets/Updated Endcard/Updated Videos`, staged under `Assets/videos/ellaola/mip16`. Its two-line `TODAY ONLY,` and live uppercase date block uses the supplied Sofia SemiBold font and navy placement beneath 30% OFF.
- Both MIP and SIP endcard dates render in uppercase at the enlarged offer-line size while keeping the device date live.
- The MIP 16 wheel source is a 1080×1920 transparent canvas. Crop its wheel to a centered square before rotation, and keep its supplied pointer and button stationary above it.
- Both source wheels include offset outer shadows. The asset preparer splits each shadow into `wheel-shadow.webp`; `WheelExperience` places that image beneath the rotating `wheel.webp`. Keep the MIP 16 crop centered on its wheel face so the fixed shadow stays aligned.

## EllaOla SIP 12 project notes

- `New Assets/Updated Endcard/Updated Videos` supplies both SIPs' portrait and landscape MP4s. The parent `Updated Endcard` folder supplies JPG mockups and Sofia fonts. The videos leave room below 30% OFF for a two-line `TODAY ONLY,` and live uppercase device date block. Stage the media and font under `Assets/`.
- SIP 12 and SIP 16 use the guarded MRAID helper, begin on muted video, and make the whole endcard clickable. Do not embed sound-effect MP3s or gameplay images. Orientation switching preserves playback phase. Pause media and date animation during browser or MRAID invisibility.

## Archived Benjamin MIP 10 project notes

- Reference: `New Assets/Layout and Flow.png`. Match its portrait 3x3 sorting-tray composition and use the supplied header, tray, three products, hand, CTA, reward decorations, and background artwork.
- Produce exactly one AppLovin file: `dist/Applovin/benjamin_acslanot_mip_20260915_10_ecomm_game_sort_human_none_none.html`.
- The board contains four each of coin, pink token, and star across nine slots. Any slot can hold up to four pieces and locks when all four match. Only the topmost product in an unlocked stack is movable.
- Solving all three groups awards $5.00 and is the only path that reveals CTA Part 1. There is no gameplay countdown or elapsed-time completion path.
- Prime `stack_complete.mp3` with the other drop cues on pointer-down and play it instead of the ordinary move cue when a four-item stack locks. Accepted moves use a 360 ms lifecycle-aware settle animation for the moved piece and every stack member whose offset changes.
- Keep the 1080x1920 interaction centered in every orientation. Use `BGOver.png` as a full-viewport cover layer with 3 CSS pixels of overscan.
- Keep Download Now available throughout and make the complete video endcard clickable.
- Use the supplied CTA artwork with a centered 1.5-second pulse peaking at 1.35x one-third into the cycle; keep the button's semantic bounds stationary.
- Play Tap on start, pickup, and CTA gestures; Swipe on accepted moves; Wrong on invalid drops; CTA Part 1 on reward reveal; and CTA Part 2 on video reveal. Do not ship Scratch.
- Prime Swipe and Wrong exact elements during the draggable item's capture-phase `pointerdown` before playing Tap. Preserve pooled Tap behavior, generation guards, iPadOS MacIntel/touch detection, and desktop pointerdown behavior.
- Hide the tutorial hand on player input and reveal it again after six active seconds of inactivity. Keep its source/destination fixed for every visible animation loop, then advance to another movable top item and compatible matching stack only after the next player-active/idle cycle. Skip locked/invalid cells, pause the idle delay with browser/MRAID invisibility, and permanently cancel it at completion.
- After a 1.5-second completion celebration, reveal the reward panel. Reveal CTA Part 2 when CTA Part 1 ends, with a 3.2-second visible-time fallback.
- Render CTA Part 1's supplied `Get your welcome bonus now!.png` and `You’ve just won_.png` as lossless artwork at their native 1015x371 and 754x92 proportions; do not recreate either line with browser text.
- Use the supplied Benjamin MIP 10 portrait/landscape endcard pair from `New Assets` and preserve orientation switching without restarting phase.
- All transitions, audio, and video pause during browser/MRAID invisibility. Board progress survives resize and rotation.
- Resolve the four supported AppLovin click variables at click time and use MRAID-only navigation.
- Preserve the validator-readable early MRAID helper, literal four-variable click chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached viewability/volume, and no browser fallback.
- Run `npm run typecheck`, `npm run test:sort`, `npm run test:sound`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iOS/AppLovin first-gesture audio verification remains a separate delivery check.

## Archived Indeed MIPs 01-10 notes (not active for this build)

- Reference: `New Assets/Layout and Flow.png`. Match its portrait Indeed card-stack composition using supplied artwork rather than recreating branded copy as text.
- Produce exactly ten AppLovin MIP HTML files under `dist/Applovin`, named `indeed_acslanot_mip_20260910_NN_ecomm_game_swipe_human_none_none.html`; do not create SIPs, ZIPs, or root copies.
- Use `Image 1` through `Image 6` in order. Both swipe directions advance, and X/heart controls invoke the matching direction.
- Align every remaining card at the exact same 767x631 position so only the top surface is visible; reveal the next card immediately as the current card leaves.
- Place X and heart at the outer stage edges, vertically centered on the card, and render each MIP background as a full-viewport cover layer with exactly 3 CSS pixels of overscan on every edge. MIPs 02–10 use their supplied 1892x1065 `Page 2` landscape backgrounds when the viewport is landscape; preload both orientations to avoid a rotation flash. MIP 01 has no landscape background and keeps its portrait artwork as the fallback.
- Stage MIP 02's updated portrait from `Codex Image Sep 14, 2026, 07_37_57 PM.png` at 1065x1892 while keeping `Page 2.png` as its landscape background. Stage MIP 07 Image 2 from `Codex Image Sep 14, 2026, 07_49_03 PM.png` and MIP 10 Image 2 from `Codex Image Sep 14, 2026, 07_59_38 PM.png`, each downsampled once to the standard 767x631 card size with lossless WebP storage. Both updated cards arrive with opaque black corners; apply the pixel-identical alpha silhouette and four blank 56x56 corner regions from MIP 07 Image 1 so the rounded edges match the clean cards without touching job text or interior artwork.
- Accept a drag at 18% of rendered card width. Short/cancelled drags reset silently.
- Fade the active card proportionally in either swipe direction, reaching 18% opacity by 65% of its width. Accepted swipes finish fading to zero; cancelled swipes restore full opacity with the reset transition.
- After five dismissals, lock card six, play CTA Part 1, then reveal the orientation-aware video endcard on cue completion with a 3.2-second visible-time fallback. Play CTA Part 2 on video reveal.
- Keep Download Now available throughout and make the complete video endcard clickable.
- Match the baked video endcard Download Now pulse on the interactive CTA artwork: use a centered 1.5-second loop, peak at 1.35x scale one-third into the cycle, keep the semantic button bounds stationary, pause with lifecycle, and disable under reduced motion.
- `Scripts/prepare-indeed-assets.mjs` detects the main 767x631 Indeed-blue frame, repairs exactly 18 oversized cards, and validates lossless visible pixels. Never regenerate or rescale card text.
- Stage only the applicable portrait/landscape backgrounds, six runtime cards, shared logo/heading/controls/CTA, four cues, and that MIP's supplied video pair. Do not ship Scratch, Wrong, fonts, ZIPs, or other MIPs' assets.
- MIP10's supplied landscape video uses the misspelled `landsscape` source filename and must be mapped explicitly.
- Keep the interactive composition centered at 1065x1892 in every orientation. Only the endcard selects an orientation-specific video.
- Preserve exact-element audio priming, mute/volume state, generation guards, iPadOS MacIntel/touch detection, and desktop pointerdown behavior.
- On iOS, let each deferred cue's muted `play()` request settle before pausing and restoring it. An immediate pause can abort first-gesture priming and delay the first Swipe cue until the next interaction; generation guards must prevent late priming callbacks from interrupting real playback.
- Prioritize Swipe exact-element priming in the card deck's capture-phase `pointerdown` before Tap playback and drag state. Keep the real Swipe cue on accepted dismissal rather than making cancelled gestures audible.
- For pooled Tap audio, start the chosen voice first and then prime every other idle Tap voice within the same native gesture. Otherwise later rapid interactions can rotate onto an unprimed iOS element and intermittently lose Tap.
- All timers, transitions, audio, and video pause during browser/MRAID invisibility. Deck progress survives resize and rotation.
- Resolve the four supported AppLovin click variables at click time and use MRAID-only navigation.
- Preserve the validator-readable early MRAID helper, literal four-variable click chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached viewability/volume, and no browser fallback.
- Run `npm run typecheck`, `npm run test:sound`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iOS/AppLovin first-gesture audio verification remains a separate delivery check.

## Clean People MIP 03 project notes

- Produce exactly `cleanpeople_acslanot_mip_20260928_03_lingyun_game_quiz_human_dtd_unique.html` as the only AppLovin output.
- The active interaction is a three-question survey. Keep supplied question headings as optimized WebP artwork and reproduce answer copy with locally embedded Brandon Grotesque Regular/Bold according to `New Assets/Layout and Flow.png`.
- The second answer changes with each question: question 1 uses `Fragrance-Free (Gentle & simple)`, question 2 uses `Safe, natural, or eco-friendly ingredients`, and question 3 uses `Safe for baby & sensitive skin`.
- On selection, crossfade the answer plate to supplied blue artwork, fade the other choices, then advance. After question three, go directly to CTA Part 2 with no CTA Part 1 state, cue, or asset.
- Keep every answer natively disabled until its staggered entrance animation has fully settled. Prime deferred audio on native pointer-down, cancel when movement exceeds the tap threshold, and commit Tap plus selection together on native pointer-up. Ignore pointer-generated clicks (`event.detail !== 0`) while preserving detail-zero keyboard activation, then lock all answers synchronously on commit so a synthetic click after a drag or rapid double taps cannot skip a question.
- Extract the portrait and landscape MP4 payloads from `New Assets/Updated Endcard.html`; do not embed or iframe that document because it would duplicate MRAID and isolate the bridge. Reproduce its runtime date/device overlays at the supplied source-video coordinates and font-size ratios.
- Preserve normalized video phase through rotation, cap extreme portrait/landscape ratios to 9:16 or 16:9, and make the complete endcard clickable.
- Ship only Tap and CTA Part 2 audio, using persistent two-voice pools, first-gesture exact-element priming, MRAID volume, and visibility-aware pause/resume.
- Do not play Tap from the full-screen CTA Part 2 click target. The survey Shop Now artwork uses a continuous 0.8-second linear pulse with no hold at either scale extreme; animate the artwork while keeping semantic button bounds stationary.
- Run `npm run typecheck`, `npm run test:sound`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iOS/AppLovin first-gesture audio verification remains a separate delivery check.

## Benjamin MIP 06 project notes

- The active build is a responsive DOM/CSS 5×5 match-3 game based on `New Assets/Layout and Flow.png`. Produce exactly `benjamin_acslanot_mip_20260929_06_emily_game_match3_human_none_none.html`.
- Every valid player-made match awards $2.50, flies the supplied coin and bill art from the matched blocks to the top-right score, and fills one of four bottom progress slots green. The fourth match reaches $10.00 and starts the completion handoff.
- Use locally embedded Plus Jakarta Sans Bold for the live gameplay score and Medium for the live CTA Part 1 amount. Keep `font-synthesis: none`.
- CTA Part 1 uses the supplied reward title, subtitle, mascot, coin, and Download Now artwork. CTA Part 2 uses the supplied MIP 06 portrait/landscape videos, preserves normalized phase through rotation, caps extreme viewports to 9:16 or 16:9, and keeps the entire endcard clickable.
- Ship exactly Tap, Swipe, Wrong, Match Complete, CTA Part 1, and CTA Part 2 cues. Preserve persistent two-voice pools, capture-phase Swipe-first priming, rejected-play retries, MRAID volume, and lifecycle-aware pause/resume.
- Preserve the readable early MRAID helper, literal four-variable click chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached exposure/volume, guarded `mraid.open`, and no browser navigation fallback.
- Run `npm run typecheck`, `npm run test:match3`, `npm run test:sound`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iPhone/AppLovin first-gesture audio verification remains separate.

## Maya Mobile MIP 01 project notes

- The active build is a responsive DOM/CSS four-card scratcher plus a standalone video SIP. Produce exactly `maya_acslanot_mip_20260930_01_emily_game_scratch_human_none_none.html` and `mayamobile_acslanot_sip_20260930_05_ecomm_product_review_human_none_none.html` as the AppLovin outputs.
- Use the supplied `image 235.png` and `landscape.png` as full-viewport portrait and landscape backgrounds. Gameplay uses the supplied logo, headings, CTA, lucky/congratulations copy, confetti, and three standalone deal images. The missing standalone 3-day deal is responsive DOM text in supplied DM Sans.
- Draw each scratch surface from the supplied `Container.png` with `Maya Mobile Logo hd 3.png` centered on it; both assets erase together on the live canvas.
- Flow is Tap to Start → choose and scratch exactly one card → guaranteed winning reveal → pause-aware lucky hold → congratulations card carrying the selected offer. Other cards lock as soon as one card is selected.
- The intro includes a looping tutorial-hand tap gesture over the supplied Tap to Start artwork. CTA Part 1 uses live, pause-aware falling/tumbling gold and cream DOM confetti inspired by the supplied static confetti image; do not embed that static image.
- Preserve scratch progress across viewport resize/orientation changes by replaying normalized scratch segments after the canvas is resized at device pixel ratio.
- In landscape, keep all gameplay and CTA Part 1 content in the same centered 9:16 portrait composition used in portrait; only the full-viewport background changes orientation. Keep live confetti viewport-wide behind that centered stage.
- Ship Tap, Scratch, Reveal, CTA Part 1, and CTA Part 2 cues. Use `ReferenceSfxController` persistent two-voice pools, capture-phase priming, rejected-play retries, MRAID volume, and visibility-aware pause/resume. Scratch loops only while the pointer is actively scratching.
- CTA Part 2 uses the supplied Maya Mobile portrait/landscape videos, preserves normalized playback phase through rotation, and keeps the complete video clickable.
- The standalone SIP uses the same video pair and orientation-aware controller. Match the video edges with `#f2ffff` portrait and `#dff2ff` landscape backgrounds/gutters. It ships no gameplay images, fonts, or audio.
- Preserve the validator-readable early MRAID helper, literal four-variable click chain, active `window.handleClickAction`, boot timeout, late-ready activation, cached exposure/volume, guarded `mraid.open`, and no browser navigation fallback.
- Run `npm run typecheck`, `npm run test:scratch`, `npm run test:sip`, `npm run test:sound`, `npm run test:mraid`, `npm run build`, and `npm run verify:applovin`. Physical iPhone/AppLovin first-gesture audio verification remains separate.
