export const DESIGN_WIDTH = 1080;
export const DESIGN_HEIGHT = 1920;

export const Z_INDEX = {
  background: 0,
  gameObjects: 5,
  hud: 17,
  dimOverlay: 20,
  resultUi: 21,
  inputBlocker: 25,
  cta: 30,
} as const;
