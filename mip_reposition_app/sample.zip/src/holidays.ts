import halloween from "./assets/creative/holidays/promo.png";
import christmas from "./assets/creative/holidays/promo-1.png";
import stPaddys from "./assets/creative/holidays/promo-2.png";
import winter from "./assets/creative/holidays/promo-3.png";
import julyFourth from "./assets/creative/holidays/promo-4.png";
import fathersDay from "./assets/creative/holidays/promo-5.png";
import blackFriday from "./assets/creative/holidays/promo-6.png";
import presidentsDay from "./assets/creative/holidays/promo-7.png";
import valentinesDay from "./assets/creative/holidays/promo-8.png";
import fall from "./assets/creative/holidays/promo-9.png";
import memorialDay from "./assets/creative/holidays/promo-10.png";
import thanksgiving from "./assets/creative/holidays/promo-11.png";
import cyberMonday from "./assets/creative/holidays/promo-12.png";
import summer from "./assets/creative/holidays/promo-13.png";
import spring from "./assets/creative/holidays/promo-14.png";
import easter from "./assets/creative/holidays/promo-15.png";
import mothersDay from "./assets/creative/holidays/promo-16.png";
import laborDay from "./assets/creative/holidays/promo-17.png";
import newYear from "./assets/creative/holidays/promo-18.png";

export type HolidayPromotion = {
  id: number;
  saleKey: string;
  label: string;
  image: string;
};

const promotion = (id: number, saleKey: string, label: string, image: string) => ({
  id,
  saleKey,
  label,
  image,
});

const PROMOTIONS = {
  "labor-day": promotion(16, "labor-day", "Happy Labor Day Sale", laborDay),
  summer: promotion(14, "summer", "Happy Summer Day Sale", summer),
  fall: promotion(6, "fall", "Happy Fall Sale", fall),
  halloween: promotion(1, "halloween", "Happy Halloween Day Sale", halloween),
  thanksgiving: promotion(2, "thanksgiving", "Happy Thanksgiving Sale", thanksgiving),
  "black-friday": promotion(20, "black-friday", "Happy Black Friday Sale", blackFriday),
  "cyber-monday": promotion(21, "cyber-monday", "Happy Cyber Monday Sale", cyberMonday),
  christmas: promotion(3, "christmas", "Happy Christmas Sale", christmas),
  winter: promotion(5, "winter", "Happy Winter Sale", winter),
  "new-year": promotion(4, "new-year", "Happy New Year Sale", newYear),
  "valentines-day": promotion(7, "valentines-day", "Happy Valentine's Day Sale", valentinesDay),
  "presidents-day": promotion(19, "presidents-day", "Happy Presidents Day Sale", presidentsDay),
  "st-patricks-day": promotion(8, "st-patricks-day", "Happy St. Paddy's Day Sale", stPaddys),
  spring: promotion(9, "spring", "Happy Spring Sale", spring),
  easter: promotion(10, "easter", "Happy Easter Sale", easter),
  "mothers-day": promotion(11, "mothers-day", "Happy Mother's Day Sale", mothersDay),
  "memorial-day": promotion(12, "memorial-day", "Happy Memorial Day Sale", memorialDay),
  "fathers-day": promotion(13, "fathers-day", "Happy Father's Day Sale", fathersDay),
  "july-4": promotion(15, "july-4", "Happy July 4th Sale", julyFourth),
} as const;

type HolidaySaleKey = keyof typeof PROMOTIONS;
type HolidayRange = readonly [start: string, end: string, saleKey: HolidaySaleKey];

// The Holiday Chart is authoritative. Blank chart rows (including MLK Day)
// intentionally have no entry, so no banner is rendered on those dates.
const HOLIDAY_RANGES: readonly HolidayRange[] = [
  ["2026-08-31", "2026-09-07", "labor-day"],
  ["2026-09-08", "2026-09-21", "summer"],
  ["2026-09-22", "2026-10-25", "fall"],
  ["2026-10-26", "2026-10-31", "halloween"],
  ["2026-11-23", "2026-11-26", "thanksgiving"],
  ["2026-11-27", "2026-11-27", "black-friday"],
  ["2026-11-28", "2026-11-30", "cyber-monday"],
  ["2026-12-01", "2026-12-20", "fall"],
  ["2026-12-21", "2026-12-25", "christmas"],
  ["2026-12-26", "2026-12-31", "winter"],
  ["2027-01-01", "2027-01-03", "new-year"],
  ["2027-01-04", "2027-01-14", "winter"],
  ["2027-01-19", "2027-02-09", "winter"],
  ["2027-02-10", "2027-02-14", "valentines-day"],
  ["2027-02-15", "2027-02-21", "presidents-day"],
  ["2027-02-22", "2027-03-13", "winter"],
  ["2027-03-14", "2027-03-17", "st-patricks-day"],
  ["2027-03-18", "2027-03-19", "winter"],
  ["2027-03-20", "2027-03-24", "spring"],
  ["2027-03-25", "2027-03-28", "easter"],
  ["2027-03-29", "2027-05-05", "spring"],
  ["2027-05-06", "2027-05-09", "mothers-day"],
  ["2027-05-10", "2027-05-20", "spring"],
  ["2027-05-21", "2027-05-31", "memorial-day"],
  ["2027-06-01", "2027-06-19", "spring"],
  ["2027-06-20", "2027-06-20", "fathers-day"],
  ["2027-06-21", "2027-06-30", "summer"],
  ["2027-07-01", "2027-07-05", "july-4"],
  ["2027-07-06", "2027-08-29", "summer"],
  ["2027-08-30", "2027-09-06", "labor-day"],
  ["2027-09-07", "2027-09-21", "summer"],
  ["2027-09-22", "2027-10-25", "fall"],
  ["2027-10-26", "2027-10-31", "halloween"],
  ["2027-11-01", "2027-11-21", "fall"],
  ["2027-11-22", "2027-11-25", "thanksgiving"],
  ["2027-11-26", "2027-11-26", "black-friday"],
  ["2027-11-27", "2027-11-29", "cyber-monday"],
  ["2027-11-30", "2027-12-20", "fall"],
  ["2027-12-21", "2027-12-26", "christmas"],
  ["2027-12-27", "2027-12-31", "winter"],
];

export function toLocalDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function getCreativeNow(): Date {
  if (typeof window !== "undefined" && typeof window.getCreativeNow === "function") {
    const date = window.getCreativeNow();
    if (date instanceof Date) return date;
  }
  return new Date();
}

export function getHolidayPromotion(date = getCreativeNow()): HolidayPromotion | null {
  const today = toLocalDateKey(date);
  const match = HOLIDAY_RANGES.find(([start, end]) => today >= start && today <= end);
  if (!match) return null;
  return PROMOTIONS[match[2]];
}
