import { createRoot } from "react-dom/client";
import App from "./App";
import { trackEvent } from "./analytics";
import { initMraid } from "./networks";
import "./styles.css";

let mounted = false;

function domReady(): Promise<void> {
  if (document.readyState !== "loading") return Promise.resolve();
  return new Promise((resolve) => {
    document.addEventListener("DOMContentLoaded", () => resolve(), { once: true });
  });
}

async function boot(): Promise<void> {
  if (mounted) return;
  trackEvent("LOADING");
  await domReady();
  await initMraid();
  if (mounted) return;
  mounted = true;

  let root = document.getElementById("root");
  if (!root) {
    root = document.createElement("div");
    root.id = "root";
    document.body.appendChild(root);
  }
  createRoot(root).render(<App />);
}

void boot();
