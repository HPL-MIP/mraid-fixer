import ActiveExperience from "@active-experience";

export default function App() {
  return <ActiveExperience />;
}
