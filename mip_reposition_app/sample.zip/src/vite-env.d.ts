/// <reference types="vite/client" />

interface MraidBridge {
  addEventListener?: (event: string, handler: (...args: unknown[]) => void) => void;
  getState?: () => string;
  isViewable?: () => boolean;
  open?: (target?: string) => void;
}

interface Window {
  mraid?: MraidBridge;
  clickTag?: string;
  clickTag1?: string;
  clickthrough?: string;
  clickThrough?: string;
  ALPlayableAnalytics?: { trackEvent?: (event: string) => void };
  gameReady?: () => void;
  gameStart?: () => void;
  gameEnd?: () => void;
  gameClose?: () => void;
  trackMraidReadiness?: (mraid: MraidBridge) => void;
  isMraidUsable?: (mraid: MraidBridge) => boolean;
  handleClickAction?: () => void;
  getCreativeNow?: () => Date;
  creativeDateIsPinned?: boolean;
  __mraidBootPromise?: Promise<void>;
}
