import { useCallback, useEffect, useRef, useState } from "react";
import activeConfig from "@active-variant";
import { trackEvent } from "../analytics";
import type { SfxInteractionToken } from "../audio/SfxController";
import { CircularScanner } from "../components/CircularScanner";
import { HolidayHeader } from "../components/HolidayHeader";
import { NativeGestureButton } from "../components/NativeGestureButton";
import { ScanSlider } from "../components/ScanSlider";
import { DESIGN_HEIGHT, DESIGN_WIDTH, Z_INDEX } from "../constants";
import { useResponsive } from "../hooks/useResponsive";
import { useSound } from "../hooks/useSound";
import { getCreativeNow, getHolidayPromotion } from "../holidays";
import {
  bindLifecycle,
  notifyGameEnd,
  notifyGameReady,
  notifyGameStart,
  triggerCTA,
} from "../networks";

const RESULT_DELAY_MS = 360;
const CTA_REVEAL_DELAY_MS = 1050;

export default function MipExperience() {
  const config = activeConfig;
  const layout = useResponsive();
  const sfx = useSound();
  const [scanStarted, setScanStarted] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const [resultVisible, setResultVisible] = useState(false);
  const [ctaVisible, setCtaVisible] = useState(false);
  const [mediaPaused, setMediaPaused] = useState(false);
  const [holidayPromotion, setHolidayPromotion] = useState(() => getHolidayPromotion());
  const startedRef = useRef(false);
  const completeRef = useRef(false);
  const tapGestureClaimedRef = useRef(false);
  const resultCuePlayedRef = useRef(false);
  const endcardCuePlayedRef = useRef(false);
  const endcardTrackedRef = useRef(false);

  useEffect(() => bindLifecycle((state) => {
    const paused = state.hidden || !state.exposed || !state.viewable;
    sfx.setMasterVolume(state.audioVolume);
    sfx.setPaused(paused);
    setMediaPaused(paused);
  }), [sfx]);

  useEffect(() => {
    trackEvent("LOADED");
    trackEvent("DISPLAYED");
    notifyGameReady();
  }, []);

  useEffect(() => {
    let rolloverTimer = 0;

    const refreshHoliday = () => {
      window.clearTimeout(rolloverTimer);
      const now = getCreativeNow();
      setHolidayPromotion(getHolidayPromotion(now));

      // A pinned QA date does not roll over. Live creatives refresh shortly
      // after local midnight and again whenever the tab regains attention.
      if (window.creativeDateIsPinned) return;
      const nextDay = new Date(now.getTime());
      nextDay.setDate(nextDay.getDate() + 1);
      nextDay.setHours(0, 0, 0, 25);
      rolloverTimer = window.setTimeout(refreshHoliday, Math.max(25, nextDay.getTime() - now.getTime()));
    };

    refreshHoliday();
    document.addEventListener("visibilitychange", refreshHoliday);
    window.addEventListener("focus", refreshHoliday);
    return () => {
      window.clearTimeout(rolloverTimer);
      document.removeEventListener("visibilitychange", refreshHoliday);
      window.removeEventListener("focus", refreshHoliday);
    };
  }, []);

  const markStarted = useCallback(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    notifyGameStart();
    trackEvent("CHALLENGE_STARTED");
  }, []);

  const finishScan = useCallback(() => {
    if (completeRef.current) return;
    completeRef.current = true;
    setScanComplete(true);
    trackEvent("CHALLENGE_SOLVED");
    notifyGameEnd();
  }, []);

  useEffect(() => {
    if (!scanComplete || mediaPaused || resultVisible) return;
    const timer = window.setTimeout(() => setResultVisible(true), RESULT_DELAY_MS);
    return () => window.clearTimeout(timer);
  }, [mediaPaused, resultVisible, scanComplete]);

  useEffect(() => {
    if (!resultVisible || mediaPaused || resultCuePlayedRef.current) return;
    if (sfx.promotePrepared("productReveal", { restart: true })) {
      resultCuePlayedRef.current = true;
    }
  }, [mediaPaused, resultVisible, sfx]);

  useEffect(() => {
    if (!resultVisible || mediaPaused || ctaVisible) return;
    const timer = window.setTimeout(() => setCtaVisible(true), CTA_REVEAL_DELAY_MS);
    return () => window.clearTimeout(timer);
  }, [ctaVisible, mediaPaused, resultVisible]);

  useEffect(() => {
    if (!ctaVisible || mediaPaused || endcardCuePlayedRef.current) return;
    if (sfx.promotePrepared("endcardReveal", { restart: true })) {
      endcardCuePlayedRef.current = true;
    }
    if (!endcardTrackedRef.current) {
      endcardTrackedRef.current = true;
      trackEvent("ENDCARD_SHOWN");
    }
  }, [ctaVisible, mediaPaused, sfx]);

  const onTapGesture = useCallback((token: SfxInteractionToken) => {
    if (tapGestureClaimedRef.current || scanStarted || scanComplete) return false;
    tapGestureClaimedRef.current = true;
    markStarted();
    // Every other pooled cue receives a short muted iOS prime from this same
    // native gesture. None of the delayed cues stays alive as a silent loop.
    sfx.playGestureCues([
      { key: "click", options: { restart: true } },
    ], token);
    return true;
  }, [markStarted, scanComplete, scanStarted, sfx]);

  const onTapActivate = useCallback(() => {
    if (scanStarted || scanComplete) return;
    setScanStarted(true);
  }, [scanComplete, scanStarted]);

  const onTapScanComplete = useCallback(() => {
    sfx.promotePrepared("correct", { restart: true });
    finishScan();
  }, [finishScan, sfx]);

  const onSliderGesture = useCallback((token: SfxInteractionToken) => {
    if (scanComplete) return false;
    markStarted();
    sfx.playGestureCues([{ key: "click", options: { restart: true } }], token);
    return true;
  }, [markStarted, scanComplete, sfx]);

  const onSliderResolve = useCallback((token: SfxInteractionToken, success: boolean) => {
    if (success) {
      // Delayed reveal cues were briefly primed when the drag began. Keep only
      // the authored completion cue audible at release.
      sfx.playGestureCues([
        { key: "correct", options: { restart: true } },
      ], token);
      finishScan();
    } else {
      sfx.playGestureCues([{ key: "wrong", options: { restart: true } }], token);
    }
  }, [finishScan, sfx]);

  const stageStyle = {
    "--scale": layout.scale,
    "--offset-x": `${layout.offsetX}px`,
    "--offset-y": `${layout.offsetY}px`,
    "--z-background": Z_INDEX.background,
    "--z-game": Z_INDEX.gameObjects,
    "--z-result": Z_INDEX.resultUi,
    "--z-cta": Z_INDEX.cta,
  } as React.CSSProperties;

  const instruction = scanComplete
    ? "Scan complete"
    : scanStarted
      ? config.scanningText
      : config.instruction;

  return (
    <main
      className={`app monoboost-app ${mediaPaused ? "is-paused" : ""} ${holidayPromotion ? "has-holiday" : ""}`}
      data-variant={config.id}
      data-holiday={holidayPromotion?.id ?? 0}
      data-holiday-active={Boolean(holidayPromotion)}
      data-sale={holidayPromotion?.saleKey}
      style={stageStyle}
    >
      <div className="playable-stage" style={{ width: DESIGN_WIDTH, height: DESIGN_HEIGHT }}>
        <section className="scan-content" aria-label={config.title}>
          {holidayPromotion && <HolidayHeader promotion={holidayPromotion} />}
          <header className="scan-header">
            <h1>{config.heading}</h1>
            <p>{instruction}</p>
          </header>

          {config.mechanic === "tap-scan" ? (
            <>
              <CircularScanner
                active={scanStarted}
                paused={mediaPaused}
                onComplete={onTapScanComplete}
              />
              {!scanStarted && !scanComplete && (
                <NativeGestureButton
                  className="start-scan-button"
                  onGesture={onTapGesture}
                  onGestureMove={(token) => sfx.retryInteraction(token)}
                  onGestureRelease={(token) => sfx.releaseInteraction(token)}
                  onGestureCancel={(token) => {
                    tapGestureClaimedRef.current = false;
                    sfx.cancelInteraction(token);
                  }}
                  onActivate={onTapActivate}
                >
                  Start Scan
                </NativeGestureButton>
              )}
            </>
          ) : (
            <ScanSlider
              disabled={scanComplete}
              onGestureStart={onSliderGesture}
              onGestureMove={(token) => sfx.retryInteraction(token)}
              onGestureRelease={(token) => sfx.releaseInteraction(token)}
              onGestureCancel={(token) => sfx.cancelInteraction(token)}
              onResolve={onSliderResolve}
            />
          )}

          {resultVisible && (
            <section className="result-block" aria-live="polite">
              {config.id === "mip3" && <div className="result-mark" aria-hidden="true">!</div>}
              <h2>{config.resultHeading}</h2>
              {config.resultBody && <p>{config.resultBody}</p>}
              {ctaVisible && (
                <span className="result-cta" aria-hidden="true">
                  {config.ctaLabel}
                </span>
              )}
            </section>
          )}
        </section>

        {config.showDisclaimer && (
          <p className="disclaimer">This is a demo of the app. Actual results may vary.</p>
        )}
      </div>

      {ctaVisible && (
        <button
          className="endcard-clickthrough"
          type="button"
          aria-label={config.ctaLabel}
          onClick={triggerCTA}
        />
      )}
    </main>
  );
}
