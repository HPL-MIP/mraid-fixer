export type SfxPausePolicy = "cancel" | "resume";
export type SfxOverflowPolicy = "drop-newest" | "restart-oldest";
export type SfxInteractionToken = string;

export type SfxCueConfig = {
  src: string;
  volume?: number;
  poolSize?: number;
  loop?: boolean;
  pausePolicy?: SfxPausePolicy;
  overflowPolicy?: SfxOverflowPolicy;
  startAt?: number;
  endAt?: number;
};

export type SfxPlayOptions = {
  loop?: boolean;
  prepareOnly?: boolean;
  restart?: boolean;
  volume?: number;
  startAt?: number;
  endAt?: number;
};

export type SfxGestureCue<Key extends string> = {
  key: Key;
  options?: SfxPlayOptions;
};

type ResolvedPlayOptions = {
  loop: boolean;
  prepareOnly: boolean;
  restart: boolean;
  volume: number;
  startAt: number;
  endAt: number;
};

type Voice = {
  element: HTMLAudioElement;
  generation: number;
  primed: boolean;
  unsupported: boolean;
  pending: boolean;
  pendingAt: number;
  lastAttemptAt: number;
  inFlight: boolean;
  intendedPlaying: boolean;
  playingObserved: boolean;
  resumeOnVisible: boolean;
  interactionToken: SfxInteractionToken | null;
  options: ResolvedPlayOptions;
  removeListeners: () => void;
};

type Cue = {
  config: Required<Omit<SfxCueConfig, "src">> & Pick<SfxCueConfig, "src">;
  voices: Voice[];
  cursor: number;
};

const PENDING_LIFETIME_MS = 900;
const MOVE_RETRY_INTERVAL_MS = 120;

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value));
}

function errorName(error: unknown): string {
  if (error && typeof error === "object" && "name" in error) {
    return String(error.name);
  }
  return "";
}

/** Owns every persistent HTMLAudioElement used by the playable. */
export class SfxController<Key extends string> {
  private readonly cues = new Map<Key, Cue>();
  private readonly activeInteractions = new Set<SfxInteractionToken>();
  private masterVolume = 1;
  private paused = false;
  private destroyed = false;
  private gestureSeen = false;

  constructor(manifest: Record<Key, SfxCueConfig>) {
    for (const key of Object.keys(manifest) as Key[]) {
      const input = manifest[key];
      const config: Cue["config"] = {
        src: input.src,
        volume: clamp01(input.volume ?? 1),
        poolSize: Math.max(1, Math.floor(input.poolSize ?? 1)),
        loop: input.loop ?? false,
        pausePolicy: input.pausePolicy ?? "cancel",
        overflowPolicy: input.overflowPolicy ?? "drop-newest",
        startAt: Math.max(0, input.startAt ?? 0),
        endAt:
          input.endAt == null
            ? Number.POSITIVE_INFINITY
            : Math.max(0, input.endAt),
      };

      const cue: Cue = { config, voices: [], cursor: 0 };
      for (let index = 0; index < config.poolSize; index += 1) {
        const element = new Audio(config.src);
        element.preload = "auto";
        element.setAttribute("playsinline", "");
        element.setAttribute("webkit-playsinline", "");

        const voice: Voice = {
          element,
          generation: 0,
          primed: false,
          unsupported: false,
          pending: false,
          pendingAt: 0,
          lastAttemptAt: 0,
          inFlight: false,
          intendedPlaying: false,
          playingObserved: false,
          resumeOnVisible: false,
          interactionToken: null,
          options: {
            loop: config.loop,
            prepareOnly: false,
            restart: true,
            volume: 1,
            startAt: config.startAt,
            endAt: config.endAt,
          },
          removeListeners: () => undefined,
        };

        const onPlaying = () => {
          if (!voice.intendedPlaying) return;
          voice.playingObserved = true;
          voice.inFlight = false;
          voice.pending = false;
          voice.primed = true;
          if (
            voice.interactionToken &&
            !this.activeInteractions.has(voice.interactionToken)
          ) {
            voice.interactionToken = null;
          }
        };
        const onEnded = () => {
          if (voice.element.loop && voice.intendedPlaying) return;
          this.resetVoiceState(voice);
        };
        const onPause = () => {
          // Controller-owned stops and silent-prime pauses update state before
          // calling pause(). Only retain a browser/host interruption that can
          // still be recovered by an eligible native gesture.
          if (
            !voice.intendedPlaying ||
            voice.resumeOnVisible ||
            this.paused ||
            this.destroyed
          ) {
            return;
          }
          voice.inFlight = false;
          voice.playingObserved = false;
          voice.pending = true;
        };
        const onTimeUpdate = () => {
          if (
            voice.intendedPlaying &&
            Number.isFinite(voice.options.endAt) &&
            element.currentTime >= voice.options.endAt
          ) {
            this.stopVoice(voice);
          }
        };
        const onError = () => {
          if (element.error?.code === 4) {
            voice.unsupported = true;
            this.stopVoice(voice);
          }
        };

        element.addEventListener("playing", onPlaying);
        element.addEventListener("pause", onPause);
        element.addEventListener("ended", onEnded);
        element.addEventListener("timeupdate", onTimeUpdate);
        element.addEventListener("error", onError);
        voice.removeListeners = () => {
          element.removeEventListener("playing", onPlaying);
          element.removeEventListener("pause", onPause);
          element.removeEventListener("ended", onEnded);
          element.removeEventListener("timeupdate", onTimeUpdate);
          element.removeEventListener("error", onError);
        };

        cue.voices.push(voice);
        try {
          if (element.readyState === HTMLMediaElement.HAVE_NOTHING) element.load();
        } catch {
          // Metadata loading is best effort in WebViews.
        }
      }

      this.cues.set(key, cue);
    }
  }

  playGestureCues(
    cues: ReadonlyArray<SfxGestureCue<Key>>,
    interactionToken: SfxInteractionToken,
  ): ReadonlyArray<HTMLAudioElement | null> {
    if (this.destroyed || this.paused || document.hidden) return [];
    this.gestureSeen = true;
    this.activeInteractions.add(interactionToken);

    // Request every immediate audible cue before silently preparing spares.
    const elements = cues.map(({ key, options }) =>
      this.playInternal(key, options, interactionToken),
    );
    this.retryDetachedOneShots();
    this.primeFromGesture(new Set(elements.filter((item) => item !== null)));
    return elements;
  }

  private retryDetachedOneShots(): void {
    const now = performance.now();
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (
          voice.interactionToken !== null ||
          !voice.intendedPlaying ||
          voice.playingObserved
        ) {
          continue;
        }
        if (now - voice.pendingAt > PENDING_LIFETIME_MS) {
          this.stopVoice(voice);
          continue;
        }
        this.requestPlayback(cue, voice, false);
      }
    }
  }

  private primeFromGesture(activeElements: Set<HTMLAudioElement>): void {
    if (
      this.destroyed ||
      this.paused ||
      document.hidden ||
      this.activeInteractions.size === 0
    ) {
      return;
    }
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (
          !activeElements.has(voice.element) &&
          !voice.primed &&
          !voice.unsupported &&
          !voice.pending &&
          !voice.inFlight &&
          !voice.intendedPlaying &&
          voice.element.paused
        ) {
          this.primeVoice(cue, voice);
        }
      }
    }
  }

  private primeVoice(cue: Cue, voice: Voice): void {
    if (voice.unsupported || this.paused || this.destroyed) return;
    const { element } = voice;
    const generation = ++voice.generation;
    voice.inFlight = true;
    voice.lastAttemptAt = performance.now();

    const settle = (primed: boolean, error?: unknown): void => {
      if (
        voice.generation !== generation ||
        this.destroyed ||
        voice.intendedPlaying
      ) {
        return;
      }
      voice.inFlight = false;
      voice.primed = primed;
      if (errorName(error) === "NotSupportedError") voice.unsupported = true;
      try {
        element.pause();
      } catch {
        // Best effort.
      }
      try {
        element.currentTime = 0;
      } catch {
        // Metadata may not be ready.
      }
      this.applyIdleSettings(cue, voice);
    };

    try {
      element.muted = true;
      element.volume = 0;
      if (element.readyState === HTMLMediaElement.HAVE_NOTHING) element.load();
      const request = element.play();
      if (request) {
        void request.then(
          () => settle(true),
          (error) => settle(false, error),
        );
      } else {
        settle(true);
      }
    } catch (error) {
      settle(false, error);
    }
  }

  play(key: Key, options: SfxPlayOptions = {}): HTMLAudioElement | null {
    if (!this.gestureSeen) return null;
    return this.playInternal(key, options, null);
  }

  /** Makes a gesture-started silent cue audible without replacing its element. */
  promotePrepared(
    key: Key,
    options: SfxPlayOptions = {},
  ): HTMLAudioElement | null {
    if (this.destroyed || this.paused || document.hidden) return null;
    const cue = this.cues.get(key);
    if (!cue) return null;
    const voice = cue.voices.find(
      (candidate) => candidate.intendedPlaying && !candidate.unsupported,
    );
    if (!voice) return this.playInternal(key, options, null);

    voice.options = {
      loop: options.loop ?? false,
      prepareOnly: false,
      restart: options.restart ?? true,
      volume: clamp01(options.volume ?? 1),
      startAt: Math.max(0, options.startAt ?? cue.config.startAt),
      endAt:
        options.endAt == null
          ? cue.config.endAt
          : Math.max(0, options.endAt),
    };
    voice.interactionToken = null;
    voice.pendingAt = performance.now();
    this.applyVoiceSettings(cue, voice);
    if (voice.options.restart) {
      try {
        voice.element.currentTime = voice.options.startAt;
      } catch {
        // Metadata may not be ready.
      }
    }
    // A prepared iOS request can still be settling when its scene appears.
    // Reconfiguring that exact element is enough; issuing a second play() here
    // can make WebViews start the delayed cue twice. Let the existing request
    // finish and only request playback when no attempt is already in flight.
    if (!voice.inFlight && (voice.element.paused || !voice.playingObserved)) {
      this.requestPlayback(cue, voice, false);
    }
    return voice.element;
  }

  private playInternal(
    key: Key,
    options: SfxPlayOptions = {},
    interactionToken: SfxInteractionToken | null,
  ): HTMLAudioElement | null {
    if (this.destroyed || this.paused || document.hidden) return null;
    const cue = this.cues.get(key);
    if (!cue) return null;

    const ordered = cue.voices.map(
      (_, offset) => cue.voices[(cue.cursor + offset) % cue.voices.length],
    );
    let voice = ordered.find(
      (candidate) =>
        !candidate.unsupported &&
        candidate.primed &&
        !candidate.intendedPlaying &&
        !candidate.pending &&
        !candidate.inFlight,
    );
    voice ??= ordered.find(
      (candidate) =>
        !candidate.unsupported &&
        !candidate.intendedPlaying &&
        !candidate.pending &&
        !candidate.inFlight,
    );
    // A settling silent prime may be promoted on that same element.
    voice ??= ordered.find(
      (candidate) =>
        !candidate.unsupported &&
        !candidate.intendedPlaying &&
        !candidate.pending &&
        candidate.inFlight,
    );
    if (!voice) {
      if (cue.config.overflowPolicy === "drop-newest") return null;
      voice = ordered.find((candidate) => !candidate.unsupported);
      if (!voice) return null;
    }

    const selectedIndex = cue.voices.indexOf(voice);
    cue.cursor = (selectedIndex + 1) % cue.voices.length;
    this.stopVoice(voice);
    voice.options = {
      loop: options.loop ?? cue.config.loop,
      prepareOnly: options.prepareOnly ?? false,
      restart: options.restart ?? true,
      volume: clamp01(options.volume ?? 1),
      startAt: Math.max(0, options.startAt ?? cue.config.startAt),
      endAt:
        options.endAt == null
          ? cue.config.endAt
          : Math.max(0, options.endAt),
    };
    voice.intendedPlaying = true;
    voice.interactionToken = interactionToken;
    voice.pendingAt = performance.now();
    this.applyVoiceSettings(cue, voice);
    this.requestPlayback(cue, voice, voice.options.restart);
    return voice.element;
  }

  private requestPlayback(cue: Cue, voice: Voice, restart: boolean): void {
    if (
      this.destroyed ||
      this.paused ||
      document.hidden ||
      voice.unsupported ||
      !voice.intendedPlaying
    ) {
      return;
    }
    const generation = ++voice.generation;
    voice.pending = false;
    voice.inFlight = true;
    voice.playingObserved = false;
    voice.resumeOnVisible = false;
    voice.lastAttemptAt = performance.now();
    this.applyVoiceSettings(cue, voice);

    const rejected = (error?: unknown): void => {
      if (voice.generation !== generation || this.destroyed || this.paused) return;
      voice.inFlight = false;
      voice.primed = false;
      if (errorName(error) === "NotSupportedError") {
        voice.unsupported = true;
        this.stopVoice(voice);
        return;
      }
      const interactionStillActive =
        voice.interactionToken === null ||
        this.activeInteractions.has(voice.interactionToken);
      if (voice.intendedPlaying && interactionStillActive) {
        voice.pending = true;
      } else {
        this.stopVoice(voice);
      }
    };

    if (restart) {
      try {
        voice.element.currentTime = voice.options.startAt;
      } catch {
        // Metadata may not be ready.
      }
    }

    try {
      const request = voice.element.play();
      if (request) {
        void request.then(() => {
          if (voice.generation !== generation || this.destroyed) return;
          voice.inFlight = false;
          voice.pending = false;
          voice.primed = true;
        }, rejected);
      } else {
        voice.inFlight = false;
        voice.pending = false;
        voice.primed = true;
      }
    } catch (error) {
      rejected(error);
    }
  }

  retryInteraction(interactionToken: SfxInteractionToken): void {
    if (
      this.destroyed ||
      this.paused ||
      document.hidden ||
      !this.activeInteractions.has(interactionToken)
    ) {
      return;
    }
    const now = performance.now();
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (
          voice.interactionToken === interactionToken &&
          voice.intendedPlaying &&
          !voice.playingObserved &&
          now - voice.pendingAt > PENDING_LIFETIME_MS
        ) {
          this.stopVoice(voice);
          continue;
        }
        if (
          voice.interactionToken !== interactionToken ||
          !voice.intendedPlaying ||
          voice.playingObserved ||
          now - voice.lastAttemptAt < MOVE_RETRY_INTERVAL_MS ||
          (voice.options.prepareOnly && !voice.pending) ||
          (!voice.pending && !voice.inFlight)
        ) {
          continue;
        }
        this.requestPlayback(cue, voice, false);
      }
    }
  }

  releaseInteraction(interactionToken: SfxInteractionToken): void {
    if (!this.activeInteractions.has(interactionToken)) return;
    const now = performance.now();

    // Boundary recovery is synchronous and unthrottled. It also covers a
    // fulfilled promise for which no `playing` event has been observed.
    if (!this.destroyed && !this.paused && !document.hidden) {
      for (const cue of this.cues.values()) {
        for (const voice of cue.voices) {
          if (
            voice.interactionToken === interactionToken &&
            voice.options.prepareOnly &&
            !voice.pending
          ) {
            // The gesture already started this silent preparation. Do not
            // create a second outstanding play() request just because iOS has
            // not rejected the first request by pointer/touch release.
            continue;
          }
          if (
            voice.interactionToken === interactionToken &&
            voice.intendedPlaying &&
            !voice.playingObserved &&
            now - voice.pendingAt <= PENDING_LIFETIME_MS
          ) {
            this.requestPlayback(cue, voice, false);
          } else if (
            voice.interactionToken === interactionToken &&
            voice.intendedPlaying &&
            !voice.playingObserved
          ) {
            this.stopVoice(voice);
          } else if (
            voice.interactionToken === null &&
            !voice.intendedPlaying &&
            !voice.primed &&
            !voice.pending &&
            !voice.inFlight &&
            !voice.unsupported
          ) {
            this.primeVoice(cue, voice);
          }
        }
      }
    }

    this.activeInteractions.delete(interactionToken);
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (
          voice.interactionToken === interactionToken &&
          (voice.playingObserved || voice.options.prepareOnly)
        ) {
          voice.interactionToken = null;
        }
      }
    }
  }

  cancelInteraction(interactionToken: SfxInteractionToken): void {
    if (!this.activeInteractions.delete(interactionToken)) return;
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (voice.interactionToken === interactionToken) this.stopVoice(voice);
      }
    }
  }

  stop(key: Key): void {
    const cue = this.cues.get(key);
    if (!cue) return;
    for (const voice of cue.voices) this.stopVoice(voice);
  }

  private resetVoiceState(voice: Voice): void {
    voice.generation += 1;
    voice.pending = false;
    voice.inFlight = false;
    voice.intendedPlaying = false;
    voice.playingObserved = false;
    voice.resumeOnVisible = false;
    voice.interactionToken = null;
  }

  private stopVoice(voice: Voice): void {
    this.resetVoiceState(voice);
    try {
      voice.element.pause();
    } catch {
      // Best effort.
    }
    try {
      voice.element.currentTime = 0;
    } catch {
      // Metadata may not be ready.
    }
  }

  private applyIdleSettings(cue: Cue, voice: Voice): void {
    voice.element.loop = false;
    voice.element.muted = this.paused || this.masterVolume <= 0;
    voice.element.volume = clamp01(cue.config.volume * this.masterVolume);
  }

  private applyVoiceSettings(cue: Cue, voice: Voice): void {
    voice.element.loop = voice.options.loop;
    // iOS does not reliably honor programmatic HTMLMediaElement.volume changes.
    // Prepared scene cues must use the native muted flag until their authored
    // scene promotes them, otherwise a volume: 0 loop can still be audible.
    voice.element.muted =
      this.paused || this.masterVolume <= 0 || voice.options.prepareOnly;
    voice.element.volume = clamp01(
      cue.config.volume * voice.options.volume * this.masterVolume,
    );
  }

  setMasterVolume(scale: number): void {
    if (!Number.isFinite(scale)) return;
    this.masterVolume = clamp01(scale);
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (voice.inFlight && !voice.intendedPlaying) continue;
        if (voice.intendedPlaying) this.applyVoiceSettings(cue, voice);
        else this.applyIdleSettings(cue, voice);
      }
    }
  }

  setPaused(paused: boolean): void {
    if (this.destroyed || this.paused === paused) return;
    this.paused = paused;

    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        if (paused) {
          // Only a loop belonging to a still-active gesture may resume.
          if (
            cue.config.pausePolicy === "resume" &&
            voice.options.loop &&
            voice.intendedPlaying &&
            voice.interactionToken !== null &&
            this.activeInteractions.has(voice.interactionToken)
          ) {
            voice.generation += 1;
            voice.pending = false;
            voice.inFlight = false;
            voice.resumeOnVisible = true;
            try {
              voice.element.pause();
            } catch {
              // Best effort.
            }
          } else if (
            voice.intendedPlaying ||
            voice.pending ||
            voice.inFlight
          ) {
            this.stopVoice(voice);
          }
          this.applyVoiceSettings(cue, voice);
          continue;
        }

        this.applyVoiceSettings(cue, voice);
        if (
          voice.resumeOnVisible &&
          voice.interactionToken !== null &&
          this.activeInteractions.has(voice.interactionToken)
        ) {
          voice.pendingAt = performance.now();
          this.requestPlayback(cue, voice, false);
        }
      }
    }
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.activeInteractions.clear();
    for (const cue of this.cues.values()) {
      for (const voice of cue.voices) {
        this.stopVoice(voice);
        voice.removeListeners();
        try {
          voice.element.removeAttribute("src");
          voice.element.load();
        } catch {
          // Best effort.
        }
      }
    }
    this.cues.clear();
  }
}
