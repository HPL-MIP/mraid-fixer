import type { SfxInteractionToken } from "./SfxController";

export type SfxInputPath =
  | "touch"
  | "pointer"
  | "keyboard"
  | "activation";

function isPrimaryPath(path: SfxInputPath): path is "touch" | "pointer" {
  return path === "touch" || path === "pointer";
}

export function makeSfxInteractionToken(
  path: SfxInputPath,
  identifier: string | number,
): SfxInteractionToken {
  return `${path}:${identifier}`;
}

/** Keeps input ownership isolated to the one selected native mobile strategy. */
export class SfxInputOwnership<Value> {
  private readonly active = new Map<string, Value>();

  constructor(private readonly primaryPath: "touch" | "pointer") {}

  private key(path: SfxInputPath, identifier: string | number): string | null {
    if (isPrimaryPath(path) && path !== this.primaryPath) return null;
    return makeSfxInteractionToken(path, identifier);
  }

  claim(
    path: SfxInputPath,
    identifier: string | number,
    value: Value,
  ): boolean {
    const key = this.key(path, identifier);
    if (key === null || this.active.has(key)) return false;
    this.active.set(key, value);
    return true;
  }

  has(path: SfxInputPath, identifier: string | number): boolean {
    const key = this.key(path, identifier);
    return key !== null && this.active.has(key);
  }

  get(path: SfxInputPath, identifier: string | number): Value | undefined {
    const key = this.key(path, identifier);
    return key === null ? undefined : this.active.get(key);
  }

  take(path: SfxInputPath, identifier: string | number): Value | undefined {
    const key = this.key(path, identifier);
    if (key === null) return undefined;
    const value = this.active.get(key);
    if (value !== undefined) this.active.delete(key);
    return value;
  }

  drain(): Value[] {
    const values = [...this.active.values()];
    this.active.clear();
    return values;
  }
}
