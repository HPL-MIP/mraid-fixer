const DEFAULT_GESTURE_LIFETIME_MS = 900;

/**
 * Serializes gesture-bound SFX requests before React state has time to commit.
 * This prevents two simultaneous mobile pointers from both claiming the same
 * selection state and producing duplicate tap sounds.
 */
export class SfxGestureGate<Key> {
  private pending: { key: Key; expiresAt: number } | null = null;

  constructor(private readonly lifetimeMs = DEFAULT_GESTURE_LIFETIME_MS) {}

  claim(key: Key, now = performance.now()): boolean {
    if (this.pending && this.pending.expiresAt > now) return false;
    this.pending = { key, expiresAt: now + this.lifetimeMs };
    return true;
  }

  consume(key: Key): boolean {
    if (!this.pending || this.pending.key !== key) return false;
    this.pending = null;
    return true;
  }

  cancel(key: Key): void {
    if (this.pending?.key === key) this.pending = null;
  }

  clear(): void {
    this.pending = null;
  }
}
