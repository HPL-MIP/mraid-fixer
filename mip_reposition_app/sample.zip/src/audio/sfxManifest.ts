import clickUrl from "../assets/sounds/tap.mp3";
import correctUrl from "../assets/sounds/match-complete.mp3";
import endcardRevealUrl from "../assets/sounds/cta-part2.mp3";
import productRevealUrl from "../assets/sounds/cta-part1.mp3";
import wrongUrl from "../assets/sounds/wrong.mp3";
import type { SfxCueConfig } from "./SfxController";

export type SfxKey =
  | "click"
  | "correct"
  | "wrong"
  | "productReveal"
  | "endcardReveal";

export const SFX_MANIFEST: Record<SfxKey, SfxCueConfig> = {
  click: { src: clickUrl, volume: 0.72, poolSize: 4 },
  correct: { src: correctUrl, volume: 0.88, poolSize: 2 },
  wrong: { src: wrongUrl, volume: 0.8, poolSize: 2 },
  productReveal: { src: productRevealUrl, volume: 0.9, poolSize: 1 },
  endcardReveal: { src: endcardRevealUrl, volume: 0.9, poolSize: 1 },
};
