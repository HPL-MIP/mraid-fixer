import { useEffect, useState } from "react";
import { DESIGN_HEIGHT, DESIGN_WIDTH } from "../constants";

export type ResponsiveLayout = {
  width: number;
  height: number;
  scale: number;
  offsetX: number;
  offsetY: number;
};

function measure(): ResponsiveLayout {
  const viewport = window.visualViewport;
  const width = viewport?.width ?? window.innerWidth;
  const height = viewport?.height ?? window.innerHeight;
  const scale = Math.min(width / DESIGN_WIDTH, height / DESIGN_HEIGHT);
  return {
    width,
    height,
    scale,
    offsetX: (width - DESIGN_WIDTH * scale) / 2,
    offsetY: (height - DESIGN_HEIGHT * scale) / 2,
  };
}

export function useResponsive(): ResponsiveLayout {
  const [layout, setLayout] = useState(measure);

  useEffect(() => {
    let frame = 0;
    const timers: number[] = [];
    const update = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const next = measure();
        const root = document.documentElement;
        root.style.setProperty("--vw", `${next.width}px`);
        root.style.setProperty("--vh", `${next.height}px`);
        root.style.setProperty("--dpr", String(window.devicePixelRatio || 1));
        root.style.setProperty("--scale", String(next.scale));
        root.style.setProperty("--offset-x", `${next.offsetX}px`);
        root.style.setProperty("--offset-y", `${next.offsetY}px`);
        setLayout(next);
      });
    };
    const settle = () => {
      update();
      [100, 300, 600].forEach((delay) => timers.push(window.setTimeout(update, delay)));
    };

    settle();
    window.addEventListener("resize", settle);
    window.addEventListener("orientationchange", settle);
    window.visualViewport?.addEventListener("resize", settle);
    return () => {
      cancelAnimationFrame(frame);
      timers.forEach(clearTimeout);
      window.removeEventListener("resize", settle);
      window.removeEventListener("orientationchange", settle);
      window.visualViewport?.removeEventListener("resize", settle);
    };
  }, []);

  return layout;
}
