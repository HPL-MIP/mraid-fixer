import { useLayoutEffect, useMemo, useRef } from "react";
import {
  SfxController,
  type SfxGestureCue,
  type SfxInteractionToken,
  type SfxPlayOptions,
} from "../audio/SfxController";
import { SFX_MANIFEST, type SfxKey } from "../audio/sfxManifest";

export type SoundHandle = {
  playGestureCues: (
    cues: ReadonlyArray<SfxGestureCue<SfxKey>>,
    interactionToken: SfxInteractionToken,
  ) => void;
  play: (key: SfxKey, options?: SfxPlayOptions) => HTMLAudioElement | null;
  promotePrepared: (key: SfxKey, options?: SfxPlayOptions) => HTMLAudioElement | null;
  retryInteraction: (interactionToken: SfxInteractionToken) => void;
  releaseInteraction: (interactionToken: SfxInteractionToken) => void;
  cancelInteraction: (interactionToken: SfxInteractionToken) => void;
  stop: (key: SfxKey) => void;
  setMasterVolume: (scale: number) => void;
  setPaused: (paused: boolean) => void;
};

/** Creates every experience-wide SFX pool during layout, before input binds. */
export function useSound(): SoundHandle {
  const controllerRef = useRef<SfxController<SfxKey> | null>(null);

  useLayoutEffect(() => {
    const controller = new SfxController<SfxKey>(SFX_MANIFEST);
    controllerRef.current = controller;
    return () => {
      if (controllerRef.current === controller) controllerRef.current = null;
      controller.destroy();
    };
  }, []);

  return useMemo(
    () => ({
      playGestureCues: (cues, interactionToken) => {
        controllerRef.current?.playGestureCues(cues, interactionToken);
      },
      play: (key, options) =>
        controllerRef.current?.play(key, options) ?? null,
      promotePrepared: (key, options) =>
        controllerRef.current?.promotePrepared(key, options) ?? null,
      retryInteraction: (interactionToken) => {
        controllerRef.current?.retryInteraction(interactionToken);
      },
      releaseInteraction: (interactionToken) => {
        controllerRef.current?.releaseInteraction(interactionToken);
      },
      cancelInteraction: (interactionToken) => {
        controllerRef.current?.cancelInteraction(interactionToken);
      },
      stop: (key) => controllerRef.current?.stop(key),
      setMasterVolume: (scale) => controllerRef.current?.setMasterVolume(scale),
      setPaused: (paused) => controllerRef.current?.setPaused(paused),
    }),
    [],
  );
}
