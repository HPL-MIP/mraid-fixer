import { trackEvent } from "./analytics";

export type LifecycleState = {
  hidden: boolean;
  exposed: boolean;
  viewable: boolean;
  audioVolume: number;
};

let lifecycle: LifecycleState = {
  hidden: document.hidden,
  exposed: true,
  viewable: true,
  audioVolume: 1,
};
let documentHidden = document.hidden;
let mraidHidden = false;
let exposureObserved = false;
let documentListenerInstalled = false;
let mraidListenersInstalled = false;
const subscribers = new Set<(state: LifecycleState) => void>();

(["gameReady", "gameStart", "gameEnd", "gameClose"] as const).forEach((name) => {
  if (typeof window[name] !== "function") {
    window[name] = () => undefined;
  }
});

function emitLifecycle(): void {
  const snapshot = { ...lifecycle };
  subscribers.forEach((subscriber) => subscriber(snapshot));
}

function syncHiddenState(): void {
  lifecycle.hidden = documentHidden || mraidHidden;
}

function installDocumentLifecycleListener(): void {
  if (documentListenerInstalled) return;
  documentListenerInstalled = true;
  document.addEventListener("visibilitychange", () => {
    documentHidden = document.hidden;
    syncHiddenState();
    emitLifecycle();
  });
}

function installMraidLifecycleListeners(): void {
  if (mraidListenersInstalled) return;
  const bridge = window.mraid;
  if (!bridge) return;

  if (typeof bridge.isViewable === "function") {
    try {
      const initiallyViewable = Boolean(bridge.isViewable());
      lifecycle.viewable = initiallyViewable;
      if (!exposureObserved) lifecycle.exposed = initiallyViewable;
    } catch (error) {
      lifecycle.viewable = true;
    }
  }

  if (typeof bridge.addEventListener !== "function") return;
  mraidListenersInstalled = true;

  const add = (event: string, handler: (...args: unknown[]) => void) => {
    try {
      bridge.addEventListener?.(event, handler);
    } catch (error) {
      console.warn(`[MRAID] Could not bind ${event}`, error);
    }
  };

  add("error", (message) => console.warn("[MRAID]", message));
  add("stateChange", (state) => {
    mraidHidden = state === "hidden";
    syncHiddenState();
    emitLifecycle();
  });
  add("exposureChange", (exposure) => {
    if (typeof exposure === "number" && Number.isFinite(exposure)) {
      exposureObserved = true;
      lifecycle.exposed = exposure > 0;
      emitLifecycle();
    }
  });
  add("viewableChange", (viewable) => {
    const nextViewable = Boolean(viewable);
    lifecycle.viewable = nextViewable;
    if (!exposureObserved) lifecycle.exposed = nextViewable;
    emitLifecycle();
  });
  add("audioVolumeChange", (volume) => {
    if (typeof volume !== "number" || !Number.isFinite(volume)) return;
    lifecycle.audioVolume = Math.max(0, Math.min(1, volume / 100));
    emitLifecycle();
  });
}

function installLifecycleListeners(): void {
  installDocumentLifecycleListener();
  installMraidLifecycleListeners();
}

export async function initMraid(): Promise<void> {
  // Bind immediately when the bridge already exists, then retry after the
  // bounded ready/timeout gate in case the host injected MRAID late.
  installLifecycleListeners();
  await Promise.race([
    window.__mraidBootPromise ?? Promise.resolve(),
    new Promise<void>((resolve) => window.setTimeout(resolve, 2100)),
  ]);
  installLifecycleListeners();
  emitLifecycle();
}

export function bindLifecycle(
  subscriber: (state: LifecycleState) => void,
): () => void {
  subscribers.add(subscriber);
  subscriber({ ...lifecycle });
  return () => subscribers.delete(subscriber);
}

function callLifecycle(name: "gameReady" | "gameStart" | "gameEnd" | "gameClose") {
  const callback = window[name];
  if (typeof callback === "function") {
    try {
      callback();
    } catch (error) {
      console.warn(`[Lifecycle] ${name} failed`, error);
    }
  }
}

export const notifyGameReady = () => callLifecycle("gameReady");
export const notifyGameStart = () => callLifecycle("gameStart");
export const notifyGameEnd = () => callLifecycle("gameEnd");
export const notifyGameClose = () => callLifecycle("gameClose");

export function triggerCTA(): void {
  notifyGameClose();
  trackEvent("CTA_CLICKED");

  if (typeof window.handleClickAction === "function") {
    window.handleClickAction();
    return;
  }

  const mraid = window.mraid || {};
  const clickTarget =
    window.clickTag ||
    window.clickTag1 ||
    window.clickthrough ||
    window.clickThrough ||
    "";
  const usable =
    typeof window.isMraidUsable === "function" && window.isMraidUsable(mraid);

  if (typeof mraid.open === "function" && usable) {
    try {
      if (clickTarget) mraid.open(clickTarget);
      else mraid.open();
    } catch (error) {
      return;
    }
  }
}
