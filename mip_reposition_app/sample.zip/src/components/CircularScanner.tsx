import { useEffect, useRef } from "react";

type CircularScannerProps = {
  active: boolean;
  paused: boolean;
  onComplete: () => void;
};

const SCAN_DURATION_MS = 2600;
const RING_CIRCUMFERENCE = 1495;
const FLY_ICONS = ["🎬", "🎵", "☁️", "💪", "🎮", "📰"] as const;

export function CircularScanner({ active, paused, onComplete }: CircularScannerProps) {
  const ringRef = useRef<SVGCircleElement | null>(null);
  const percentRef = useRef<HTMLSpanElement | null>(null);
  const iconLayerRef = useRef<HTMLDivElement | null>(null);
  const elapsedRef = useRef(0);
  const iconElapsedRef = useRef(0);
  const iconCursorRef = useRef(0);
  const completedRef = useRef(false);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    if (!active) {
      elapsedRef.current = 0;
      iconElapsedRef.current = 0;
      iconCursorRef.current = 0;
      completedRef.current = false;
      if (percentRef.current) percentRef.current.textContent = "0%";
      if (ringRef.current) ringRef.current.style.strokeDashoffset = String(RING_CIRCUMFERENCE);
    }
  }, [active]);

  useEffect(() => {
    if (!active || paused || completedRef.current) return;
    let frame = 0;
    let previous = 0;

    const animateIcon = () => {
      const layer = iconLayerRef.current;
      if (!layer || typeof Element.prototype.animate !== "function") return;
      const icons = layer.querySelectorAll<HTMLElement>(".fly-icon");
      const icon = icons[iconCursorRef.current % icons.length];
      iconCursorRef.current += 1;
      const angle = (iconCursorRef.current * 137.5 * Math.PI) / 180;
      const distance = 245;
      const x = Math.cos(angle) * distance;
      const y = Math.sin(angle) * distance;
      icon.animate(
        [
          { opacity: 0, transform: `translate3d(${x}px, ${y}px, 0) scale(1)` },
          { opacity: 1, offset: 0.22 },
          { opacity: 0, transform: "translate3d(0, 0, 0) scale(.3)" },
        ],
        { duration: 820, easing: "ease-out" },
      );
    };

    const tick = (time: number) => {
      if (previous === 0) previous = time;
      const delta = Math.min(50, time - previous);
      previous = time;
      elapsedRef.current = Math.min(SCAN_DURATION_MS, elapsedRef.current + delta);
      iconElapsedRef.current += delta;
      const progress = elapsedRef.current / SCAN_DURATION_MS;
      const percent = Math.floor(progress * 100);
      if (percentRef.current) percentRef.current.textContent = `${percent}%`;
      if (ringRef.current) {
        ringRef.current.style.strokeDashoffset = String(
          RING_CIRCUMFERENCE - RING_CIRCUMFERENCE * progress,
        );
      }
      if (iconElapsedRef.current >= 185 && progress < 0.96) {
        iconElapsedRef.current = 0;
        animateIcon();
      }
      if (progress < 1) {
        frame = window.requestAnimationFrame(tick);
      } else if (!completedRef.current) {
        completedRef.current = true;
        onCompleteRef.current();
      }
    };

    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, [active, paused]);

  return (
    <div className="scan-circle" aria-label="Scan progress">
      <svg className="scan-ring" viewBox="0 0 526 526" aria-hidden="true">
        <circle cx="263" cy="263" r="238" className="scan-ring-base" />
        <circle
          ref={ringRef}
          cx="263"
          cy="263"
          r="238"
          className="scan-ring-progress"
          strokeDasharray={RING_CIRCUMFERENCE}
          strokeDashoffset={RING_CIRCUMFERENCE}
        />
      </svg>
      <span ref={percentRef} className="scan-percent">0%</span>
      <div ref={iconLayerRef} className="fly-icons" aria-hidden="true">
        {FLY_ICONS.map((icon) => <span className="fly-icon" key={icon}>{icon}</span>)}
      </div>
    </div>
  );
}
