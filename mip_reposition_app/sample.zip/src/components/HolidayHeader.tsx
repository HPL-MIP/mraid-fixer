import { useEffect, useState } from "react";
import claimDiscount from "../assets/creative/holidays/claim-50-discount.png";
import redBorder from "../assets/creative/holidays/red-border.png";
import type { HolidayPromotion } from "../holidays";

type HolidayHeaderProps = {
  promotion: HolidayPromotion;
};

function preloadImage(source: string): Promise<void> {
  return new Promise((resolve) => {
    const image = new Image();
    const finish = () => resolve();
    image.onload = finish;
    image.onerror = finish;
    image.src = source;
    if (image.complete) finish();
  });
}

export function HolidayHeader({ promotion }: HolidayHeaderProps) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    setReady(false);
    void Promise.all([
      preloadImage(promotion.image),
      preloadImage(claimDiscount),
      preloadImage(redBorder),
    ]).then(() => {
      if (active) setReady(true);
    });
    return () => {
      active = false;
    };
  }, [promotion.image]);

  return (
    <aside
      className={`holiday-promo ${ready ? "is-ready" : ""}`}
      data-holiday={promotion.id}
      aria-label={`${promotion.label}. Claim your 50% discount.`}
    >
      <div className="holiday-art-window" aria-hidden="true">
        <img className="holiday-art" src={promotion.image} alt="" />
        <span className="holiday-border-underlay" />
        <img className="holiday-border" src={redBorder} alt="" />
      </div>
      <img className="holiday-claim" src={claimDiscount} alt="" aria-hidden="true" />
    </aside>
  );
}
