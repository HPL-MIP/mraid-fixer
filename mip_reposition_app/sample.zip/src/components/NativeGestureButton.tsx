import {
  useEffect,
  useRef,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react";
import type { SfxInteractionToken } from "../audio/SfxController";
import {
  makeSfxInteractionToken,
  SfxInputOwnership,
  type SfxInputPath,
} from "../audio/SfxInputOwnership";

type Props = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "onClick" | "children"> & {
  children: ReactNode;
  onGesture: (token: SfxInteractionToken) => boolean;
  onGestureMove: (token: SfxInteractionToken) => void;
  onGestureRelease: (token: SfxInteractionToken) => void;
  onGestureCancel: (token: SfxInteractionToken) => void;
  onActivate: () => void;
};

type ActiveInput = { token: SfxInteractionToken };
const ACTIVE_CAPTURE = { capture: true, passive: false } as const;
const PASSIVE_CAPTURE = { capture: true, passive: true } as const;

function usesTouchPath(): boolean {
  const iPadDesktop = navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
  const mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  return (mobile || iPadDesktop) && ("ontouchstart" in window || navigator.maxTouchPoints > 0);
}

function isInside(element: HTMLElement, x: number, y: number): boolean {
  const target = document.elementFromPoint(x, y);
  return target !== null && element.contains(target);
}

export function NativeGestureButton({
  children,
  onGesture,
  onGestureMove,
  onGestureRelease,
  onGestureCancel,
  onActivate,
  ...buttonProps
}: Props) {
  const elementRef = useRef<HTMLButtonElement | null>(null);
  const callbacks = useRef({ onGesture, onGestureMove, onGestureRelease, onGestureCancel, onActivate });
  callbacks.current = { onGesture, onGestureMove, onGestureRelease, onGestureCancel, onActivate };

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;
    const touchPath = usesTouchPath();
    const inputs = new SfxInputOwnership<ActiveInput>(touchPath ? "touch" : "pointer");
    const cleanups: Array<() => void> = [];

    const accept = (path: SfxInputPath, id: string | number) => {
      const token = makeSfxInteractionToken(path, id);
      if (element.disabled || inputs.has(path, id) || !callbacks.current.onGesture(token)) return;
      inputs.claim(path, id, { token });
    };
    const cancel = (path: SfxInputPath, id: string | number) => {
      const active = inputs.take(path, id);
      if (active) callbacks.current.onGestureCancel(active.token);
    };
    const release = (path: SfxInputPath, id: string | number, x: number, y: number) => {
      const active = inputs.take(path, id);
      if (!active) return;
      callbacks.current.onGestureRelease(active.token);
      if (isInside(element, x, y)) callbacks.current.onActivate();
      else callbacks.current.onGestureCancel(active.token);
    };

    const onKeyDown = (event: KeyboardEvent) => {
      if (!event.isTrusted || event.repeat || (event.key !== "Enter" && event.key !== " ")) return;
      event.preventDefault();
      accept("keyboard", event.code);
    };
    const onKeyUp = (event: KeyboardEvent) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      const active = inputs.take("keyboard", event.code);
      if (!active) return;
      callbacks.current.onGestureRelease(active.token);
      callbacks.current.onActivate();
    };
    const onAccessibleClick = (event: MouseEvent) => {
      if (!event.isTrusted || event.detail !== 0) return;
      const token = makeSfxInteractionToken("activation", event.timeStamp);
      if (!callbacks.current.onGesture(token)) return;
      callbacks.current.onGestureRelease(token);
      callbacks.current.onActivate();
    };
    const preventClick = (event: MouseEvent) => event.preventDefault();
    element.addEventListener("keydown", onKeyDown, ACTIVE_CAPTURE);
    element.addEventListener("keyup", onKeyUp, ACTIVE_CAPTURE);
    element.addEventListener("click", onAccessibleClick, ACTIVE_CAPTURE);
    element.addEventListener("click", preventClick);
    cleanups.push(
      () => element.removeEventListener("keydown", onKeyDown, ACTIVE_CAPTURE),
      () => element.removeEventListener("keyup", onKeyUp, ACTIVE_CAPTURE),
      () => element.removeEventListener("click", onAccessibleClick, ACTIVE_CAPTURE),
      () => element.removeEventListener("click", preventClick),
    );

    if (touchPath) {
      const onTouchStart = (event: TouchEvent) => {
        const touch = Array.from(event.changedTouches).find((item) => item.target instanceof Node && element.contains(item.target));
        if (touch) accept("touch", touch.identifier);
      };
      const onTouchMove = (event: TouchEvent) => {
        for (const touch of Array.from(event.changedTouches)) {
          const active = inputs.get("touch", touch.identifier);
          if (active) callbacks.current.onGestureMove(active.token);
        }
      };
      const onTouchEnd = (event: TouchEvent) => {
        for (const touch of Array.from(event.changedTouches)) release("touch", touch.identifier, touch.clientX, touch.clientY);
      };
      const onTouchCancel = (event: TouchEvent) => {
        for (const touch of Array.from(event.changedTouches)) cancel("touch", touch.identifier);
      };
      element.addEventListener("touchstart", onTouchStart, ACTIVE_CAPTURE);
      window.addEventListener("touchmove", onTouchMove, PASSIVE_CAPTURE);
      window.addEventListener("touchend", onTouchEnd, PASSIVE_CAPTURE);
      window.addEventListener("touchcancel", onTouchCancel, PASSIVE_CAPTURE);
      cleanups.push(
        () => element.removeEventListener("touchstart", onTouchStart, ACTIVE_CAPTURE),
        () => window.removeEventListener("touchmove", onTouchMove, PASSIVE_CAPTURE),
        () => window.removeEventListener("touchend", onTouchEnd, PASSIVE_CAPTURE),
        () => window.removeEventListener("touchcancel", onTouchCancel, PASSIVE_CAPTURE),
      );
    } else {
      const onPointerDown = (event: PointerEvent) => {
        if (event.pointerType === "mouse" && event.button !== 0) return;
        accept("pointer", event.pointerId);
        if (inputs.has("pointer", event.pointerId)) {
          try { element.setPointerCapture(event.pointerId); } catch { /* best effort */ }
        }
      };
      const onPointerMove = (event: PointerEvent) => {
        const active = inputs.get("pointer", event.pointerId);
        if (active) callbacks.current.onGestureMove(active.token);
      };
      const onPointerUp = (event: PointerEvent) => release("pointer", event.pointerId, event.clientX, event.clientY);
      const onPointerCancel = (event: PointerEvent) => cancel("pointer", event.pointerId);
      const onLostCapture = (event: PointerEvent) => cancel("pointer", event.pointerId);
      element.addEventListener("pointerdown", onPointerDown, ACTIVE_CAPTURE);
      element.addEventListener("lostpointercapture", onLostCapture, ACTIVE_CAPTURE);
      window.addEventListener("pointermove", onPointerMove, ACTIVE_CAPTURE);
      window.addEventListener("pointerup", onPointerUp, ACTIVE_CAPTURE);
      window.addEventListener("pointercancel", onPointerCancel, ACTIVE_CAPTURE);
      cleanups.push(
        () => element.removeEventListener("pointerdown", onPointerDown, ACTIVE_CAPTURE),
        () => element.removeEventListener("lostpointercapture", onLostCapture, ACTIVE_CAPTURE),
        () => window.removeEventListener("pointermove", onPointerMove, ACTIVE_CAPTURE),
        () => window.removeEventListener("pointerup", onPointerUp, ACTIVE_CAPTURE),
        () => window.removeEventListener("pointercancel", onPointerCancel, ACTIVE_CAPTURE),
      );
    }

    const onBlur = () => {
      for (const active of inputs.drain()) callbacks.current.onGestureCancel(active.token);
    };
    window.addEventListener("blur", onBlur, ACTIVE_CAPTURE);
    cleanups.push(() => window.removeEventListener("blur", onBlur, ACTIVE_CAPTURE));
    return () => {
      onBlur();
      cleanups.forEach((cleanup) => cleanup());
    };
  }, []);

  return <button {...buttonProps} ref={elementRef} type={buttonProps.type ?? "button"}>{children}</button>;
}
