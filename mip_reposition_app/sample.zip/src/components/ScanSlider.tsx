import { useEffect, useRef } from "react";
import type { SfxInteractionToken } from "../audio/SfxController";
import {
  makeSfxInteractionToken,
  SfxInputOwnership,
  type SfxInputPath,
} from "../audio/SfxInputOwnership";

type ScanSliderProps = {
  disabled: boolean;
  onGestureStart: (token: SfxInteractionToken) => boolean;
  onGestureMove: (token: SfxInteractionToken) => void;
  onGestureRelease: (token: SfxInteractionToken) => void;
  onGestureCancel: (token: SfxInteractionToken) => void;
  onResolve: (token: SfxInteractionToken, success: boolean) => void;
};

type ActiveDrag = { token: SfxInteractionToken; offset: number };
const ACTIVE_CAPTURE = { capture: true, passive: false } as const;
const PASSIVE_CAPTURE = { capture: true, passive: true } as const;
const HANDLE_SIZE = 133;
const TRACK_PADDING = 14;

function usesTouchPath(): boolean {
  const iPadDesktop = navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
  const mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  return (mobile || iPadDesktop) && ("ontouchstart" in window || navigator.maxTouchPoints > 0);
}

export function ScanSlider({
  disabled,
  onGestureStart,
  onGestureMove,
  onGestureRelease,
  onGestureCancel,
  onResolve,
}: ScanSliderProps) {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const handleRef = useRef<HTMLDivElement | null>(null);
  const fillRef = useRef<HTMLDivElement | null>(null);
  const percentRef = useRef<HTMLDivElement | null>(null);
  const labelRef = useRef<HTMLDivElement | null>(null);
  const currentXRef = useRef(0);
  const doneRef = useRef(false);
  const disabledRef = useRef(disabled);
  disabledRef.current = disabled;
  const callbacks = useRef({
    onGestureStart,
    onGestureMove,
    onGestureRelease,
    onGestureCancel,
    onResolve,
  });
  callbacks.current = {
    onGestureStart,
    onGestureMove,
    onGestureRelease,
    onGestureCancel,
    onResolve,
  };

  useEffect(() => {
    const track = trackRef.current;
    const handle = handleRef.current;
    const fill = fillRef.current;
    const percent = percentRef.current;
    if (!track || !handle || !fill || !percent) return;

    const touchPath = usesTouchPath();
    const inputs = new SfxInputOwnership<ActiveDrag>(touchPath ? "touch" : "pointer");
    let dragging = false;
    let frame = 0;
    let pendingX: number | null = null;

    const maxX = () => Math.max(1, track.offsetWidth - HANDLE_SIZE - TRACK_PADDING * 2);
    const localX = (clientX: number) => {
      const rect = track.getBoundingClientRect();
      const scale = rect.width / track.offsetWidth || 1;
      return (clientX - rect.left) / scale;
    };
    const renderPosition = (x: number, snap: boolean) => {
      const clamped = Math.max(0, Math.min(maxX(), x));
      currentXRef.current = clamped;
      handle.classList.toggle("is-snapping", snap);
      fill.classList.toggle("is-snapping", snap);
      handle.style.transform = `translate3d(${clamped}px, 0, 0)`;
      fill.style.width = `${clamped + HANDLE_SIZE / 2 + TRACK_PADDING}px`;
      percent.textContent = `${Math.round((clamped / maxX()) * 100)}%`;
    };
    const schedulePosition = (x: number) => {
      pendingX = x;
      if (frame) return;
      frame = window.requestAnimationFrame(() => {
        frame = 0;
        if (pendingX !== null) renderPosition(pendingX, false);
        pendingX = null;
      });
    };
    const accept = (path: SfxInputPath, id: string | number, clientX: number) => {
      if (dragging || disabledRef.current || doneRef.current) return;
      const token = makeSfxInteractionToken(path, id);
      if (!callbacks.current.onGestureStart(token)) return;
      const offset = localX(clientX) - TRACK_PADDING - currentXRef.current;
      if (!inputs.claim(path, id, { token, offset })) {
        callbacks.current.onGestureCancel(token);
        return;
      }
      dragging = true;
      handle.classList.remove("is-snapping");
      fill.classList.remove("is-snapping");
    };
    const move = (path: SfxInputPath, id: string | number, clientX: number) => {
      const active = inputs.get(path, id);
      if (!active || doneRef.current) return;
      callbacks.current.onGestureMove(active.token);
      schedulePosition(localX(clientX) - TRACK_PADDING - active.offset);
    };
    const release = (path: SfxInputPath, id: string | number, clientX: number) => {
      const active = inputs.take(path, id);
      if (!active) return;
      dragging = false;
      if (frame) {
        window.cancelAnimationFrame(frame);
        frame = 0;
      }
      const x = Math.max(0, Math.min(maxX(), localX(clientX) - TRACK_PADDING - active.offset));
      const success = x / maxX() >= 0.85;
      callbacks.current.onResolve(active.token, success);
      callbacks.current.onGestureRelease(active.token);
      if (success) {
        doneRef.current = true;
        renderPosition(maxX(), true);
        if (labelRef.current) labelRef.current.textContent = "";
      } else {
        renderPosition(0, true);
      }
    };
    const cancel = (path: SfxInputPath, id: string | number) => {
      const active = inputs.take(path, id);
      if (!active) return;
      dragging = false;
      callbacks.current.onGestureCancel(active.token);
      renderPosition(0, true);
    };

    const onKeyDown = (event: KeyboardEvent) => {
      if (!event.isTrusted || event.repeat || (event.key !== "Enter" && event.key !== " ")) return;
      event.preventDefault();
      const token = makeSfxInteractionToken("keyboard", event.code);
      if (!callbacks.current.onGestureStart(token)) return;
      callbacks.current.onResolve(token, true);
      callbacks.current.onGestureRelease(token);
      doneRef.current = true;
      renderPosition(maxX(), true);
      if (labelRef.current) labelRef.current.textContent = "";
    };
    handle.addEventListener("keydown", onKeyDown, ACTIVE_CAPTURE);

    const cleanups: Array<() => void> = [
      () => handle.removeEventListener("keydown", onKeyDown, ACTIVE_CAPTURE),
    ];
    if (touchPath) {
      const onTouchStart = (event: TouchEvent) => {
        const touch = Array.from(event.changedTouches).find(
          (item) => item.target instanceof Node && handle.contains(item.target),
        );
        if (!touch) return;
        event.preventDefault();
        accept("touch", touch.identifier, touch.clientX);
      };
      const onTouchMove = (event: TouchEvent) => {
        for (const touch of Array.from(event.changedTouches)) {
          move("touch", touch.identifier, touch.clientX);
        }
      };
      const onTouchEnd = (event: TouchEvent) => {
        for (const touch of Array.from(event.changedTouches)) {
          release("touch", touch.identifier, touch.clientX);
        }
      };
      const onTouchCancel = (event: TouchEvent) => {
        for (const touch of Array.from(event.changedTouches)) cancel("touch", touch.identifier);
      };
      handle.addEventListener("touchstart", onTouchStart, ACTIVE_CAPTURE);
      window.addEventListener("touchmove", onTouchMove, PASSIVE_CAPTURE);
      window.addEventListener("touchend", onTouchEnd, PASSIVE_CAPTURE);
      window.addEventListener("touchcancel", onTouchCancel, PASSIVE_CAPTURE);
      cleanups.push(
        () => handle.removeEventListener("touchstart", onTouchStart, ACTIVE_CAPTURE),
        () => window.removeEventListener("touchmove", onTouchMove, PASSIVE_CAPTURE),
        () => window.removeEventListener("touchend", onTouchEnd, PASSIVE_CAPTURE),
        () => window.removeEventListener("touchcancel", onTouchCancel, PASSIVE_CAPTURE),
      );
    } else {
      const onPointerDown = (event: PointerEvent) => {
        if (event.pointerType === "mouse" && event.button !== 0) return;
        event.preventDefault();
        accept("pointer", event.pointerId, event.clientX);
        if (inputs.has("pointer", event.pointerId)) {
          try { handle.setPointerCapture(event.pointerId); } catch { /* best effort */ }
        }
      };
      const onPointerMove = (event: PointerEvent) => move("pointer", event.pointerId, event.clientX);
      const onPointerUp = (event: PointerEvent) => release("pointer", event.pointerId, event.clientX);
      const onPointerCancel = (event: PointerEvent) => cancel("pointer", event.pointerId);
      const onLostCapture = (event: PointerEvent) => cancel("pointer", event.pointerId);
      handle.addEventListener("pointerdown", onPointerDown, ACTIVE_CAPTURE);
      handle.addEventListener("lostpointercapture", onLostCapture, ACTIVE_CAPTURE);
      window.addEventListener("pointermove", onPointerMove, ACTIVE_CAPTURE);
      window.addEventListener("pointerup", onPointerUp, ACTIVE_CAPTURE);
      window.addEventListener("pointercancel", onPointerCancel, ACTIVE_CAPTURE);
      cleanups.push(
        () => handle.removeEventListener("pointerdown", onPointerDown, ACTIVE_CAPTURE),
        () => handle.removeEventListener("lostpointercapture", onLostCapture, ACTIVE_CAPTURE),
        () => window.removeEventListener("pointermove", onPointerMove, ACTIVE_CAPTURE),
        () => window.removeEventListener("pointerup", onPointerUp, ACTIVE_CAPTURE),
        () => window.removeEventListener("pointercancel", onPointerCancel, ACTIVE_CAPTURE),
      );
    }

    const onBlur = () => {
      for (const active of inputs.drain()) callbacks.current.onGestureCancel(active.token);
      dragging = false;
      if (!doneRef.current) renderPosition(0, true);
    };
    window.addEventListener("blur", onBlur, ACTIVE_CAPTURE);
    cleanups.push(() => window.removeEventListener("blur", onBlur, ACTIVE_CAPTURE));

    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      onBlur();
      cleanups.forEach((cleanup) => cleanup());
    };
  }, []);

  return (
    <div className="slider-control">
      <div ref={percentRef} className="slider-percent" aria-live="polite">0%</div>
      <div ref={trackRef} className="slider-track">
        <div ref={fillRef} className="slider-fill" />
        <div ref={labelRef} className="slider-label">SLIDE TO SCAN</div>
        <div
          ref={handleRef}
          className="slider-handle"
          role="slider"
          aria-label="Slide to scan"
          aria-valuemin={0}
          aria-valuemax={100}
          tabIndex={disabled ? -1 : 0}
        >
          <span aria-hidden="true">➜</span>
        </div>
      </div>
    </div>
  );
}
