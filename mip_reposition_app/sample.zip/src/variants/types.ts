export type MonoBoostVariantId = "mip3" | "mip4";

export type MonoBoostConfig = {
  id: MonoBoostVariantId;
  mechanic: "tap-scan" | "slide-scan";
  title: string;
  heading: string;
  instruction: string;
  scanningText: string;
  resultHeading: string;
  resultBody: string;
  ctaLabel: string;
  showDisclaimer: boolean;
};
