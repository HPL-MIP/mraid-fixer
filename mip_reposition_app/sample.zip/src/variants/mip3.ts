import type { MonoBoostConfig } from "./types";

const config: MonoBoostConfig = {
  id: "mip3",
  mechanic: "tap-scan",
  title: "MonoBoost Subscription Scan",
  heading: "⚠️ Check your subscriptions now",
  instruction: "Tap below to scan",
  scanningText: "Scanning your apps...",
  resultHeading: "Unused subscriptions found",
  resultBody: "",
  ctaLabel: "Check Now",
  showDisclaimer: true,
};

export default config;
