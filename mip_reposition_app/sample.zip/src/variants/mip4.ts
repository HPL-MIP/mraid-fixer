import type { MonoBoostConfig } from "./types";

const config: MonoBoostConfig = {
  id: "mip4",
  mechanic: "slide-scan",
  title: "MonoBoost App Scan",
  heading: "Slide to scan your apps",
  instruction: "Drag the circle all the way right",
  scanningText: "Scanning your apps...",
  resultHeading: "Subscriptions detected",
  resultBody: "See what's still charging you — and cancel the ones you don't need.",
  ctaLabel: "Find & Cancel",
  showDisclaimer: false,
};

export default config;
